
import React, { useState, useEffect, useCallback } from 'react';
import { Helmet } from 'react-helmet';
import { Routes, Route, Navigate, useLocation } from 'react-router-dom';
import LandingPage from '@/components/LandingPage';
import Dashboard from '@/components/Dashboard';
import SignupPage from '@/components/auth/SignupPage';
import SigninPage from '@/components/auth/SigninPage';
import QnAPage from '@/components/QnAPage';
import QnAQuestionDetail from '@/components/QnAQuestionDetail';
import AdoptionCentresPage from '@/components/AdoptionCentresPage';
import AdminDashboard from '@/components/AdminDashboard';
import ProtectedAdminRoute from '@/components/ProtectedAdminRoute';
import CommunityGuidelinesModal from '@/components/CommunityGuidelinesModal';
import CommunityGuidelinesPage from '@/components/CommunityGuidelinesPage';
import Profile from '@/components/Profile';
import CommunitiesPage from '@/components/CommunitiesPage';
import ForumPage from '@/components/ForumPage'; // Added import for Forum
import { Toaster } from '@/components/ui/toaster';
import { AuthProvider, useAuth } from '@/context/AuthContext';
import { ThemeProviderContext, useTheme } from '@/context/ThemeContext';
import { PetThemeProvider } from '@/context/PetThemeContext';
import ThemeProvider from '@/components/ThemeProvider';
import LocationPermissionModal from '@/components/LocationPermissionModal';
import { useLocationTracking } from '@/hooks/useLocationTracking';
import { updateUserLocation } from '@/lib/locationUtils';

// New Pet Theme Components
import GlobalHeader from '@/components/GlobalHeader';
import GlobalSidePanel from '@/components/GlobalSidePanel';
import PetFooter from '@/components/PetFooter';
import PawCursorTrail from '@/components/ui/PawCursorTrail';
import PageTransition from '@/components/PageTransition';

// Protected Route Wrapper with Guidelines Check
const ProtectedRoute = ({ children }) => {
  const { isAuthenticated, loading, hasAcceptedGuidelines } = useAuth();
  const location = useLocation();
  
  if (loading) return <div className="min-h-screen flex items-center justify-center bg-[#FFF8E7]">Loading...</div>;
  
  if (!isAuthenticated) {
    return <Navigate to="/signin" replace state={{ from: location }} />;
  }

  // Critical: Redirect to guidelines if not accepted
  if (!hasAcceptedGuidelines && location.pathname !== '/community-guidelines') {
    return <Navigate to="/community-guidelines" replace />;
  }
  
  return children;
};

// Route for Guidelines that ensures user is auth'd
const GuidelinesRoute = ({ children }) => {
  const { isAuthenticated, loading, hasAcceptedGuidelines } = useAuth();
  
  if (loading) return <div className="min-h-screen flex items-center justify-center bg-[#FFF8E7]">Loading...</div>;

  if (!isAuthenticated) {
    return <Navigate to="/signin" replace />;
  }
  
  return children;
};

const AppContent = () => {
  const { user } = useAuth();
  const { activeTheme } = useTheme();
  const { latitude, longitude, accuracy, refreshLocation } = useLocationTracking();

  useEffect(() => {
    if (user && user.id && latitude && longitude) {
        const update = async () => {
             await updateUserLocation(user.id, { latitude, longitude, accuracy });
        };
        update();
    }
  }, [user, latitude, longitude, accuracy]);

  const handlePermissionGranted = useCallback(() => {
      refreshLocation();
  }, [refreshLocation]);

  return (
      <div 
        className="flex flex-col min-h-screen font-poppins transition-colors duration-300"
        style={{ backgroundColor: activeTheme.bg_surface || '#FFF8E7' }}
      >
        <GlobalHeader />
        <GlobalSidePanel />
        <PawCursorTrail />
        
        <main className="flex-1 w-full max-w-[1920px] mx-auto">
          <PageTransition>
            <Routes>
               {/* Public Routes */}
               <Route path="/" element={<LandingPage />} />
               <Route path="/signup" element={<SignupPage />} />
               <Route path="/signin" element={<SigninPage />} />
               
               {/* Static Guidelines Page (Public) */}
               <Route path="/guidelines" element={<CommunityGuidelinesPage />} />

               {/* Guidelines Acceptance Flow (Protected but restricted) */}
               <Route 
                 path="/community-guidelines" 
                 element={
                   <GuidelinesRoute>
                     <CommunityGuidelinesModal />
                   </GuidelinesRoute>
                 } 
               />
               
               {/* Protected Routes */}
               <Route 
                 path="/dashboard" 
                 element={
                   <ProtectedRoute>
                     <Dashboard />
                   </ProtectedRoute>
                 } 
               />

               <Route 
                 path="/qa" 
                 element={
                   <ProtectedRoute>
                     <QnAPage />
                   </ProtectedRoute>
                 } 
               />
               
               <Route 
                 path="/qa/:id" 
                 element={
                   <ProtectedRoute>
                     <QnAQuestionDetail />
                   </ProtectedRoute>
                 } 
               />
               
               <Route 
                 path="/forum" 
                 element={
                   <ProtectedRoute>
                     <ForumPage />
                   </ProtectedRoute>
                 } 
               />

               <Route 
                 path="/adoption-centres" 
                 element={
                   <ProtectedRoute>
                     <AdoptionCentresPage />
                   </ProtectedRoute>
                 } 
               />
               
               <Route 
                 path="/profile" 
                 element={
                   <ProtectedRoute>
                     <Profile />
                   </ProtectedRoute>
                 } 
               />

               <Route 
                 path="/communities" 
                 element={
                   <ProtectedRoute>
                     <CommunitiesPage />
                   </ProtectedRoute>
                 } 
               />

               <Route 
                 path="/admin" 
                 element={
                   <ProtectedAdminRoute>
                     <AdminDashboard />
                   </ProtectedAdminRoute>
                 } 
               />

               {/* Fallback */}
               <Route path="*" element={<Navigate to="/" replace />} />
            </Routes>
          </PageTransition>
        </main>

        <PetFooter />
        
        {user && <LocationPermissionModal onPermissionGranted={handlePermissionGranted} />}
      </div>
  );
};

function App() {
  return (
    <ThemeProviderContext>
      <ThemeProvider>
        <PetThemeProvider>
          <AuthProvider>
            <Helmet>
              <link rel="preconnect" href="https://fonts.googleapis.com" />
              <link rel="preconnect" href="https://fonts.gstatic.com" crossOrigin="anonymous" />
              <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700;800&display=swap" rel="stylesheet" />
              <title>Paws & Pals</title>
            </Helmet>
            
            <AppContent />
            <Toaster />
          </AuthProvider>
        </PetThemeProvider>
      </ThemeProvider>
    </ThemeProviderContext>
  );
}

export default App;
