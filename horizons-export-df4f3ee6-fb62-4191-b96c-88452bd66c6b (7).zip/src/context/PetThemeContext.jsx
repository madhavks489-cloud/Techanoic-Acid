
import React, { createContext, useContext, useState, useEffect } from 'react';
import { lightTheme } from '@/lib/themeColors';

const PetThemeContext = createContext();

export const usePetTheme = () => useContext(PetThemeContext);

export const PetThemeProvider = ({ children }) => {
  const [soundEnabled, setSoundEnabled] = useState(() => {
    return localStorage.getItem('pet-sound-enabled') !== 'false';
  });
  
  const [cursorTrailEnabled, setCursorTrailEnabled] = useState(() => {
    return localStorage.getItem('pet-cursor-trail') !== 'false';
  });

  const [activeSidePanel, setActiveSidePanel] = useState(false);
  const activeTheme = lightTheme; // Simplified for this task, can be dynamic

  useEffect(() => {
    localStorage.setItem('pet-sound-enabled', soundEnabled);
  }, [soundEnabled]);

  useEffect(() => {
    localStorage.setItem('pet-cursor-trail', cursorTrailEnabled);
  }, [cursorTrailEnabled]);

  const playSound = (type) => {
    if (!soundEnabled) return;

    // Simple data URIs for sounds (short beeps/pops to avoid 404s without assets)
    // In production, replace with real asset paths
    const sounds = {
      click: 'data:audio/wav;base64,UklGRl9vT19XQVZFZm10IBAAAAABAAEAQB8AAEAfAAABAAgAZGF0YU...', // Placeholder
      success: 'data:audio/wav;base64,UklGRl9vT19XQVZFZm10IBAAAAABAAEAQB8AAEAfAAABAAgAZGF0YU...', 
      hover: 'data:audio/wav;base64,UklGRl9vT19XQVZFZm10IBAAAAABAAEAQB8AAEAfAAABAAgAZGF0YU...', 
      error: 'data:audio/wav;base64,UklGRl9vT19XQVZFZm10IBAAAAABAAEAQB8AAEAfAAABAAgAZGF0YU...'
    };

    // For now, we will just console log to simulate sound if no actual file
    // To implement real sound: const audio = new Audio('/sounds/' + type + '.mp3');
    // We can use a simple oscillator for web audio API to make a "pop"
    
    try {
        const AudioContext = window.AudioContext || window.webkitAudioContext;
        if (AudioContext) {
            const ctx = new AudioContext();
            const osc = ctx.createOscillator();
            const gain = ctx.createGain();
            
            osc.connect(gain);
            gain.connect(ctx.destination);
            
            if (type === 'click') {
                osc.type = 'sine';
                osc.frequency.setValueAtTime(800, ctx.currentTime);
                osc.frequency.exponentialRampToValueAtTime(300, ctx.currentTime + 0.1);
            } else if (type === 'success') {
                osc.type = 'triangle';
                osc.frequency.setValueAtTime(400, ctx.currentTime);
                osc.frequency.linearRampToValueAtTime(800, ctx.currentTime + 0.1);
            } else {
                osc.type = 'sine';
                osc.frequency.setValueAtTime(200, ctx.currentTime);
            }
            
            gain.gain.setValueAtTime(0.1, ctx.currentTime);
            gain.gain.exponentialRampToValueAtTime(0.01, ctx.currentTime + 0.1);
            
            osc.start();
            osc.stop(ctx.currentTime + 0.1);
        }
    } catch (e) {
        // Fallback or ignore
    }
  };

  const toggleSidePanel = () => setActiveSidePanel(prev => !prev);

  const value = {
    soundEnabled,
    setSoundEnabled,
    cursorTrailEnabled,
    setCursorTrailEnabled,
    activeSidePanel,
    toggleSidePanel,
    setActiveSidePanel,
    playSound,
    activeTheme
  };

  return (
    <PetThemeContext.Provider value={value}>
      {children}
    </PetThemeContext.Provider>
  );
};
