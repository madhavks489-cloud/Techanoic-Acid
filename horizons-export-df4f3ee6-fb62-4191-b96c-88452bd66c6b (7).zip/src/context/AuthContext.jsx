
import React, { createContext, useContext, useState, useEffect } from 'react';
import { supabase } from '@/lib/supabase';
import { useToast } from '@/components/ui/use-toast';

const AuthContext = createContext({});

export const useAuth = () => useContext(AuthContext);

export const AuthProvider = ({ children }) => {
  const [user, setUser] = useState(null);
  const [session, setSession] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [hasAcceptedGuidelines, setHasAcceptedGuidelines] = useState(false);
  const { toast } = useToast();

  const checkGuidelinesAcceptance = async (userId) => {
    try {
      // Primary check: Profile flag
      const { data: profile, error: profileError } = await supabase
        .from('profiles')
        .select('agreed_to_guidelines')
        .eq('id', userId)
        .single();
        
      if (!profileError && profile) {
          setHasAcceptedGuidelines(profile.agreed_to_guidelines === true);
          return;
      }

      // Fallback check: Acceptance table
      const { data, error } = await supabase
        .from('community_guidelines_acceptance')
        .select('id')
        .eq('user_id', userId)
        .maybeSingle();

      setHasAcceptedGuidelines(!!data);
    } catch (err) {
      console.error('Failed to check guidelines:', err);
      setHasAcceptedGuidelines(false);
    }
  };

  const fetchProfile = async (authUser) => {
    try {
      const { data, error } = await supabase
        .from('profiles')
        .select('*')
        .eq('id', authUser.id)
        .single();

      if (error) {
        console.error('Error fetching profile:', error);
        // Even if fetching profile fails, we retain authUser base info
        setUser(authUser);
      } else {
        setUser({ ...authUser, ...data });
        setHasAcceptedGuidelines(data.agreed_to_guidelines === true);
      }
    } catch (error) {
      console.error('Profile fetch error:', error);
      setUser(authUser);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    const initializeAuth = async () => {
      try {
        const { data: { session: initialSession }, error } = await supabase.auth.getSession();
        
        if (error) throw error;
        
        setSession(initialSession);
        if (initialSession?.user) {
          await fetchProfile(initialSession.user);
        } else {
          setLoading(false);
        }
      } catch (error) {
        console.error("Auth initialization error:", error);
        setError(error);
        setLoading(false);
      }
    };

    initializeAuth();

    const { data: { subscription } } = supabase.auth.onAuthStateChange(async (event, currentSession) => {
      setSession(currentSession);
      
      if (currentSession?.user) {
         // Optimistically set user from session immediately to prevent flicker
         if (!user || user.id !== currentSession.user.id) {
             setUser(currentSession.user); 
         }
         await fetchProfile(currentSession.user);
      } else {
        setUser(null);
        setHasAcceptedGuidelines(false);
        setLoading(false);
      }
    });

    return () => subscription.unsubscribe();
  }, []);

  const login = async (username, password) => {
    setLoading(true);
    setError(null);
    try {
      const emailToUse = `${username}@gmail.com`;
      const { data, error } = await supabase.auth.signInWithPassword({
        email: emailToUse,
        password,
      });

      if (error) throw error;
      
      // We don't redirect here anymore, strictly handle state. 
      // The calling component will check `hasAcceptedGuidelines` after await.
      
      toast({ title: "Welcome back!", description: "Successfully logged in." });
      return { success: true, user: data.user };
    } catch (error) {
      console.error("Login error:", error);
      let message = "Invalid username or password.";
      if (error.message.includes("Email not confirmed")) {
         message = "Account not active. Please contact support.";
      }
      setError(error);
      toast({ title: "Login Failed", description: message, variant: "destructive" });
      return { success: false, error: message };
    } finally {
      setLoading(false);
    }
  };

  const signup = async (username, password) => {
    setLoading(true);
    setError(null);
    try {
      const email = `${username}@gmail.com`;
      const { data: signUpData, error: signUpError } = await supabase.auth.signUp({
        email: email,
        password: password,
        options: {
          data: { username: username }
        }
      });

      if (signUpError) throw signUpError;

      const userId = signUpData.user?.id;
      
      if (userId) {
        await supabase.from('profiles').upsert({
          id: userId,
          username: username,
          email: email,
          full_name: username,
          role: 'user',
          agreed_to_guidelines: false, // Explicitly false
          created_at: new Date().toISOString()
        });
      }
      
      // Auto login check
      if (signUpData.session) {
          setSession(signUpData.session);
          setUser(signUpData.user);
          setHasAcceptedGuidelines(false);
      }

      toast({ title: "Account Created", description: "Your account has been successfully created." });
      return { success: true };

    } catch (error) {
      setError(error);
      let message = error.message;
      let isSignupDisabled = false;
      if (message.includes("already registered")) message = "Username is already taken.";
      if (message.includes("Signups not allowed")) {
         message = "Signups are currently disabled.";
         isSignupDisabled = true;
      }
      toast({ title: "Signup Failed", description: message, variant: "destructive" });
      return { success: false, error: message, isSignupDisabled };
    } finally {
      setLoading(false);
    }
  };

  const logout = async () => {
    setLoading(true);
    try {
      await supabase.auth.signOut();
      setUser(null);
      setSession(null);
      setHasAcceptedGuidelines(false);
    } catch (error) {
      console.error("Logout error:", error);
    } finally {
      setLoading(false);
    }
  };

  const refreshGuidelinesStatus = async () => {
    if (user?.id) {
       await checkGuidelinesAcceptance(user.id);
    }
  };

  const updateProfileEmail = async (newEmail) => {
    if (!user) return;
    try {
       const { error } = await supabase.from('profiles').update({ email: newEmail }).eq('id', user.id);
       if (error) throw error;
       setUser(prev => ({ ...prev, email: newEmail }));
       toast({ title: "Success", description: "Email updated successfully." });
    } catch (error) {
       toast({ title: "Error", description: "Could not update email.", variant: "destructive" });
    }
  };

  return (
    <AuthContext.Provider value={{ 
      user, 
      session, 
      loading, 
      error,
      isAuthenticated: !!session?.user,
      hasAcceptedGuidelines,
      login, 
      signup, 
      logout,
      refreshGuidelinesStatus,
      updateProfileEmail
    }}>
      {children}
    </AuthContext.Provider>
  );
};
