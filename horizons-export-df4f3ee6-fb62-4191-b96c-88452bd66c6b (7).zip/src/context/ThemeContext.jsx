
import React, { createContext, useContext, useState, useEffect, useMemo, useCallback } from 'react';
import { lightTheme, darkTheme, defaultCustomTheme } from '@/lib/themeColors';
import { presetThemes } from '@/lib/presetThemes';
import { supabase } from '@/lib/supabase';
import { useAuth } from '@/context/AuthContext';

const ThemeContext = createContext();

export const useTheme = () => useContext(ThemeContext);

export const ThemeProviderContext = ({ children }) => {
  const { user } = useAuth();
  const [themeMode, setThemeMode] = useState('light'); // light, dark, custom, preset
  const [customColors, setCustomColors] = useState(defaultCustomTheme);
  const [activeTheme, setActiveTheme] = useState(lightTheme);
  const [activePresetId, setActivePresetId] = useState(null);
  const [pawTrailColor, setPawTrailColor] = useState('#fb923c'); // Default orange

  // Load initial preferences
  useEffect(() => {
    const savedMode = localStorage.getItem('theme-mode');
    const savedCustomColors = localStorage.getItem('custom-theme-colors');
    const savedPresetId = localStorage.getItem('selectedPreset');

    if (savedCustomColors) {
      try {
        setCustomColors(JSON.parse(savedCustomColors));
      } catch (e) {
        console.error("Failed to parse custom colors", e);
      }
    }

    if (savedMode === 'preset' && savedPresetId) {
       applyPreset(savedPresetId, false);
    } else if (savedMode) {
      setThemeMode(savedMode);
    }

    // Attempt to load from profile if user is logged in
    if (user) {
       loadThemeFromProfile();
    }
  }, [user]);

  const loadThemeFromProfile = async () => {
    try {
       // Assuming 'theme_preference' jsonb column or similar exists/added to profiles
       // If not, we fallback to local storage which is already handled
       // For this implementation, we'll assume local storage is primary for immediate load
       // and profile sync happens in background
    } catch (e) {
       console.error("Error loading theme from profile", e);
    }
  };

  useEffect(() => {
    // Determine active theme object and paw color based on mode
    let current;
    let trailColor = '#fb923c'; // Default

    switch (themeMode) {
      case 'dark':
        current = darkTheme;
        trailColor = '#9333ea'; // Night/Dark -> Purple
        setActivePresetId(null);
        break;
      case 'custom':
        current = customColors;
        trailColor = customColors.accent_primary || '#fb923c';
        setActivePresetId(null);
        break;
      case 'preset':
        const preset = presetThemes.find(p => p.id === activePresetId);
        current = preset ? preset.colors : lightTheme;
        // Map presets to specific paw colors
        if (activePresetId === 'forest') trailColor = '#22c55e'; // Green
        else if (activePresetId === 'night') trailColor = '#9333ea'; // Purple
        else if (activePresetId === 'ocean') trailColor = '#3b82f6'; // Blue
        else trailColor = '#fb923c';
        break;
      case 'light':
      default:
        current = lightTheme;
        trailColor = '#fb923c';
        setActivePresetId(null);
        break;
    }

    setActiveTheme(current);
    setPawTrailColor(trailColor);
    localStorage.setItem('theme-mode', themeMode);
    
    // Apply CSS variables for global usage if needed
    document.documentElement.style.setProperty('--paw-trail-color', trailColor);

  }, [themeMode, customColors, activePresetId]);

  const updateCustomColors = useCallback((newColors) => {
    const updated = { ...customColors, ...newColors };
    setCustomColors(updated);
    localStorage.setItem('custom-theme-colors', JSON.stringify(updated));
    if (themeMode === 'custom') {
      setActiveTheme(updated);
    }
  }, [customColors, themeMode]);

  const resetCustomTheme = useCallback(() => {
    setCustomColors(defaultCustomTheme);
    localStorage.setItem('custom-theme-colors', JSON.stringify(defaultCustomTheme));
    if (themeMode === 'custom') {
      setActiveTheme(defaultCustomTheme);
    }
  }, [themeMode]);

  const applyPreset = useCallback((presetId, save = true) => {
    const preset = presetThemes.find(p => p.id === presetId);
    if (preset) {
      setActivePresetId(presetId);
      setThemeMode('preset');
      if (save) localStorage.setItem('selectedPreset', presetId);
    }
  }, []);

  const getPresetThemes = useCallback(() => presetThemes, []);

  const isPresetActive = useCallback((presetId) => themeMode === 'preset' && activePresetId === presetId, [themeMode, activePresetId]);

  const value = useMemo(() => ({
    themeMode,
    setThemeMode,
    customColors,
    updateCustomColors,
    resetCustomTheme,
    activeTheme,
    applyPreset,
    getPresetThemes,
    isPresetActive,
    activePresetId,
    pawTrailColor
  }), [
    themeMode, 
    customColors, 
    activeTheme, 
    activePresetId, 
    updateCustomColors, 
    resetCustomTheme, 
    applyPreset, 
    getPresetThemes, 
    isPresetActive,
    pawTrailColor
  ]);

  return (
    <ThemeContext.Provider value={value}>
      {children}
    </ThemeContext.Provider>
  );
};
