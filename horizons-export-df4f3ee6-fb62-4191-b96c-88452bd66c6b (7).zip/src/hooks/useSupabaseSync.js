
import { useState, useEffect } from 'react';
import { supabase } from '@/lib/supabase';
import { useAuth } from '@/context/AuthContext';

export const useSupabaseSync = () => {
  const { user } = useAuth();
  const [loading, setLoading] = useState(false);

  // Sync Feed
  const fetchFeed = async () => {
    const { data, error } = await supabase
      .from('feed_posts')
      .select('*, profiles:user_id(full_name, avatar_url, role)')
      .order('created_at', { ascending: false });
    return { data, error };
  };

  // Sync My Pets
  const fetchMyPets = async () => {
    if (!user) return { data: [] };
    const { data, error } = await supabase
      .from('pets')
      .select('*')
      .eq('owner_id', user.id);
    return { data, error };
  };

  // Sync Forum Threads
  const fetchForumThreads = async (category) => {
    let query = supabase
      .from('forum_threads')
      .select('*, profiles:author_id(full_name)')
      .order('created_at', { ascending: false });
    
    if (category) query = query.eq('category', category);
    
    const { data, error } = await query;
    return { data, error };
  };

  // Sync Reminders
  const fetchReminders = async () => {
    if (!user) return { data: [] };
    const { data, error } = await supabase
      .from('reminders')
      .select('*')
      .eq('user_id', user.id)
      .eq('is_completed', false)
      .order('due_date', { ascending: true });
    return { data, error };
  };

  return {
    fetchFeed,
    fetchMyPets,
    fetchForumThreads,
    fetchReminders,
    loading
  };
};
