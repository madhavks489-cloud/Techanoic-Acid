
import { useState, useEffect, useCallback } from 'react';
import { supabase } from '@/lib/supabase';
import { useLocationTracking } from '@/hooks/useLocationTracking';
import { calculateDistance } from '@/lib/locationUtils';

export const useUserSearch = () => {
  const [results, setResults] = useState([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);
  const { latitude: userLat, longitude: userLong } = useLocationTracking();

  const search = useCallback(async (query, filters = {}, sort = 'relevance') => {
    if (!query || query.trim().length < 2) {
      setResults([]);
      return;
    }

    setLoading(true);
    setError(null);

    try {
      const searchTerm = query.trim();
      
      // 1. Search Profiles (Name or Email) using 'profiles' table which maps to users
      const { data: profileMatches, error: profileError } = await supabase
        .from('profiles')
        .select('*, pets(*)')
        .or(`full_name.ilike.%${searchTerm}%,email.ilike.%${searchTerm}%`)
        .limit(50);

      if (profileError) throw profileError;

      // 2. Search Pets (Name) and get their owners
      const { data: petMatches, error: petError } = await supabase
        .from('pets')
        .select('owner_id')
        .ilike('name', `%${searchTerm}%`)
        .limit(50);

      if (petError) throw petError;

      // 3. Fetch owners from pet matches if they aren't already in profileMatches
      const existingIds = new Set(profileMatches.map(p => p.id));
      const newOwnerIds = [...new Set(petMatches.map(p => p.owner_id))].filter(id => !existingIds.has(id));

      let additionalProfiles = [];
      if (newOwnerIds.length > 0) {
        const { data: extraProfiles, error: extraError } = await supabase
          .from('profiles')
          .select('*, pets(*)')
          .in('id', newOwnerIds);
        
        if (extraError) throw extraError;
        additionalProfiles = extraProfiles;
      }

      // 4. Merge and Process Results
      let mergedResults = [...profileMatches, ...additionalProfiles];

      // 5. Apply Client-side Filters & Calculations
      mergedResults = mergedResults.map(profile => {
        let distance = null;
        if (userLat && userLong && profile.latitude && profile.longitude) {
          distance = calculateDistance(userLat, userLong, profile.latitude, profile.longitude);
        }
        return { ...profile, distance };
      });

      // Filter: Verified Vet
      if (filters.verifiedOnly) {
        mergedResults = mergedResults.filter(p => p.role === 'vet' || p.role === 'verified_vet');
      }

      // Filter: Radius
      if (filters.radius && userLat && userLong) {
        mergedResults = mergedResults.filter(p => p.distance !== null && p.distance <= parseFloat(filters.radius));
      }

      // Filter: Pet Type (if we had breed/type in search or filters, simplistic check here)
      if (filters.petType) {
         mergedResults = mergedResults.filter(p => 
           p.pets && p.pets.some(pet => pet.breed?.toLowerCase().includes(filters.petType.toLowerCase()))
         );
      }

      // 6. Sort
      mergedResults.sort((a, b) => {
        if (sort === 'distance') {
          if (a.distance === null) return 1;
          if (b.distance === null) return -1;
          return a.distance - b.distance;
        } else if (sort === 'name') {
          return (a.full_name || '').localeCompare(b.full_name || '');
        }
        // Default: Relevance
        return 0;
      });

      setResults(mergedResults);
    } catch (err) {
      console.error('Search error:', err);
      setError(err.message);
    } finally {
      setLoading(false);
    }
  }, [userLat, userLong]);

  return { results, loading, error, search };
};
