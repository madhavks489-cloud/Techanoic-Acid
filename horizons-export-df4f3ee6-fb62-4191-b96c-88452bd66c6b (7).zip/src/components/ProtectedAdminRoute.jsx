
import React from 'react';
import { Navigate } from 'react-router-dom';
import { useAuth } from '@/context/AuthContext';
import { useToast } from '@/components/ui/use-toast';

const ProtectedAdminRoute = ({ children }) => {
  const { user, loading } = useAuth();
  const { toast } = useToast();

  if (loading) return <div className="min-h-screen flex items-center justify-center">Loading...</div>;

  const isAdminOrMod = user && (user.role === 'admin' || user.role === 'moderator');

  if (!isAdminOrMod) {
    toast({
      title: "Access Denied",
      description: "You do not have permission to view this page.",
      variant: "destructive"
    });
    return <Navigate to="/dashboard" replace />;
  }

  return children;
};

export default ProtectedAdminRoute;
