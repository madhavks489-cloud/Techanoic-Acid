
import React from 'react';
import { motion } from 'framer-motion';
import { Star } from 'lucide-react';
import {
  Tooltip,
  TooltipContent,
  TooltipProvider,
  TooltipTrigger,
} from '@/components/ui/tooltip';

const VerifiedVetBadge = ({ name }) => {
  return (
    <TooltipProvider>
      <Tooltip>
        <TooltipTrigger>
          <motion.div 
            initial={{ scale: 0.8, opacity: 0 }}
            animate={{ scale: 1, opacity: 1 }}
            className="flex items-center gap-1 bg-yellow-50 text-[#D4AF37] px-2 py-1 rounded-full border border-[#D4AF37] text-xs font-semibold"
          >
            <Star className="w-3 h-3 fill-[#D4AF37]" />
            Verified Vet
          </motion.div>
        </TooltipTrigger>
        <TooltipContent className="bg-white text-gray-800 border-gray-200 shadow-lg">
          <p className="text-xs">
            {name || "This veterinarian"} has been verified by Paws & Pals
          </p>
        </TooltipContent>
      </Tooltip>
    </TooltipProvider>
  );
};

export default VerifiedVetBadge;
