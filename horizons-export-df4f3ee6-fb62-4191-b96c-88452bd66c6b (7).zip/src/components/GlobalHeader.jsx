
import React from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { motion } from 'framer-motion';
import { Search, Bell, Menu, PawPrint, Home, Compass, Heart, User, Dog } from 'lucide-react';
import { useAuth } from '@/context/AuthContext';
import { usePetTheme } from '@/context/PetThemeContext';
import PetButton from '@/components/ui/PetButton';
import PetInput from '@/components/ui/PetInput';

const GlobalHeader = () => {
  const { user } = useAuth();
  const { toggleSidePanel, playSound } = usePetTheme();
  const navigate = useNavigate();

  return (
    <motion.header 
      initial={{ y: -100 }}
      animate={{ y: 0 }}
      className="sticky top-0 z-40 bg-white/90 backdrop-blur-md border-b border-[var(--border-color)] shadow-sm px-4 py-3"
    >
      <div className="container mx-auto flex items-center justify-between gap-4">
        {/* Logo */}
        <Link to="/" onClick={() => playSound('click')} className="flex items-center gap-2 group">
          <motion.div 
            whileHover={{ rotate: 20 }}
            className="w-10 h-10 bg-[var(--accent-primary)] rounded-2xl flex items-center justify-center text-white shadow-lg"
          >
            <Dog className="w-6 h-6" />
          </motion.div>
          <span className="text-xl font-bold text-[var(--text-primary)] hidden md:block group-hover:text-[var(--accent-primary)] transition-colors">
            Paws & Pals
          </span>
        </Link>

        {/* Desktop Nav */}
        <nav className="hidden md:flex items-center gap-6">
          <Link to="/dashboard" className="nav-link flex items-center gap-1 text-[var(--text-secondary)] hover:text-[var(--accent-primary)] font-medium transition-colors">
            <Home className="w-4 h-4" /> Home
          </Link>
          <Link to="/adoption-centres" className="nav-link flex items-center gap-1 text-[var(--text-secondary)] hover:text-[var(--accent-primary)] font-medium transition-colors">
            <Heart className="w-4 h-4" /> Adopt
          </Link>
          <Link to="/qa" className="nav-link flex items-center gap-1 text-[var(--text-secondary)] hover:text-[var(--accent-primary)] font-medium transition-colors">
            <Compass className="w-4 h-4" /> Q&A
          </Link>
        </nav>

        {/* Search Bar */}
        <div className="hidden md:block flex-1 max-w-md mx-4">
           <PetInput 
             placeholder="Search for pets, friends, or tips..." 
             icon={Search}
             className="h-10 py-1"
           />
        </div>

        {/* Actions */}
        <div className="flex items-center gap-3">
          {user ? (
            <>
              <motion.button 
                whileHover={{ scale: 1.1 }}
                whileTap={{ scale: 0.9 }}
                className="p-2 text-[var(--text-secondary)] hover:text-[var(--accent-primary)] hover:bg-[var(--pet-cream)] rounded-full transition-colors relative"
              >
                <Bell className="w-5 h-5" />
                <span className="absolute top-1 right-1 w-2 h-2 bg-red-500 rounded-full border border-white"></span>
              </motion.button>
              
              <motion.div 
                whileHover={{ scale: 1.05 }}
                className="hidden md:block cursor-pointer"
                onClick={() => navigate('/dashboard')}
              >
                <div className="w-9 h-9 rounded-full bg-[var(--pet-blue-primary)] border-2 border-white shadow-sm overflow-hidden">
                  {user.avatar_url ? (
                    <img src={user.avatar_url} alt="User" className="w-full h-full object-cover" />
                  ) : (
                    <div className="w-full h-full flex items-center justify-center text-xs font-bold text-[var(--text-primary)]">
                      {user.full_name?.[0]}
                    </div>
                  )}
                </div>
              </motion.div>
            </>
          ) : (
            <Link to="/signin">
              <PetButton size="sm" className="py-2 h-9 text-sm">Sign In</PetButton>
            </Link>
          )}

          {/* Mobile Menu Toggle */}
          <motion.button 
            whileTap={{ scale: 0.9 }}
            onClick={toggleSidePanel}
            className="md:hidden p-2 text-[var(--text-primary)] hover:bg-[var(--pet-cream)] rounded-xl"
          >
            <Menu className="w-6 h-6" />
          </motion.button>
        </div>
      </div>
    </motion.header>
  );
};

export default GlobalHeader;
