
import React from 'react';
import { motion } from 'framer-motion';
import { cn } from '@/lib/utils';
import { usePetTheme } from '@/context/PetThemeContext';

const PetButton = ({ 
  children, 
  className, 
  variant = 'primary', 
  onClick, 
  icon: Icon, 
  isLoading,
  ...props 
}) => {
  const { playSound } = usePetTheme();

  const variants = {
    primary: "bg-[var(--accent-primary)] text-white hover:bg-[#8B9D77] shadow-lg shadow-[#9CAF88]/30",
    secondary: "bg-[var(--pet-blue-primary)] text-[#1a365d] hover:bg-[#90c0ff] shadow-lg shadow-[#B4D4FF]/30",
    outline: "border-2 border-[var(--accent-primary)] text-[var(--accent-primary)] hover:bg-[var(--accent-primary)] hover:text-white bg-transparent",
    ghost: "bg-transparent text-[var(--text-secondary)] hover:bg-[var(--pet-cream)]",
    danger: "bg-red-500 text-white hover:bg-red-600 shadow-lg shadow-red-500/30"
  };

  const handleClick = (e) => {
    playSound('click');
    if (onClick) onClick(e);
  };

  return (
    <motion.button
      whileHover={{ scale: 1.05, y: -2 }}
      whileTap={{ scale: 0.95 }}
      onClick={handleClick}
      disabled={isLoading}
      className={cn(
        "relative px-6 py-3 rounded-2xl font-semibold transition-all duration-200 flex items-center justify-center gap-2 overflow-hidden",
        variants[variant],
        isLoading && "opacity-70 cursor-not-allowed",
        className
      )}
      {...props}
    >
      {isLoading ? (
        <span className="animate-spin mr-2">🐾</span>
      ) : Icon ? (
        <Icon className="w-5 h-5" />
      ) : null}
      {children}
    </motion.button>
  );
};

export default PetButton;
