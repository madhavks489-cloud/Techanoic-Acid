
import * as React from "react"
import { cn } from "@/lib/utils"

const AvatarContext = React.createContext({ 
  imageState: 'loading', 
  setImageState: () => {} 
})

const Avatar = React.forwardRef(({ className, ...props }, ref) => {
  const [imageState, setImageState] = React.useState('loading')
  
  return (
    <AvatarContext.Provider value={{ imageState, setImageState }}>
      <div
        ref={ref}
        className={cn("relative flex h-10 w-10 shrink-0 overflow-hidden rounded-full", className)}
        {...props}
      />
    </AvatarContext.Provider>
  )
})
Avatar.displayName = "Avatar"

const AvatarImage = React.forwardRef(({ className, src, ...props }, ref) => {
  const { setImageState, imageState } = React.useContext(AvatarContext)

  React.useEffect(() => {
    if (!src) {
      setImageState('error')
      return
    }
    
    setImageState('loading')
    
    const img = new Image()
    img.src = src
    img.onload = () => setImageState('loaded')
    img.onerror = () => setImageState('error')
    
    return () => {
      img.onload = null
      img.onerror = null
    }
  }, [src, setImageState])

  if (imageState !== 'loaded') return null

  return (
    <img
      ref={ref}
      src={src}
      className={cn("aspect-square h-full w-full", className)}
      {...props}
    />
  )
})
AvatarImage.displayName = "AvatarImage"

const AvatarFallback = React.forwardRef(({ className, ...props }, ref) => {
  const { imageState } = React.useContext(AvatarContext)

  if (imageState === 'loaded') return null

  return (
    <div
      ref={ref}
      className={cn(
        "flex h-full w-full items-center justify-center rounded-full bg-muted",
        className
      )}
      {...props}
    />
  )
})
AvatarFallback.displayName = "AvatarFallback"

export { Avatar, AvatarImage, AvatarFallback }
