
import React from 'react';
import { motion } from 'framer-motion';
import { cn } from '@/lib/utils';
import { usePetTheme } from '@/context/PetThemeContext';

const PetCard = ({ children, className, onClick, ...props }) => {
  const { playSound } = usePetTheme();

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      whileHover={{ y: -5, boxShadow: 'var(--shadow-lift)' }}
      onMouseEnter={() => playSound('hover')}
      onClick={onClick}
      className={cn(
        "bg-white rounded-3xl p-5 border border-gray-100 shadow-[var(--shadow-soft)] transition-colors",
        "relative overflow-hidden",
        className
      )}
      {...props}
    >
      {/* Decorative background paw (subtle) */}
      <div className="absolute -right-4 -top-4 text-[var(--pet-cream)] opacity-50 pointer-events-none transform rotate-12">
        <svg width="100" height="100" viewBox="0 0 24 24" fill="currentColor">
          <path d="M12 2C10.5 2 9.2 3.1 9 4.6L9 5L8.9 5C7.3 5 6 6.3 6 8C6 9.7 7.3 11 9 11C10.7 11 12 9.7 12 8C12 6.3 10.7 5 9 5C9.2 3.5 10.5 2.4 12 2.4C13.5 2.4 14.8 3.5 15 5C13.3 5 12 6.3 12 8C12 9.7 13.3 11 15 11C16.7 11 18 9.7 18 8C18 6.3 16.7 5 15.1 5L15 5L15 4.6C14.8 3.1 13.5 2 12 2M5 13C3.3 13 2 14.3 2 16C2 17.7 3.3 19 5 19C6.7 19 8 17.7 8 16C8 14.3 6.7 13 5 13M19 13C17.3 13 16 14.3 16 16C16 17.7 17.3 19 19 19C20.7 19 22 17.7 22 16C22 14.3 20.7 13 19 13M12 14C10 14 8 16 8 18.5C8 20.2 9.3 22 12 22C14.7 22 16 20.2 16 18.5C16 16 14 14 12 14Z" />
        </svg>
      </div>
      
      <div className="relative z-10">
        {children}
      </div>
    </motion.div>
  );
};

export default PetCard;
