
import React, { useEffect, useRef } from 'react';
import { usePetTheme } from '@/context/PetThemeContext';
import { useTheme } from '@/context/ThemeContext';

const PawCursorTrail = () => {
  const { cursorTrailEnabled } = usePetTheme();
  const { pawTrailColor } = useTheme();
  const canvasRef = useRef(null);
  const paws = useRef([]);
  const requestRef = useRef();

  useEffect(() => {
    if (!cursorTrailEnabled) return;

    const canvas = canvasRef.current;
    if (!canvas) return;
    
    const ctx = canvas.getContext('2d');
    
    const setSize = () => {
      canvas.width = window.innerWidth;
      canvas.height = window.innerHeight;
    };
    
    setSize();
    window.addEventListener('resize', setSize);

    const handleMouseMove = (e) => {
      // Limit number of paws on screen
      if (paws.current.length > 15) {
        paws.current.shift(); // Remove oldest
      }

      paws.current.push({
        x: e.clientX,
        y: e.clientY,
        alpha: 1,
        scale: 0.5, // Start small
        maxScale: Math.random() * 0.5 + 0.8, // Target scale
        rotation: Math.random() * 360,
        color: pawTrailColor // Capture current color at creation time
      });
    };

    const animate = () => {
      if (!ctx || !canvas) return;
      ctx.clearRect(0, 0, canvas.width, canvas.height);

      for (let i = 0; i < paws.current.length; i++) {
        const paw = paws.current[i];
        
        ctx.save();
        ctx.translate(paw.x, paw.y);
        ctx.rotate((paw.rotation * Math.PI) / 180);
        ctx.scale(paw.scale, paw.scale);
        ctx.globalAlpha = paw.alpha;
        ctx.fillStyle = paw.color;
        
        // Draw Paw
        ctx.beginPath();
        // Main pad
        ctx.ellipse(0, 0, 10, 8, 0, 0, Math.PI * 2);
        // Toes
        ctx.ellipse(-10, -12, 4, 5, -0.4, 0, Math.PI * 2);
        ctx.ellipse(0, -18, 4, 5, 0, 0, Math.PI * 2);
        ctx.ellipse(10, -12, 4, 5, 0.4, 0, Math.PI * 2);
        ctx.fill();
        
        ctx.restore();

        // Animation logic
        if (paw.scale < paw.maxScale) {
            paw.scale += 0.05; // Pulsate/Grow effect
        }
        
        paw.alpha -= 0.015; // Fade out
      }

      // Remove invisible paws
      paws.current = paws.current.filter(p => p.alpha > 0);
      requestRef.current = requestAnimationFrame(animate);
    };

    window.addEventListener('mousemove', handleMouseMove);
    requestRef.current = requestAnimationFrame(animate);

    return () => {
      window.removeEventListener('mousemove', handleMouseMove);
      window.removeEventListener('resize', setSize);
      cancelAnimationFrame(requestRef.current);
    };
  }, [cursorTrailEnabled, pawTrailColor]);

  if (!cursorTrailEnabled) return null;

  return (
    <canvas 
      ref={canvasRef} 
      className="fixed inset-0 pointer-events-none z-[9999]" 
      style={{ touchAction: 'none' }}
    />
  );
};

export default PawCursorTrail;
