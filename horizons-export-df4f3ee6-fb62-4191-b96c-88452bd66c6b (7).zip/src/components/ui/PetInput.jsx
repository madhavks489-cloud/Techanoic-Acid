
import React from 'react';
import { cn } from '@/lib/utils';

const PetInput = React.forwardRef(({ className, icon: Icon, ...props }, ref) => {
  return (
    <div className="relative group">
      {Icon && (
        <div className="absolute left-3 top-1/2 -translate-y-1/2 text-[var(--text-secondary)] group-focus-within:text-[var(--accent-primary)] transition-colors">
          <Icon className="w-5 h-5" />
        </div>
      )}
      <input
        ref={ref}
        className={cn(
          "w-full bg-white border-2 border-transparent focus:border-[var(--accent-primary)] rounded-xl px-4 py-3 text-[var(--text-primary)] placeholder-[var(--text-light)] shadow-sm outline-none transition-all duration-200",
          "hover:shadow-md",
          Icon && "pl-11",
          className
        )}
        style={{ backgroundColor: 'var(--input-bg)' }}
        {...props}
      />
    </div>
  );
});

PetInput.displayName = "PetInput";
export default PetInput;
