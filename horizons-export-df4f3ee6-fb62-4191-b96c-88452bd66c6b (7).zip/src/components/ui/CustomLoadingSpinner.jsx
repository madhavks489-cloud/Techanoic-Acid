
import React from 'react';
import { motion } from 'framer-motion';
import { useTheme } from '@/context/ThemeContext';

const CustomLoadingSpinner = ({ size = "medium", text = "Fetching treats..." }) => {
  const { activeTheme, themeMode } = useTheme();
  
  const sizeMap = {
    small: "scale-50",
    medium: "scale-100",
    large: "scale-150"
  };

  const containerHeight = {
    small: "h-24",
    medium: "h-40",
    large: "h-60"
  };
  
  // Use theme colors
  const catColor = themeMode === 'dark' ? '#d1d5db' : '#4b5563'; // Gray-300 vs Gray-600
  const ballColor = activeTheme.accent_primary || '#fb923c';

  return (
    <div className={`flex flex-col items-center justify-center w-full ${containerHeight[size]} transition-all duration-300`}>
      <div className={`relative w-24 h-24 ${sizeMap[size]}`}>
        {/* Cat Container - Rotating */}
        <motion.div
           className="w-full h-full absolute top-0 left-0"
           animate={{ rotate: 360 }}
           transition={{ duration: 2, repeat: Infinity, ease: "linear" }}
        >
            {/* The Cat Sprite */}
            <svg 
                viewBox="0 0 100 100" 
                className="w-full h-full absolute -top-4"
                style={{ filter: 'drop-shadow(0px 2px 2px rgba(0,0,0,0.1))' }}
            >
                {/* Simplified Cat Shape */}
                <g transform="translate(50, 20)">
                    <path 
                        d="M-15 10 Q 0 -5 15 10 L 15 30 Q 0 40 -15 30 Z" 
                        fill={catColor} 
                    />
                    {/* Ears */}
                    <path d="M-12 10 L -18 -5 L -5 5 Z" fill={catColor} />
                    <path d="M12 10 L 18 -5 L 5 5 Z" fill={catColor} />
                    {/* Tail */}
                    <path d="M-10 30 Q -25 40 -20 20" stroke={catColor} strokeWidth="4" fill="none" />
                </g>
            </svg>
        </motion.div>

        {/* Cotton Ball - Rotating opposite or with delay */}
        <motion.div
           className="absolute top-1/2 left-1/2 w-4 h-4 rounded-full shadow-sm"
           style={{ 
               backgroundColor: ballColor,
               top: '50%',
               left: '50%',
               marginTop: '-8px',
               marginLeft: '-8px'
           }}
           animate={{ 
               x: [0, 30, 0, -30, 0],
               y: [0, -30, 0, 30, 0],
           }}
           transition={{ 
               duration: 2, 
               repeat: Infinity, 
               ease: "linear",
               times: [0, 0.25, 0.5, 0.75, 1]
           }}
        />
      </div>
      
      {text && (
        <motion.p 
            initial={{ opacity: 0.5 }}
            animate={{ opacity: 1 }}
            transition={{ duration: 0.8, repeat: Infinity, repeatType: "reverse" }}
            className="mt-2 text-sm font-medium font-poppins"
            style={{ color: activeTheme.text_secondary }}
        >
            {text}
        </motion.p>
      )}
    </div>
  );
};

export default CustomLoadingSpinner;
