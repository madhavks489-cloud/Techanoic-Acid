
import React, { useState, useEffect, useRef } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Camera, Plus, Image as ImageIcon, X } from 'lucide-react';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { useToast } from '@/components/ui/use-toast';
import { useAuth } from '@/context/AuthContext';
import { supabase } from '@/lib/supabase';
import FeedPost from '@/components/FeedPost';
import PetButton from '@/components/ui/PetButton';
import PetCard from '@/components/ui/PetCard';
import PetInput from '@/components/ui/PetInput';
import CustomLoadingSpinner from '@/components/ui/CustomLoadingSpinner';
import { useTheme } from '@/context/ThemeContext';

const Feed = () => {
  const [posts, setPosts] = useState([]);
  const [loading, setLoading] = useState(true);
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const [newPostContent, setNewPostContent] = useState('');
  
  const [selectedFile, setSelectedFile] = useState(null);
  const [previewUrl, setPreviewUrl] = useState(null);
  const [uploading, setUploading] = useState(false);
  const fileInputRef = useRef(null);

  const { user } = useAuth();
  const { toast } = useToast();
  const { activeTheme } = useTheme();

  useEffect(() => {
    fetchPosts();

    const channel = supabase
      .channel('public:feed_posts')
      .on('postgres_changes', { event: '*', schema: 'public', table: 'feed_posts' }, (payload) => {
        if (payload.eventType === 'INSERT') {
          fetchSinglePost(payload.new.id).then(post => {
            if (post) setPosts(prev => [post, ...prev]);
          });
        } else if (payload.eventType === 'DELETE') {
          setPosts(prev => prev.filter(p => p.id !== payload.old.id));
        }
      })
      .subscribe();

    return () => supabase.removeChannel(channel);
  }, []);

  const fetchSinglePost = async (id) => {
    const { data } = await supabase
      .from('feed_posts')
      .select('*, profiles:user_id(full_name, avatar_url, role), pets:pet_id(name, breed, photo_url), post_likes(user_id)')
      .eq('id', id)
      .single();
    return data;
  };

  const fetchPosts = async () => {
    setLoading(true);
    const { data, error } = await supabase
      .from('feed_posts')
      .select('*, profiles:user_id(full_name, avatar_url, role), pets:pet_id(name, breed, photo_url), post_likes(user_id)')
      .order('created_at', { ascending: false });

    if (error) {
      console.error("Feed error:", error);
      toast({ title: "Error", description: "Failed to load feed", variant: "destructive" });
    } else {
      setPosts(data || []);
    }
    setLoading(false);
  };

  const handleFileSelect = (e) => {
    const file = e.target.files[0];
    if (file) {
      if (!['image/jpeg', 'image/png', 'image/webp'].includes(file.type)) {
        toast({ title: "Invalid file type", description: "Please select a JPG, PNG, or WebP image.", variant: "destructive" });
        return;
      }
      setSelectedFile(file);
      setPreviewUrl(URL.createObjectURL(file));
    }
  };

  const clearFile = () => {
    setSelectedFile(null);
    setPreviewUrl(null);
    if (fileInputRef.current) fileInputRef.current.value = '';
  };

  const handleCreatePost = async () => {
    if (!newPostContent.trim() && !selectedFile) {
      toast({ title: "Empty Post", description: "Please add some text or an image.", variant: "destructive" });
      return;
    }

    setUploading(true);
    let imageUrl = null;

    try {
      if (selectedFile) {
        const fileExt = selectedFile.name.split('.').pop();
        const fileName = `${Math.random()}.${fileExt}`;
        const filePath = `${user.id}/${fileName}`;

        const { error: uploadError } = await supabase.storage
          .from('pet_photos')
          .upload(filePath, selectedFile);

        if (uploadError) throw uploadError;

        const { data: publicUrlData } = supabase.storage
          .from('pet_photos')
          .getPublicUrl(filePath);
          
        imageUrl = publicUrlData.publicUrl;
      }

      const { data: pets } = await supabase.from('pets').select('id').eq('owner_id', user.id).limit(1);
      const petId = pets?.[0]?.id;

      let postType = 'text';
      if (imageUrl) {
        postType = 'image';
      }

      const payload = {
        user_id: user.id,
        pet_id: petId,
        type: postType, 
        content: newPostContent,
        image_url: imageUrl,
      };

      const { error } = await supabase.from('feed_posts').insert(payload);

      if (error) throw error;

      toast({ title: "Success", description: "Post created!" });
      setNewPostContent('');
      clearFile();
      setIsDialogOpen(false);

    } catch (error) {
      console.error(error);
      toast({ title: "Error", description: error.message || "Failed to create post", variant: "destructive" });
    } finally {
      setUploading(false);
    }
  };

  return (
    <div className="container mx-auto px-4 py-8 max-w-2xl min-h-[60vh]">
      <div className="flex justify-between items-center mb-8">
        <motion.h1
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          className="text-3xl font-bold font-poppins"
          style={{ color: activeTheme.text_primary }}
        >
          Your Feed
        </motion.h1>
        
        <Dialog open={isDialogOpen} onOpenChange={(open) => {
          if (!open) clearFile();
          setIsDialogOpen(open);
        }}>
          <DialogTrigger asChild>
            <PetButton icon={Plus}>New Post</PetButton>
          </DialogTrigger>
          <DialogContent 
            className="sm:max-w-md border-none shadow-2xl rounded-3xl"
            style={{ backgroundColor: activeTheme.bg_primary }}
          >
            <DialogHeader>
              <DialogTitle className="text-xl font-bold" style={{ color: activeTheme.text_primary }}>Create New Post</DialogTitle>
            </DialogHeader>
            <div className="space-y-4 pt-4">
              <textarea
                value={newPostContent}
                onChange={(e) => setNewPostContent(e.target.value)}
                placeholder="What's on your pet's mind?"
                className="w-full h-32 p-4 border rounded-xl resize-none focus:ring-2 outline-none"
                style={{ 
                    backgroundColor: activeTheme.bg_secondary, 
                    color: activeTheme.text_primary, 
                    borderColor: activeTheme.border_color,
                    '--tw-ring-color': activeTheme.accent_primary
                }}
              />

              <AnimatePresence>
                {previewUrl && (
                  <motion.div 
                    initial={{ opacity: 0, scale: 0.9 }}
                    animate={{ opacity: 1, scale: 1 }}
                    exit={{ opacity: 0, scale: 0.9 }}
                    className="relative rounded-xl overflow-hidden shadow-md"
                  >
                    <img src={previewUrl} alt="Preview" className="w-full h-48 object-cover" />
                    <button 
                      onClick={clearFile}
                      className="absolute top-2 right-2 p-1 bg-black/50 rounded-full text-white hover:bg-black/70 transition-colors"
                    >
                      <X className="w-4 h-4" />
                    </button>
                  </motion.div>
                )}
              </AnimatePresence>

              <div className="flex items-center gap-2">
                 <input 
                   type="file" 
                   ref={fileInputRef}
                   onChange={handleFileSelect}
                   accept="image/jpeg,image/png,image/webp"
                   className="hidden"
                   id="image-upload"
                 />
                 <label 
                   htmlFor="image-upload" 
                   className="flex items-center gap-2 text-sm cursor-pointer transition-colors p-3 rounded-xl border border-dashed w-full justify-center group"
                   style={{ 
                       color: activeTheme.text_secondary, 
                       borderColor: activeTheme.border_color,
                       backgroundColor: activeTheme.bg_secondary 
                   }}
                 >
                   <ImageIcon className="w-5 h-5 group-hover:scale-110 transition-transform" />
                   Add Photo
                 </label>
              </div>

              <PetButton onClick={handleCreatePost} isLoading={uploading} className="w-full">
                Post Update
              </PetButton>
            </div>
          </DialogContent>
        </Dialog>
      </div>

      {loading ? (
        <CustomLoadingSpinner size="large" />
      ) : posts.length === 0 ? (
        <PetCard className="text-center py-12">
           <div className="w-20 h-20 rounded-full flex items-center justify-center mx-auto mb-4 animate-float" style={{ backgroundColor: activeTheme.bg_secondary }}>
             <Camera className="w-10 h-10" style={{ color: activeTheme.accent_primary }} />
           </div>
           <h3 className="text-xl font-bold mb-2" style={{ color: activeTheme.text_primary }}>No posts yet</h3>
           <p className="max-w-xs mx-auto" style={{ color: activeTheme.text_secondary }}>
             Be the first to share a photo of your furry friend!
           </p>
        </PetCard>
      ) : (
        <div className="space-y-6">
          {posts.map(post => (
             <FeedPost key={post.id} post={post} currentUser={user} />
          ))}
        </div>
      )}
    </div>
  );
};

export default Feed;
