
import React from 'react';
import { Clock, X } from 'lucide-react';
import { useTheme } from '@/context/ThemeContext';
import { motion, AnimatePresence } from 'framer-motion';

const SearchHistory = ({ onSelect, history, onClear, onRemoveItem }) => {
  const { activeTheme } = useTheme();

  if (!history || history.length === 0) return null;

  return (
    <div className="w-full mt-2">
      <div className="flex items-center justify-between mb-2 px-2">
        <span 
          className="text-xs font-semibold uppercase tracking-wider"
          style={{ color: activeTheme.text_secondary }}
        >
          Recent Searches
        </span>
        <button
          onClick={onClear}
          className="text-xs hover:underline"
          style={{ color: activeTheme.accent_primary }}
        >
          Clear All
        </button>
      </div>
      <div className="flex flex-col gap-1">
        <AnimatePresence>
          {history.map((item, index) => (
            <motion.div
              key={`${item}-${index}`}
              initial={{ opacity: 0, height: 0 }}
              animate={{ opacity: 1, height: 'auto' }}
              exit={{ opacity: 0, height: 0 }}
              className="group flex items-center justify-between p-2 rounded-md cursor-pointer transition-colors"
              style={{ backgroundColor: activeTheme.bg_secondary }}
              onClick={() => onSelect(item)}
            >
              <div className="flex items-center gap-3">
                <Clock size={14} style={{ color: activeTheme.text_secondary }} />
                <span className="text-sm" style={{ color: activeTheme.text_primary }}>{item}</span>
              </div>
              <button
                onClick={(e) => {
                  e.stopPropagation();
                  onRemoveItem(item);
                }}
                className="opacity-0 group-hover:opacity-100 p-1 rounded-full hover:bg-black/5 dark:hover:bg-white/10 transition-all"
              >
                <X size={14} style={{ color: activeTheme.text_secondary }} />
              </button>
            </motion.div>
          ))}
        </AnimatePresence>
      </div>
    </div>
  );
};

export default SearchHistory;
