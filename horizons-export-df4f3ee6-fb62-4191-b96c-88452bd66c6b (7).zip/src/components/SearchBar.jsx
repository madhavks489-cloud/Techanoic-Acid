
import React, { useState, useEffect, useRef } from 'react';
import { Search, X, Loader2 } from 'lucide-react';
import { useTheme } from '@/context/ThemeContext';
import SearchHistory from './SearchHistory';

const SearchHistoryManager = () => {
  const getHistory = () => {
    try {
      return JSON.parse(localStorage.getItem('search_history') || '[]');
    } catch {
      return [];
    }
  };

  const addToHistory = (term) => {
    if (!term) return;
    const current = getHistory();
    const newHistory = [term, ...current.filter(t => t !== term)].slice(0, 5);
    localStorage.setItem('search_history', JSON.stringify(newHistory));
    return newHistory;
  };

  const clearHistory = () => {
    localStorage.removeItem('search_history');
    return [];
  };

  const removeFromHistory = (term) => {
    const current = getHistory();
    const newHistory = current.filter(t => t !== term);
    localStorage.setItem('search_history', JSON.stringify(newHistory));
    return newHistory;
  };

  return { getHistory, addToHistory, clearHistory, removeFromHistory };
};

const SearchBar = ({ onSearch, loading, placeholder = "Search users, pets..." }) => {
  const { activeTheme } = useTheme();
  const [query, setQuery] = useState('');
  const [isFocused, setIsFocused] = useState(false);
  const [history, setHistory] = useState([]);
  const historyManager = useRef(SearchHistoryManager());
  
  // Debounce logic
  useEffect(() => {
    const timer = setTimeout(() => {
      if (query) {
        onSearch(query);
        if (query.length > 2) {
             const newHistory = historyManager.current.addToHistory(query);
             setHistory(newHistory);
        }
      } else {
        onSearch('');
      }
    }, 300);

    return () => clearTimeout(timer);
  }, [query, onSearch]);

  // Load history on mount
  useEffect(() => {
    setHistory(historyManager.current.getHistory());
  }, []);

  const handleClear = () => {
    setQuery('');
    onSearch('');
  };

  const handleHistorySelect = (term) => {
    setQuery(term);
    // Instant search on click
    onSearch(term);
  };

  const handleClearHistory = () => {
    const newHistory = historyManager.current.clearHistory();
    setHistory(newHistory);
  };
  
  const handleRemoveHistoryItem = (term) => {
    const newHistory = historyManager.current.removeFromHistory(term);
    setHistory(newHistory);
  };

  return (
    <div className="w-full relative z-20">
      <div 
        className={`relative flex items-center w-full rounded-xl transition-all duration-300 border ${isFocused ? 'ring-2' : ''}`}
        style={{
          backgroundColor: activeTheme.bg_secondary,
          borderColor: isFocused ? activeTheme.accent_primary : 'transparent',
          color: activeTheme.text_primary
        }}
      >
        <div className="pl-3 py-3">
          {loading ? (
            <Loader2 className="animate-spin w-5 h-5" style={{ color: activeTheme.text_secondary }} />
          ) : (
            <Search className="w-5 h-5" style={{ color: activeTheme.text_secondary }} />
          )}
        </div>
        
        <input
          type="text"
          value={query}
          onChange={(e) => setQuery(e.target.value)}
          onFocus={() => setIsFocused(true)}
          onBlur={() => setTimeout(() => setIsFocused(false), 200)} // Delay to allow click on history
          placeholder={placeholder}
          className="w-full bg-transparent border-none outline-none px-3 py-3 text-sm"
          style={{ color: activeTheme.text_primary }} 
        />
        
        {query && (
          <button 
            onClick={handleClear}
            className="pr-3 py-2"
          >
            <X className="w-4 h-4" style={{ color: activeTheme.text_secondary }} />
          </button>
        )}
      </div>

      {isFocused && !query && history.length > 0 && (
        <div 
          className="absolute top-full left-0 right-0 mt-2 p-2 rounded-xl shadow-xl border"
          style={{
            backgroundColor: activeTheme.bg_primary,
            borderColor: activeTheme.border_color
          }}
        >
          <SearchHistory 
            history={history} 
            onSelect={handleHistorySelect}
            onClear={handleClearHistory}
            onRemoveItem={handleRemoveHistoryItem}
          />
        </div>
      )}
    </div>
  );
};

export default SearchBar;
