
import React, { useState } from 'react';
import { ArrowLeft, Camera, Save } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { useToast } from '@/components/ui/use-toast';
import { useAuth } from '@/context/AuthContext';
import { supabase } from '@/lib/supabase';

const AddPetPage = ({ onBack }) => {
  const [name, setName] = useState('');
  const [breed, setBreed] = useState('');
  const [age, setAge] = useState('');
  const [loading, setLoading] = useState(false);
  const { toast } = useToast();
  const { user } = useAuth();

  const handleSubmit = async (e) => {
    e.preventDefault();
    setLoading(true);
    
    try {
      const { error } = await supabase.from('pets').insert({
        name,
        breed,
        age,
        photo_url: 'https://images.unsplash.com/photo-1543466835-00a7907e9de1', // Static for demo
        owner_id: user.id
      });

      if (error) throw error;

      toast({ title: "Success!", description: `${name} has been added.` });
      onBack();
    } catch (error) {
      toast({ title: "Error", description: error.message, variant: "destructive" });
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="container mx-auto px-4 py-6 max-w-md">
      <button onClick={onBack} className="flex items-center gap-2 mb-6 text-gray-600">
        <ArrowLeft className="w-5 h-5" /> Back
      </button>

      <h1 className="text-2xl font-bold mb-6 text-gray-900">Add New Pet</h1>

      <form onSubmit={handleSubmit} className="space-y-6">
        <div className="bg-gray-50 h-48 rounded-xl flex flex-col items-center justify-center border-2 border-dashed border-gray-300 cursor-pointer hover:bg-gray-100 transition">
          <Camera className="w-8 h-8 text-gray-400 mb-2" />
          <span className="text-sm text-gray-500">Upload Photo (Demo: Static)</span>
        </div>

        <div>
          <label className="block text-sm font-medium mb-1 text-gray-700">Pet Name</label>
          <input 
            required
            value={name}
            onChange={e => setName(e.target.value)}
            className="w-full p-3 rounded-lg border border-gray-200 focus:ring-2 focus:ring-[#9CAF88] outline-none"
          />
        </div>

        <div>
          <label className="block text-sm font-medium mb-1 text-gray-700">Breed</label>
          <input 
            required
            value={breed}
            onChange={e => setBreed(e.target.value)}
            className="w-full p-3 rounded-lg border border-gray-200 focus:ring-2 focus:ring-[#9CAF88] outline-none"
          />
        </div>

        <div>
          <label className="block text-sm font-medium mb-1 text-gray-700">Age</label>
          <input 
            required
            value={age}
            onChange={e => setAge(e.target.value)}
            placeholder="e.g. 2 years"
            className="w-full p-3 rounded-lg border border-gray-200 focus:ring-2 focus:ring-[#9CAF88] outline-none"
          />
        </div>

        <Button type="submit" disabled={loading} className="w-full py-6 text-lg bg-[#9CAF88] hover:bg-[#8b9c79] text-white">
          {loading ? 'Saving...' : <><Save className="w-5 h-5 mr-2" /> Save Pet</>}
        </Button>
      </form>
    </div>
  );
};

export default AddPetPage;
