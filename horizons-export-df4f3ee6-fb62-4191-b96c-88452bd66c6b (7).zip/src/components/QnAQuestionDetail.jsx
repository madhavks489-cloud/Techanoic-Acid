
import React, { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { useAuth } from '@/context/AuthContext';
import { useTheme } from '@/context/ThemeContext';
import { supabase } from '@/lib/supabase';
import { Button } from '@/components/ui/button';
import { useToast } from '@/components/ui/use-toast';
import { ArrowLeft, ThumbsUp, ThumbsDown, Trash2, ShieldAlert } from 'lucide-react';
import { motion } from 'framer-motion';
import QnAAnswerForm from './QnAAnswerForm';
import VerifiedVetBadge from './VerifiedVetBadge';
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";

const QnAQuestionDetail = () => {
  const { id } = useParams();
  const navigate = useNavigate();
  const { user } = useAuth();
  const { activeTheme } = useTheme();
  const { toast } = useToast();
  
  const [question, setQuestion] = useState(null);
  const [answers, setAnswers] = useState([]);
  const [loading, setLoading] = useState(true);
  const [deleteItem, setDeleteItem] = useState(null); // { type: 'question' | 'answer', id: string }

  const isModerator = user?.role === 'admin' || user?.role === 'moderator';

  useEffect(() => {
    fetchQuestionData();

    const answersSub = supabase.channel(`question_answers:${id}`)
      .on('postgres_changes', { 
        event: '*', 
        schema: 'public', 
        table: 'qa_answers',
        filter: `question_id=eq.${id}`
      }, () => {
        fetchAnswers();
      })
      .subscribe();

    return () => supabase.removeChannel(answersSub);
  }, [id]);

  const fetchQuestionData = async () => {
    setLoading(true);
    // Fetch question
    const { data: qData, error: qError } = await supabase
      .from('qa_questions')
      .select('*, profiles:user_id(full_name, role, avatar_url)')
      .eq('id', id)
      .single();

    if (qError) {
      console.error('Error fetching question:', qError);
      setLoading(false);
      return;
    }

    setQuestion(qData);
    await fetchAnswers();
    setLoading(false);
  };

  const fetchAnswers = async () => {
    const { data: aData, error: aError } = await supabase
      .from('qa_answers')
      .select('*, profiles:user_id(full_name, role, avatar_url)')
      .eq('question_id', id)
      .order('upvotes', { ascending: false });

    if (!aError) {
        // Check user votes for these answers
        if (user) {
            const answerIds = aData.map(a => a.id);
            const { data: vData } = await supabase
                .from('qa_votes')
                .select('answer_id, vote_type')
                .eq('user_id', user.id)
                .in('answer_id', answerIds);
            
            const votesMap = {};
            vData?.forEach(v => votesMap[v.answer_id] = v.vote_type);
            
            const answersWithVotes = aData.map(a => ({
                ...a,
                userVote: votesMap[a.id]
            }));
            setAnswers(answersWithVotes);
        } else {
            setAnswers(aData);
        }
    }
  };

  const handleVote = async (answerId, type) => {
      if (!user) {
          toast({ title: "Please sign in to vote" });
          return;
      }
      
      const currentAnswer = answers.find(a => a.id === answerId);
      const existingVote = currentAnswer.userVote;

      try {
          if (existingVote === type) {
              // Remove vote
              await supabase.from('qa_votes').delete().match({ answer_id: answerId, user_id: user.id });
              // Update local counts optimistically
              setAnswers(prev => prev.map(a => {
                  if (a.id === answerId) {
                      return {
                          ...a,
                          userVote: null,
                          upvotes: type === 'upvote' ? a.upvotes - 1 : a.upvotes,
                          downvotes: type === 'downvote' ? a.downvotes - 1 : a.downvotes
                      };
                  }
                  return a;
              }));
          } else {
              // Insert or Update vote
              if (existingVote) {
                   // Remove old vote first from UI perspective
                   await supabase.from('qa_votes').delete().match({ answer_id: answerId, user_id: user.id });
              }
              
              await supabase.from('qa_votes').insert({
                  answer_id: answerId,
                  user_id: user.id,
                  vote_type: type
              });

              // Update local counts optimistically
              setAnswers(prev => prev.map(a => {
                  if (a.id === answerId) {
                      let newUp = a.upvotes;
                      let newDown = a.downvotes;
                      
                      if (existingVote === 'upvote') newUp--;
                      if (existingVote === 'downvote') newDown--;
                      
                      if (type === 'upvote') newUp++;
                      if (type === 'downvote') newDown++;

                      return {
                          ...a,
                          userVote: type,
                          upvotes: newUp,
                          downvotes: newDown
                      };
                  }
                  return a;
              }));
          }
          
          // Re-sync with server to ensure consistency
          // Note: In a real app, we'd use RPC for atomic updates, but for now we rely on refetching or simple updates
          const { error } = await supabase.rpc('handle_vote', { 
              p_answer_id: answerId, 
              p_user_id: user.id, 
              p_vote_type: type 
          }).catch(() => {}); // If RPC doesn't exist, we skip. Votes table is source of truth.
          
      } catch (err) {
          console.error("Voting error", err);
      }
  };

  const confirmDelete = async () => {
    if (!deleteItem) return;

    try {
      if (deleteItem.type === 'question') {
        await supabase.from('qa_questions').delete().eq('id', deleteItem.id);
        
        // Log admin action if applicable
        if (isModerator && user.id !== question.user_id) {
            await supabase.from('admin_actions').insert({
                admin_id: user.id,
                action_type: 'DELETE_QUESTION',
                target_id: deleteItem.id,
                target_type: 'qa_questions',
                reason: 'Content moderation'
            });
        }
        
        toast({ title: "Question deleted" });
        navigate('/qa');
      } else {
        await supabase.from('qa_answers').delete().eq('id', deleteItem.id);
        
        // Log admin action if applicable
        const answer = answers.find(a => a.id === deleteItem.id);
        if (isModerator && answer && user.id !== answer.user_id) {
             await supabase.from('admin_actions').insert({
                admin_id: user.id,
                action_type: 'DELETE_ANSWER',
                target_id: deleteItem.id,
                target_type: 'qa_answers',
                reason: 'Content moderation'
            });
        }

        setAnswers(prev => prev.filter(a => a.id !== deleteItem.id));
        toast({ title: "Answer deleted" });
      }
    } catch (error) {
      toast({ title: "Error deleting item", variant: "destructive" });
    } finally {
      setDeleteItem(null);
    }
  };

  if (loading) return <div className="p-8 flex justify-center"><div className="animate-spin rounded-full h-8 w-8 border-b-2 border-gray-900"></div></div>;
  if (!question) return <div className="p-8 text-center">Question not found</div>;

  return (
    <div className="min-h-screen pb-20" style={{ backgroundColor: activeTheme.bg_secondary }}>
      <div className="container mx-auto px-4 py-6 max-w-4xl">
        <Button variant="ghost" className="mb-4 pl-0" onClick={() => navigate('/qa')}>
          <ArrowLeft className="w-5 h-5 mr-2" /> Back to Q&A
        </Button>

        {/* Question Card */}
        <div className="bg-white rounded-xl p-6 shadow-sm border mb-6" style={{ borderColor: activeTheme.border_color }}>
          <div className="flex justify-between items-start mb-4">
             <span className="text-xs font-bold px-2 py-1 rounded bg-gray-100 text-gray-600">{question.category}</span>
             {(user?.id === question.user_id || isModerator) && (
                <Button variant="ghost" size="icon" className="text-red-500 hover:bg-red-50" onClick={() => setDeleteItem({ type: 'question', id: question.id })}>
                  <Trash2 className="w-4 h-4" />
                </Button>
             )}
          </div>
          <h1 className="text-2xl font-bold mb-4 text-gray-900">{question.title}</h1>
          <p className="text-gray-700 whitespace-pre-wrap mb-6">{question.description}</p>
          
          <div className="flex items-center text-sm text-gray-500 pt-4 border-t">
            <div className="flex items-center gap-2">
               <div className="w-8 h-8 bg-gray-200 rounded-full flex items-center justify-center font-bold text-gray-600">
                  {question.profiles?.full_name?.[0]}
               </div>
               <span className="font-medium">{question.profiles?.full_name}</span>
            </div>
            <span className="mx-2">•</span>
            <span>{new Date(question.created_at).toLocaleDateString()}</span>
          </div>
        </div>

        {/* Answers Section */}
        <h2 className="text-xl font-bold mb-4 px-2">Answers ({answers.length})</h2>
        
        <div className="space-y-4">
          {answers.map((answer) => (
            <motion.div 
              key={answer.id}
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              className="bg-white rounded-xl p-6 shadow-sm border relative"
              style={{ borderColor: activeTheme.border_color }}
            >
              <div className="flex gap-4">
                 {/* Vote Controls */}
                 <div className="flex flex-col items-center gap-2">
                    <button 
                      onClick={() => handleVote(answer.id, 'upvote')}
                      className={`p-1 rounded hover:bg-gray-100 ${answer.userVote === 'upvote' ? 'text-green-600' : 'text-gray-400'}`}
                    >
                       <ThumbsUp className="w-6 h-6" />
                    </button>
                    <span className="font-bold text-gray-700">{ (answer.upvotes || 0) - (answer.downvotes || 0) }</span>
                    <button 
                      onClick={() => handleVote(answer.id, 'downvote')}
                      className={`p-1 rounded hover:bg-gray-100 ${answer.userVote === 'downvote' ? 'text-red-600' : 'text-gray-400'}`}
                    >
                       <ThumbsDown className="w-6 h-6" />
                    </button>
                 </div>

                 {/* Content */}
                 <div className="flex-1">
                    <div className="flex justify-between items-start mb-2">
                       <div className="flex items-center gap-2">
                          <span className="font-semibold text-gray-900">{answer.profiles?.full_name}</span>
                          {answer.profiles?.role === 'verified_vet' && <VerifiedVetBadge size="sm" />}
                          <span className="text-xs text-gray-500">• {new Date(answer.created_at).toLocaleDateString()}</span>
                       </div>
                       {(user?.id === answer.user_id || isModerator) && (
                          <Button variant="ghost" size="icon" className="h-6 w-6 text-gray-400 hover:text-red-500" onClick={() => setDeleteItem({ type: 'answer', id: answer.id })}>
                            <Trash2 className="w-4 h-4" />
                          </Button>
                       )}
                    </div>
                    <p className="text-gray-700 whitespace-pre-wrap">{answer.answer_text}</p>
                 </div>
              </div>
            </motion.div>
          ))}

          {answers.length === 0 && (
            <div className="text-center py-10 text-gray-500 italic">
               No answers yet. Be the first to help!
            </div>
          )}
        </div>

        <QnAAnswerForm questionId={id} onAnswerSubmitted={fetchAnswers} />
      </div>

      <AlertDialog open={!!deleteItem} onOpenChange={(open) => !open && setDeleteItem(null)}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Are you sure?</AlertDialogTitle>
            <AlertDialogDescription>
              This action cannot be undone. This will permanently delete the {deleteItem?.type}.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancel</AlertDialogCancel>
            <AlertDialogAction onClick={confirmDelete} className="bg-red-600 hover:bg-red-700">Delete</AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
};

export default QnAQuestionDetail;
