import React, { useState, useEffect, useRef } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Heart, MessageCircle, Share2, Plus, Volume2, VolumeX } from 'lucide-react';
import { useAuth } from '@/context/AuthContext';
import { useTheme } from '@/context/ThemeContext';
import { supabase } from '@/lib/supabase';
import { Button } from '@/components/ui/button';
import ZoomiesUploadModal from './ZoomiesUploadModal';
import ZoomiesCommentForm from './ZoomiesCommentForm';
import {
  Sheet,
  SheetContent,
  SheetHeader,
  SheetTitle,
  SheetTrigger,
} from "@/components/ui/sheet";

const ZoomiesPage = () => {
  const [videos, setVideos] = useState([]);
  const [currentIndex, setCurrentIndex] = useState(0);
  const [isMuted, setIsMuted] = useState(false);
  const [isUploadOpen, setIsUploadOpen] = useState(false);
  const containerRef = useRef(null);
  const { user } = useAuth();
  const { activeTheme } = useTheme();

  useEffect(() => {
    fetchVideos();
  }, []);

  const fetchVideos = async () => {
    const { data } = await supabase
      .from('zoomies_videos')
      .select('*, profiles(*)')
      .order('created_at', { ascending: false });
    
    if (data) setVideos(data);
  };

  const handleScroll = (e) => {
    const container = e.target;
    const index = Math.round(container.scrollTop / container.clientHeight);
    if (index !== currentIndex) {
      setCurrentIndex(index);
    }
  };

  const toggleLike = async (video) => {
    // Optimistic update would go here
    const { error } = await supabase
      .from('zoomies_likes')
      .insert({ video_id: video.id, user_id: user.id });
    
    // Simplified: refresh or update local state manually
    if (!error) {
       // Ideally update local state
    }
  };

  return (
    <div 
      className="relative h-[calc(100vh-80px)] w-full bg-black overflow-hidden"
    >
      {/* Header overlay */}
      <div className="absolute top-0 left-0 right-0 p-4 z-20 flex justify-between items-center bg-gradient-to-b from-black/50 to-transparent">
        <h1 className="text-white font-bold text-xl drop-shadow-md">Zoomies</h1>
        <Button 
          size="sm" 
          onClick={() => setIsUploadOpen(true)}
          className="bg-white/20 hover:bg-white/30 text-white border-0 backdrop-blur-sm"
        >
          <Plus className="w-4 h-4 mr-1" /> Post
        </Button>
      </div>

      <div 
        ref={containerRef}
        className="h-full w-full overflow-y-scroll snap-y snap-mandatory no-scrollbar"
        onScroll={handleScroll}
      >
        {videos.length === 0 ? (
           <div className="h-full flex flex-col items-center justify-center text-white p-6 text-center">
              <p className="mb-4 text-lg">No zoomies yet!</p>
              <Button onClick={() => setIsUploadOpen(true)} className="bg-[var(--accent-primary)]">
                Be the first to post
              </Button>
           </div>
        ) : (
          videos.map((video, index) => (
            <div 
              key={video.id}
              className="h-full w-full snap-start relative flex items-center justify-center bg-gray-900"
            >
              {Math.abs(currentIndex - index) <= 1 && ( // Only render current, prev, next
                <VideoPlayer 
                   src={video.video_url} 
                   isActive={currentIndex === index} 
                   isMuted={isMuted}
                   toggleMute={() => setIsMuted(!isMuted)}
                />
              )}
              
              {/* Overlay Controls */}
              <div className="absolute bottom-0 left-0 right-0 p-4 pb-10 bg-gradient-to-t from-black/80 via-black/30 to-transparent text-white z-10 flex items-end justify-between">
                 <div className="flex-1 mr-12 mb-2">
                    <div className="flex items-center gap-2 mb-2">
                       <img src={video.profiles?.avatar_url || 'https://via.placeholder.com/40'} className="w-10 h-10 rounded-full border-2 border-white" />
                       <span className="font-bold drop-shadow-md">@{video.profiles?.full_name}</span>
                    </div>
                    <p className="font-medium drop-shadow-md mb-1">{video.title}</p>
                    <p className="text-sm opacity-90 line-clamp-2 drop-shadow-md">{video.description}</p>
                 </div>

                 <div className="flex flex-col items-center gap-6 mb-4">
                    <button className="flex flex-col items-center gap-1 group" onClick={() => toggleLike(video)}>
                       <div className="p-3 bg-black/40 rounded-full group-hover:bg-red-500/20 transition-colors backdrop-blur-sm">
                          <Heart className="w-6 h-6 text-white group-hover:text-red-500 transition-colors" />
                       </div>
                       <span className="text-xs font-medium drop-shadow-md">{video.likes_count || 0}</span>
                    </button>
                    
                    <Sheet>
                       <SheetTrigger asChild>
                          <button className="flex flex-col items-center gap-1 group">
                             <div className="p-3 bg-black/40 rounded-full group-hover:bg-white/20 transition-colors backdrop-blur-sm">
                                <MessageCircle className="w-6 h-6 text-white" />
                             </div>
                             <span className="text-xs font-medium drop-shadow-md">{video.comments_count || 0}</span>
                          </button>
                       </SheetTrigger>
                       <SheetContent side="bottom" className="h-[70vh]" style={{ backgroundColor: activeTheme.bg_surface }}>
                          <SheetHeader>
                             <SheetTitle>Comments</SheetTitle>
                          </SheetHeader>
                          <div className="flex-1 overflow-y-auto py-4">
                             {/* Comments would be fetched here */}
                             <p className="text-center text-sm opacity-50">No comments yet.</p>
                          </div>
                          <div className="pt-2">
                             <ZoomiesCommentForm videoId={video.id} />
                          </div>
                       </SheetContent>
                    </Sheet>

                    <button className="flex flex-col items-center gap-1 group">
                       <div className="p-3 bg-black/40 rounded-full group-hover:bg-green-500/20 transition-colors backdrop-blur-sm">
                          <Share2 className="w-6 h-6 text-white" />
                       </div>
                       <span className="text-xs font-medium drop-shadow-md">Share</span>
                    </button>
                 </div>
              </div>
            </div>
          ))
        )}
      </div>

      <ZoomiesUploadModal 
        isOpen={isUploadOpen} 
        onClose={() => setIsUploadOpen(false)} 
        onUploadSuccess={fetchVideos}
      />
    </div>
  );
};

const VideoPlayer = ({ src, isActive, isMuted, toggleMute }) => {
  const videoRef = useRef(null);

  useEffect(() => {
    if (isActive && videoRef.current) {
      videoRef.current.currentTime = 0;
      videoRef.current.play().catch(e => console.log("Autoplay blocked", e));
    } else if (videoRef.current) {
      videoRef.current.pause();
    }
  }, [isActive]);

  return (
    <div className="w-full h-full relative" onClick={toggleMute}>
       <video
         ref={videoRef}
         src={src}
         className="w-full h-full object-cover"
         loop
         playsInline
         muted={isMuted}
       />
       <button className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 opacity-0 hover:opacity-100 transition-opacity bg-black/40 p-4 rounded-full">
          {isMuted ? <VolumeX className="w-8 h-8 text-white" /> : <Volume2 className="w-8 h-8 text-white" />}
       </button>
    </div>
  );
};

export default ZoomiesPage;