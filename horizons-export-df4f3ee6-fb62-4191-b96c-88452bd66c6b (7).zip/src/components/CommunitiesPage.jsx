
import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Hash, Plus, Users, ArrowRight, Shield, Lock } from 'lucide-react';
import { supabase } from '@/lib/supabase';
import { Button } from '@/components/ui/button';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { useAuth } from '@/context/AuthContext';
import { useTheme } from '@/context/ThemeContext';
import { useToast } from '@/components/ui/use-toast';
import ChannelDetailPage from './ChannelDetailPage';
import { Checkbox } from "@/components/ui/checkbox";
import { Label } from "@/components/ui/label";

const CommunitiesPage = () => {
  const [selectedChannelId, setSelectedChannelId] = useState(null);
  const [channels, setChannels] = useState([]);
  const [newChannel, setNewChannel] = useState({ name: '', description: '', isPrivate: false });
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const { user } = useAuth();
  const { activeTheme } = useTheme();
  const { toast } = useToast();

  const onSelectChannel = (channelId) => {
    setSelectedChannelId(channelId);
  };

  useEffect(() => {
    fetchChannels();
    
    // Subscribe to all changes on 'channels' table
    const sub = supabase.channel('public:channels')
      .on('postgres_changes', { event: '*', schema: 'public', table: 'channels' }, (payload) => {
        if (payload.eventType === 'INSERT') {
          setChannels(prev => [payload.new, ...prev]);
        }
        else if (payload.eventType === 'DELETE') {
          setChannels(prev => prev.filter(channel => channel.id !== payload.old.id));
        }
        else if (payload.eventType === 'UPDATE') {
           setChannels(prev => prev.map(channel => channel.id === payload.new.id ? payload.new : channel));
        }
      })
      .subscribe();

    return () => supabase.removeChannel(sub);
  }, []);

  const fetchChannels = async () => {
    const { data } = await supabase.from('channels').select('*').order('created_at', { ascending: false });
    if (data) setChannels(data);
  };

  const createChannel = async () => {
    if (!newChannel.name) return;
    if (!user) {
      toast({ title: "Error", description: "You must be logged in to create a channel", variant: "destructive" });
      return;
    }

    const { error } = await supabase.from('channels').insert({
      name: newChannel.name,
      description: newChannel.description,
      creator_id: user.id,
      is_public: !newChannel.isPrivate,
      privacy_status: newChannel.isPrivate ? 'private' : 'public'
    });
    
    if (!error) {
      setNewChannel({ name: '', description: '', isPrivate: false });
      setIsDialogOpen(false);
      toast({ title: "Success", description: "Channel created successfully" });
    } else {
      toast({ title: "Error", description: error.message, variant: "destructive" });
    }
  };

  if (selectedChannelId) {
    return <ChannelDetailPage channelId={selectedChannelId} onBack={() => onSelectChannel(null)} />;
  }

  return (
    <div 
      className="container mx-auto px-4 py-6 max-w-2xl min-h-screen pb-24 transition-colors"
      style={{ backgroundColor: activeTheme.bg_secondary }}
    >
      <div className="flex justify-between items-center mb-6">
        <div>
           <h1 className="text-3xl font-bold font-poppins" style={{ color: activeTheme.text_primary }}>
             Channels
           </h1>
           <p className="text-sm" style={{ color: activeTheme.text_secondary }}>
             Join the conversation
           </p>
        </div>
        
        <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
          <DialogTrigger asChild>
            <Button 
              className="shadow-md border-0 text-white"
              style={{ backgroundColor: activeTheme.accent_primary }}
            >
              <Plus className="w-4 h-4 mr-1" /> Create
            </Button>
          </DialogTrigger>
          <DialogContent 
            className="border"
            style={{ 
              backgroundColor: activeTheme.bg_primary,
              borderColor: activeTheme.border_color
            }}
          >
            <DialogHeader>
              <DialogTitle style={{ color: activeTheme.text_primary }}>New Community Channel</DialogTitle>
            </DialogHeader>
            <div className="space-y-4 pt-4">
              <div className="space-y-2">
                 <Label style={{ color: activeTheme.text_primary }}>Channel Name</Label>
                 <div className="relative">
                    <span className="absolute left-3 top-2.5" style={{ color: activeTheme.text_secondary }}>#</span>
                    <input 
                      placeholder="puppy-training"
                      value={newChannel.name}
                      onChange={e => setNewChannel({...newChannel, name: e.target.value.toLowerCase().replace(/\s+/g, '-')})}
                      className="w-full pl-7 p-2 border rounded-md focus:ring-2 outline-none"
                      style={{ 
                        backgroundColor: activeTheme.bg_secondary,
                        borderColor: activeTheme.border_color,
                        color: activeTheme.text_primary
                      }}
                    />
                 </div>
              </div>
              <div className="space-y-2">
                 <Label style={{ color: activeTheme.text_primary }}>Description</Label>
                 <textarea
                    placeholder="What's this channel about?"
                    value={newChannel.description}
                    onChange={e => setNewChannel({...newChannel, description: e.target.value})}
                    className="w-full p-2 border rounded-md focus:ring-2 outline-none"
                    style={{ 
                        backgroundColor: activeTheme.bg_secondary,
                        borderColor: activeTheme.border_color,
                        color: activeTheme.text_primary
                    }}
                 />
              </div>

              <div className="flex items-center space-x-2">
                 <Checkbox 
                    id="privacy" 
                    checked={newChannel.isPrivate} 
                    onCheckedChange={(checked) => setNewChannel({...newChannel, isPrivate: checked})}
                 />
                 <Label htmlFor="privacy" style={{ color: activeTheme.text_primary }}>Make Private (Invite Only)</Label>
              </div>

              <Button 
                onClick={createChannel} 
                className="w-full text-white"
                style={{ backgroundColor: activeTheme.accent_primary }}
              >
                Create Channel
              </Button>
            </div>
          </DialogContent>
        </Dialog>
      </div>

      <div className="space-y-3">
        <AnimatePresence>
          {channels.map((channel, index) => (
            <motion.div
              key={channel.id}
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.95, height: 0 }}
              transition={{ delay: index * 0.05 }}
              onClick={() => onSelectChannel(channel.id)}
              whileHover={{ scale: 1.01 }}
              whileTap={{ scale: 0.99 }}
              className="p-5 rounded-xl shadow-sm border cursor-pointer flex items-center justify-between group transition-colors"
              style={{ 
                backgroundColor: activeTheme.bg_primary,
                borderColor: activeTheme.border_color
              }}
            >
              <div className="flex items-center gap-4">
                <div 
                  className="w-12 h-12 rounded-full flex items-center justify-center transition-colors group-hover:text-white relative"
                  style={{ 
                    backgroundColor: activeTheme.accent_tertiary,
                    color: activeTheme.accent_primary
                  }}
                >
                  <Hash className="w-6 h-6" />
                  {channel.privacy_status === 'private' && (
                     <div className="absolute -bottom-1 -right-1 bg-white dark:bg-gray-800 rounded-full p-0.5">
                        <Lock className="w-3 h-3 text-gray-500" />
                     </div>
                  )}
                </div>
                <div>
                  <h3 
                    className="font-bold text-lg transition-colors flex items-center gap-2"
                    style={{ color: activeTheme.text_primary }}
                  >
                    #{channel.name}
                  </h3>
                  <p 
                    className="text-sm line-clamp-1"
                    style={{ color: activeTheme.text_secondary }}
                  >
                    {channel.description}
                  </p>
                </div>
              </div>
              <ArrowRight 
                className="w-5 h-5 transition-colors"
                style={{ color: activeTheme.text_secondary }}
              />
            </motion.div>
          ))}
        </AnimatePresence>
        
        {channels.length === 0 && (
           <div className="text-center py-10 opacity-50">
              <p style={{ color: activeTheme.text_secondary }}>No channels found. Create one!</p>
           </div>
        )}
      </div>
    </div>
  );
};

export default CommunitiesPage;
