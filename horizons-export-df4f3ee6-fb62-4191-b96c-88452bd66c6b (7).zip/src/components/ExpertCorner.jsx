
import React from 'react';
import { motion } from 'framer-motion';
import { Star } from 'lucide-react';

const ExpertCorner = () => {
  const posts = []; // Empty for now

  return (
    <div className="container mx-auto px-4 py-6 max-w-2xl">
      <h1 className="text-3xl font-bold mb-2 font-poppins">Expert Corner</h1>
      <p className="text-gray-600 mb-6">Professional advice from certified experts</p>

      {posts.length === 0 ? (
        <div className="text-center py-16 bg-white rounded-xl shadow-sm border border-gray-100">
           <Star className="w-12 h-12 text-gray-300 mx-auto mb-4" />
           <p className="text-gray-500">No expert posts available yet.</p>
        </div>
      ) : (
        <div>{/* Post list */}</div>
      )}
    </div>
  );
};

export default ExpertCorner;
