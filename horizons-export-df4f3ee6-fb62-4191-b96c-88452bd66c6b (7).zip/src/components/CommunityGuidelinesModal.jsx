
import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Shield, Check, BookOpen } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { useAuth } from '@/context/AuthContext';
import { supabase } from '@/lib/supabase';
import { useNavigate, Link } from 'react-router-dom';
import { useToast } from '@/components/ui/use-toast';
import { Checkbox } from "@/components/ui/checkbox";

const CommunityGuidelinesModal = () => {
  const { user, refreshGuidelinesStatus } = useAuth();
  const navigate = useNavigate();
  const { toast } = useToast();
  const [submitting, setSubmitting] = useState(false);
  const [agreed, setAgreed] = useState(false);

  const handleAgree = async () => {
    if (!user || !agreed) return;
    setSubmitting(true);
    
    try {
      // 1. Update Profile Flag
      const { error: profileError } = await supabase
        .from('profiles')
        .update({ agreed_to_guidelines: true })
        .eq('id', user.id);

      if (profileError) throw profileError;

      // 2. Insert Acceptance Record
      const { error: acceptanceError } = await supabase
        .from('community_guidelines_acceptance')
        .insert({
          user_id: user.id,
          accepted_at: new Date().toISOString()
        });

      if (acceptanceError) {
         console.warn("Could not insert acceptance record, but profile flag updated.");
      }

      toast({ 
        title: "Welcome aboard! 🐾", 
        description: "You've successfully joined the Paws & Pals community." 
      });
      
      await refreshGuidelinesStatus();
      navigate('/dashboard', { replace: true });
      
    } catch (error) {
      console.error("Error accepting guidelines:", error);
      toast({ 
        title: "Something went wrong", 
        description: "Please try again. Check your connection.", 
        variant: "destructive" 
      });
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <div className="fixed inset-0 z-[60] flex items-center justify-center bg-black/80 backdrop-blur-md p-4">
      <motion.div 
        initial={{ opacity: 0, scale: 0.9 }}
        animate={{ opacity: 1, scale: 1 }}
        className="bg-white dark:bg-gray-900 rounded-3xl shadow-2xl w-full max-w-lg overflow-hidden border-4 border-blue-100 dark:border-gray-700"
      >
        <div className="bg-gradient-to-r from-blue-500 to-purple-600 p-8 text-white text-center">
           <div className="w-16 h-16 bg-white/20 rounded-full flex items-center justify-center mx-auto mb-4 backdrop-blur-sm">
              <Shield className="w-8 h-8 text-white" />
           </div>
           <h2 className="text-3xl font-bold mb-2">Community Rules</h2>
           <p className="text-blue-100">Please review before continuing</p>
        </div>

        <div className="p-8 space-y-6">
           <div className="space-y-4 text-sm text-gray-600 dark:text-gray-300 max-h-[40vh] overflow-y-auto pr-2 custom-scrollbar">
              <p className="font-medium text-lg text-gray-900 dark:text-white">Our Promise to You</p>
              <p>
                 We strive to create a safe, welcoming, and fun environment for all pet lovers. 
                 By joining, you agree to:
              </p>
              <ul className="list-disc pl-5 space-y-2">
                 <li>Treat all members and their pets with respect.</li>
                 <li>Avoid hate speech, bullying, or harassment.</li>
                 <li>Post only appropriate, pet-related content.</li>
                 <li>Respect the privacy and safety of others.</li>
                 <li>Not spam or solicit other members.</li>
              </ul>
              <div className="pt-2">
                 <Link to="/guidelines" className="text-blue-600 hover:underline flex items-center gap-1">
                    <BookOpen className="w-4 h-4" /> Read Full Guidelines
                 </Link>
              </div>
           </div>

           <div className="bg-gray-50 dark:bg-gray-800 p-4 rounded-xl flex items-start gap-3">
              <Checkbox 
                id="agree" 
                checked={agreed} 
                onCheckedChange={setAgreed}
                className="mt-1"
              />
              <label htmlFor="agree" className="text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70 cursor-pointer select-none">
                I have read and agree to the Community Guidelines and Code of Conduct.
              </label>
           </div>

           <Button 
             onClick={handleAgree} 
             disabled={!agreed || submitting}
             className="w-full py-6 text-lg font-bold rounded-xl shadow-lg transition-all hover:scale-[1.02]"
           >
             {submitting ? 'Processing...' : 'Accept & Continue'}
           </Button>
        </div>
      </motion.div>
    </div>
  );
};

export default CommunityGuidelinesModal;
