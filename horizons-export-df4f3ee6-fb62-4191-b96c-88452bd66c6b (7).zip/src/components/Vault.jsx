
import React from 'react';
import { motion } from 'framer-motion';
import { FileText, Upload } from 'lucide-react';
import { Button } from '@/components/ui/button';

const Vault = () => {
  const docs = []; // Empty for now

  return (
    <div className="container mx-auto px-4 py-6 max-w-2xl">
      <h1 className="text-3xl font-bold mb-2 font-poppins">Pet Health Vault</h1>
      <p className="text-gray-600 mb-6">Securely manage health records</p>

      {docs.length === 0 ? (
        <div className="text-center py-16 bg-white rounded-xl shadow-sm border border-gray-100">
           <div className="w-16 h-16 bg-[#FFF8F3] rounded-full flex items-center justify-center mx-auto mb-4">
             <FileText className="w-8 h-8 text-[#B4D4FF]" />
           </div>
           <h3 className="text-lg font-bold text-gray-900 mb-2">No documents yet</h3>
           <p className="text-gray-500 mb-6">Upload vaccination records, vet visits, and more.</p>
           <Button style={{ backgroundColor: '#B4D4FF', color: '#1a1b1e' }}>
             <Upload className="w-4 h-4 mr-2" /> Upload Document
           </Button>
        </div>
      ) : (
        <div>{/* Doc list */}</div>
      )}
    </div>
  );
};

export default Vault;
