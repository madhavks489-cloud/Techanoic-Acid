
import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { Loader2, User, Lock, ArrowLeft } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { useAuth } from '@/context/AuthContext';
import { Link, useNavigate } from 'react-router-dom';
import { useTheme } from '@/context/ThemeContext';

const SigninPage = () => {
  const { login, hasAcceptedGuidelines } = useAuth();
  const navigate = useNavigate();
  const { activeTheme } = useTheme();
  
  const [formData, setFormData] = useState({
    username: '',
    password: ''
  });
  const [loading, setLoading] = useState(false);

  const handleSubmit = async (e) => {
    e.preventDefault();
    setLoading(true);
    const result = await login(formData.username, formData.password);
    setLoading(false);
    
    if (result.success) {
       // Check guidelines status from the AuthContext which should update after login
       // We might need a small delay or rely on the updated state if not immediate
       // But typically navigate happens here based on desired flow
       
       // Note: In strict React logic, accessing 'hasAcceptedGuidelines' here might get the OLD value 
       // from before the login state update processed. 
       // However, the App.jsx ProtectedRoute handles the redirection to /community-guidelines automatically
       // if authenticated but not accepted. So strictly speaking, just navigating to dashboard is enough,
       // and the Router will intercept.
       
       navigate('/dashboard');
    }
  };

  return (
    <div className="min-h-screen flex items-center justify-center p-4 bg-gradient-to-bl from-green-50 to-blue-50">
      <div className="w-full max-w-md">
        <Button 
          variant="ghost" 
          className="mb-4 pl-0 hover:bg-transparent hover:text-gray-900" 
          onClick={() => navigate('/')}
        >
          <ArrowLeft className="w-5 h-5 mr-2" /> Back to Home
        </Button>

        <motion.div 
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="w-full p-8 rounded-3xl shadow-xl bg-white border border-gray-100"
        >
          <div className="text-center mb-8">
             <div className="w-16 h-16 bg-gradient-to-tr from-green-400 to-blue-500 rounded-2xl mx-auto mb-4 flex items-center justify-center shadow-lg -rotate-3 hover:-rotate-6 transition-transform">
                <Lock className="text-white w-8 h-8" />
             </div>
             <h1 className="text-2xl font-bold mb-2 text-gray-900">Welcome Back</h1>
             <p className="text-gray-500">Enter your credentials to access your account</p>
          </div>

          <form onSubmit={handleSubmit} className="space-y-6">
             <div className="space-y-2">
                <label className="text-sm font-semibold ml-1 text-gray-700">Username</label>
                <Input 
                  type="text"
                  placeholder="Enter your username" 
                  className="pl-4 h-12 bg-gray-50 border-gray-200 rounded-xl focus:ring-2 focus:ring-green-500 transition-all"
                  value={formData.username}
                  onChange={e => setFormData({...formData, username: e.target.value})}
                  required
                />
             </div>

             <div className="space-y-2">
                <label className="text-sm font-semibold ml-1 text-gray-700">Password</label>
                <Input 
                  type="password"
                  placeholder="Enter your password" 
                  className="pl-4 h-12 bg-gray-50 border-gray-200 rounded-xl focus:ring-2 focus:ring-green-500 transition-all"
                  value={formData.password}
                  onChange={e => setFormData({...formData, password: e.target.value})}
                  required
                />
             </div>

             <Button 
               type="submit" 
               className="w-full h-12 text-lg font-bold rounded-xl shadow-lg bg-gradient-to-r from-green-500 to-blue-600 hover:from-green-600 hover:to-blue-700 transition-all hover:scale-[1.02]" 
               disabled={loading}
             >
               {loading ? <Loader2 className="animate-spin w-5 h-5 mr-2" /> : null}
               Sign In
             </Button>
          </form>

          <div className="mt-8 text-center text-sm">
            <p className="text-gray-500">
              Don't have an account?{' '}
              <Link to="/signup" className="font-bold text-green-600 hover:underline">
                Sign up
              </Link>
            </p>
          </div>
        </motion.div>
      </div>
    </div>
  );
};

export default SigninPage;
