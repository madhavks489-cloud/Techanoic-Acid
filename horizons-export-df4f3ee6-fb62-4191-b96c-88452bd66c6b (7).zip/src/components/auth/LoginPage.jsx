import React from 'react';

// Component deprecated/removed as authentication is now disabled.
// Using Demo User mode.
const LoginPage = () => {
  return null;
};

export default LoginPage;