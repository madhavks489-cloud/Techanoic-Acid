
import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { Loader2, User, Lock, ArrowLeft, AlertCircle } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { useAuth } from '@/context/AuthContext';
import { Link, useNavigate } from 'react-router-dom';
import { useTheme } from '@/context/ThemeContext';
import { useToast } from '@/components/ui/use-toast';

const SignupPage = () => {
  const { signup } = useAuth();
  const navigate = useNavigate();
  const { activeTheme } = useTheme();
  const { toast } = useToast();
  
  const [formData, setFormData] = useState({
    username: '',
    password: '',
    confirmPassword: ''
  });
  const [loading, setLoading] = useState(false);
  const [signupError, setSignupError] = useState(null);

  const validateUsername = (username) => {
    const regex = /^[a-zA-Z0-9_]{3,}$/;
    return regex.test(username);
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setSignupError(null);
    
    if (!validateUsername(formData.username)) {
      toast({
        title: "Invalid Username",
        description: "Username must be at least 3 characters and contain only letters, numbers, and underscores.",
        variant: "destructive"
      });
      return;
    }

    if (formData.password.length < 6) {
      toast({
        title: "Weak Password",
        description: "Password must be at least 6 characters long.",
        variant: "destructive"
      });
      return;
    }

    if (formData.password !== formData.confirmPassword) {
      toast({
        title: "Password Mismatch",
        description: "Passwords do not match.",
        variant: "destructive"
      });
      return;
    }
    
    setLoading(true);
    const result = await signup(formData.username, formData.password);
    setLoading(false);
    
    if (result.success) {
      // Direct to community guidelines instead of dashboard
      navigate('/community-guidelines');
    } else if (result.isSignupDisabled) {
      setSignupError({
        type: 'disabled',
        message: "New account registration is currently disabled."
      });
    }
  };

  return (
    <div className="min-h-screen flex items-center justify-center p-4 bg-gradient-to-br from-blue-50 to-purple-50">
      <div className="w-full max-w-md">
        <Button 
          variant="ghost" 
          className="mb-4 pl-0 hover:bg-transparent hover:text-gray-900" 
          onClick={() => navigate('/')}
        >
          <ArrowLeft className="w-5 h-5 mr-2" /> Back to Home
        </Button>

        <motion.div 
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="w-full p-8 rounded-3xl shadow-xl bg-white border border-gray-100"
        >
          <div className="text-center mb-8">
             <div className="w-16 h-16 bg-gradient-to-tr from-blue-400 to-purple-500 rounded-2xl mx-auto mb-4 flex items-center justify-center shadow-lg rotate-3 hover:rotate-6 transition-transform">
                <User className="text-white w-8 h-8" />
             </div>
             <h2 className="text-2xl font-bold text-gray-900">Create Account</h2>
             <p className="text-gray-500">Join the fluffiest community on the web</p>
          </div>

          {signupError && (
            <div className="mb-6 p-4 rounded-xl bg-red-50 border border-red-100 flex items-start gap-3">
              <AlertCircle className="w-5 h-5 text-red-600 flex-shrink-0 mt-0.5" />
              <div className="text-sm text-red-600">
                <p className="font-medium">Registration Failed</p>
                <p>{signupError.message}</p>
              </div>
            </div>
          )}

          <form onSubmit={handleSubmit} className="space-y-5">
             <div className="space-y-2">
               <label className="text-sm font-semibold ml-1 text-gray-700">Username</label>
               <Input 
                 placeholder="Choose a username" 
                 className="pl-4 h-12 bg-gray-50 border-gray-200 rounded-xl focus:ring-2 focus:ring-blue-500 transition-all"
                 value={formData.username}
                 onChange={e => setFormData({...formData, username: e.target.value})}
                 required
               />
               <p className="text-xs text-gray-400 ml-1">Letters, numbers & underscores only.</p>
             </div>

             <div className="space-y-2">
               <label className="text-sm font-semibold ml-1 text-gray-700">Password</label>
               <Input 
                 type="password"
                 placeholder="Create a password" 
                 className="pl-4 h-12 bg-gray-50 border-gray-200 rounded-xl focus:ring-2 focus:ring-blue-500 transition-all"
                 value={formData.password}
                 onChange={e => setFormData({...formData, password: e.target.value})}
                 required
                 minLength={6}
               />
             </div>

             <div className="space-y-2">
               <label className="text-sm font-semibold ml-1 text-gray-700">Confirm Password</label>
               <Input 
                 type="password"
                 placeholder="Confirm your password" 
                 className="pl-4 h-12 bg-gray-50 border-gray-200 rounded-xl focus:ring-2 focus:ring-blue-500 transition-all"
                 value={formData.confirmPassword}
                 onChange={e => setFormData({...formData, confirmPassword: e.target.value})}
                 required
                 minLength={6}
               />
             </div>

             <Button 
               type="submit" 
               className="w-full mt-6 h-12 text-lg font-bold rounded-xl shadow-lg bg-gradient-to-r from-blue-500 to-purple-600 hover:from-blue-600 hover:to-purple-700 transition-all hover:scale-[1.02]" 
               disabled={loading}
             >
               {loading ? <Loader2 className="animate-spin w-5 h-5 mr-2" /> : null}
               Sign Up
             </Button>
          </form>

          <div className="mt-8 text-center text-sm">
            <p className="text-gray-500">
              Already have an account?{' '}
              <Link to="/signin" className="font-bold text-blue-600 hover:underline">
                Sign In
              </Link>
            </p>
          </div>
        </motion.div>
      </div>
    </div>
  );
};

export default SignupPage;
