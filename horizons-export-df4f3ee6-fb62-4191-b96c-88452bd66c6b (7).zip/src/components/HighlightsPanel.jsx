import React, { useState, useEffect } from 'react';
import { Plus, Heart } from 'lucide-react';
import { supabase } from '@/lib/supabase';
import { useAuth } from '@/context/AuthContext';
import { useTheme } from '@/context/ThemeContext';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';

const HighlightsPanel = ({ userId }) => {
  const [highlights, setHighlights] = useState([]);
  const { activeTheme } = useTheme();

  useEffect(() => {
    const fetchHighlights = async () => {
      const { data } = await supabase
        .from('highlights')
        .select('*')
        .eq('user_id', userId);
      if (data) setHighlights(data);
    };
    fetchHighlights();
  }, [userId]);

  return (
    <div className="flex gap-4 overflow-x-auto py-4">
      {highlights.map(hl => (
        <div key={hl.id} className="flex flex-col items-center space-y-1 min-w-[70px] cursor-pointer">
           <div className="w-16 h-16 rounded-full border-2 p-1 bg-white dark:bg-gray-800" style={{ borderColor: activeTheme.border_color }}>
              <div className="w-full h-full rounded-full bg-gray-200 overflow-hidden">
                 {hl.cover_url ? (
                   <img src={hl.cover_url} className="w-full h-full object-cover" />
                 ) : (
                   <div className="w-full h-full flex items-center justify-center bg-gray-300">
                     <Heart className="w-6 h-6 text-white" />
                   </div>
                 )}
              </div>
           </div>
           <span className="text-xs font-medium" style={{ color: activeTheme.text_primary }}>{hl.name}</span>
        </div>
      ))}
    </div>
  );
};

export default HighlightsPanel;