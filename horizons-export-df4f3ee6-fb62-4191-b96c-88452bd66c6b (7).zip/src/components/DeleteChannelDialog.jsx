
import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { AlertTriangle, Trash2, Loader2 } from 'lucide-react';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogFooter } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { useTheme } from '@/context/ThemeContext';

const DeleteChannelDialog = ({ isOpen, onClose, onConfirm, channelName, loading }) => {
  const [confirmName, setConfirmName] = useState('');
  const { activeTheme } = useTheme();

  const isDeleteEnabled = confirmName === channelName;

  const handleConfirm = () => {
    if (isDeleteEnabled) {
      onConfirm();
    }
  };

  const handleOpenChange = (open) => {
    if (!loading) {
      if (!open) setConfirmName(''); // Reset on close
      onClose(open);
    }
  };

  return (
    <Dialog open={isOpen} onOpenChange={handleOpenChange}>
      <DialogContent 
        className="sm:max-w-md border-2"
        style={{ 
          backgroundColor: activeTheme.bg_primary,
          borderColor: activeTheme.border_color,
          color: activeTheme.text_primary
        }}
      >
        <DialogHeader>
          <div className="flex items-center gap-3 mb-2">
            <div className="p-3 rounded-full bg-red-100 dark:bg-red-900/30">
              <AlertTriangle className="w-6 h-6 text-red-600 dark:text-red-400" />
            </div>
            <DialogTitle style={{ color: activeTheme.text_primary }}>Delete Channel</DialogTitle>
          </div>
          <DialogDescription style={{ color: activeTheme.text_secondary }}>
            This action cannot be undone. This will permanently delete the 
            <span className="font-bold mx-1" style={{ color: activeTheme.text_primary }}>#{channelName}</span>
            channel and remove all messages, photos, and member data associated with it.
          </DialogDescription>
        </DialogHeader>

        <div className="space-y-4 py-4">
          <div className="space-y-2">
            <label className="text-sm font-medium" style={{ color: activeTheme.text_primary }}>
              To confirm, type "<span className="font-bold select-all">{channelName}</span>" below
            </label>
            <Input
              value={confirmName}
              onChange={(e) => setConfirmName(e.target.value)}
              placeholder={channelName}
              className="border-red-200 focus:ring-red-500"
              style={{
                 backgroundColor: activeTheme.bg_secondary,
                 color: activeTheme.text_primary,
                 borderColor: isDeleteEnabled ? 'green' : activeTheme.border_color
              }}
              disabled={loading}
            />
          </div>
        </div>

        <DialogFooter className="flex gap-2 sm:justify-end">
          <Button
            variant="outline"
            onClick={() => handleOpenChange(false)}
            disabled={loading}
            style={{ 
              borderColor: activeTheme.border_color,
              color: activeTheme.text_primary
            }}
          >
            Cancel
          </Button>
          <Button
            variant="destructive"
            onClick={handleConfirm}
            disabled={!isDeleteEnabled || loading}
            className="bg-red-600 hover:bg-red-700 text-white gap-2 transition-all duration-300"
          >
            {loading ? (
              <>
                <Loader2 className="w-4 h-4 animate-spin" />
                Deleting...
              </>
            ) : (
              <>
                <Trash2 className="w-4 h-4" />
                Delete Channel
              </>
            )}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
};

export default DeleteChannelDialog;
