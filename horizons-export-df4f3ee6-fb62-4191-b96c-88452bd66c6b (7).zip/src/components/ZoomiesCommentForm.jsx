
import React, { useState } from 'react';
import { Send, Loader2 } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { supabase } from '@/lib/supabase';
import { useAuth } from '@/context/AuthContext';
import { useTheme } from '@/context/ThemeContext';
import { useToast } from '@/components/ui/use-toast';

const ZoomiesCommentForm = ({ videoId, onCommentAdded }) => {
  const [comment, setComment] = useState('');
  const [loading, setLoading] = useState(false);
  const { user } = useAuth();
  const { activeTheme } = useTheme();
  const { toast } = useToast();

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!comment.trim()) return;

    setLoading(true);
    const { data, error } = await supabase
      .from('zoomies_comments')
      .insert({
        video_id: videoId,
        user_id: user.id,
        content: comment
      })
      .select('*, profiles(*)')
      .single();

    if (!error) {
      setComment('');
      if (onCommentAdded) onCommentAdded(data);
      toast({ title: "Comment added" });
    } else {
      toast({ title: "Error", description: "Could not add comment", variant: "destructive" });
    }
    setLoading(false);
  };

  return (
    <form onSubmit={handleSubmit} className="flex gap-2 items-center p-2 border-t" style={{ borderColor: activeTheme.border_color }}>
      <Input
        value={comment}
        onChange={(e) => setComment(e.target.value)}
        placeholder="Add a comment..."
        className="flex-1 bg-transparent border-none focus:ring-0 focus-visible:ring-0"
        style={{ color: activeTheme.text_primary }}
      />
      <Button 
        type="submit" 
        size="icon" 
        disabled={loading || !comment.trim()}
        variant="ghost"
        style={{ color: activeTheme.accent_primary }}
      >
        {loading ? <Loader2 className="w-4 h-4 animate-spin" /> : <Send className="w-4 h-4" />}
      </Button>
    </form>
  );
};

export default ZoomiesCommentForm;
