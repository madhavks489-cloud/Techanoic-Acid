
import React, { useState, useEffect } from 'react';
import { MapPin, Navigation, RefreshCw, Trash2, Power, Globe } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Label } from '@/components/ui/label';
import { useAuth } from '@/context/AuthContext';
import { useLocationTracking } from '@/hooks/useLocationTracking';
import { updateUserLocation } from '@/lib/locationUtils';
import { useToast } from '@/components/ui/use-toast';
import { supabase } from '@/lib/supabase';

const LocationSettings = () => {
  const { user, updateUser } = useAuth();
  const { latitude, longitude, accuracy, loading, refreshLocation } = useLocationTracking();
  const { toast } = useToast();
  const [address, setAddress] = useState('Unknown');
  const [isUpdating, setIsUpdating] = useState(false);

  useEffect(() => {
    const fetchCurrentAddress = async () => {
      try {
        // Fetch latest address from DB if available to avoid re-geocoding constantly
        const { data, error } = await supabase
          .from('user_locations')
          .select('address')
          .eq('user_id', user?.id)
          .eq('is_current', true)
          .maybeSingle(); // Use maybeSingle to avoid PGRST116 error
        
        if (data?.address) setAddress(data.address);
      } catch (err) {
        console.error("Error fetching address:", err);
      }
    };
    if (user?.id) fetchCurrentAddress();
  }, [user]);

  const handleToggleSharing = async () => {
    try {
      const newVal = !user.location_enabled;
      await updateUser({ location_enabled: newVal });
      
      // Also update profile in DB
      const { error } = await supabase.from('profiles').update({ location_enabled: newVal }).eq('id', user.id);
      
      if (error) throw error;

      toast({
        title: newVal ? "Location Sharing Enabled" : "Location Sharing Disabled",
        description: newVal ? "Other users can now see you on the map." : "You are now invisible on the map.",
      });
    } catch (error) {
      toast({
        variant: "destructive",
        title: "Error",
        description: "Failed to update location settings. Please try again."
      });
    }
  };

  const handleManualRefresh = async () => {
    setIsUpdating(true);
    refreshLocation(); // Get coords from browser
    
    if (latitude && longitude) {
      try {
        const result = await updateUserLocation(user.id, { latitude, longitude, accuracy });
        if (result?.address) setAddress(result.address);
        toast({ title: "Location Updated", description: "Your current position has been saved." });
      } catch (e) {
        console.error("Location update failed:", e);
        toast({ variant: "destructive", title: "Update Failed", description: "Could not save location to database. Check your connection." });
      }
    } else {
        // If latitude is null, it might take a moment, re-trigger
        setTimeout(async () => {
            refreshLocation(); // Try again
        }, 1000);
    }
    setIsUpdating(false);
  };

  const handleClearHistory = async () => {
    try {
      const { error } = await supabase
        .from('user_locations')
        .delete()
        .eq('user_id', user.id);
        
      if (error) throw error;
      
      toast({ title: "History Cleared", description: "All past location records have been deleted." });
    } catch (error) {
      toast({ variant: "destructive", title: "Error", description: "Failed to clear history." });
    }
  };

  return (
    <div className="space-y-6">
      <div className="bg-[var(--bg-secondary)] p-4 rounded-xl border border-[var(--border-color)]">
        <div className="flex items-center justify-between mb-4">
          <div className="flex items-center gap-3">
             <div className={`p-2 rounded-full ${user?.location_enabled ? 'bg-green-100 text-green-600' : 'bg-gray-200 text-gray-500'}`}>
                <Globe className="w-5 h-5" />
             </div>
             <div>
                <Label className="text-base font-semibold text-[var(--text-primary)]">Share Location</Label>
                <p className="text-xs text-[var(--text-secondary)]">Allow others to see you on the map</p>
             </div>
          </div>
          <button
            onClick={handleToggleSharing}
            className={`relative w-12 h-7 rounded-full transition-colors duration-300 ${
              user?.location_enabled ? 'bg-[var(--accent-primary)]' : 'bg-gray-300'
            }`}
          >
            <div className={`absolute top-1 left-1 bg-white w-5 h-5 rounded-full shadow-sm transition-transform duration-300 ${
              user?.location_enabled ? 'translate-x-5' : 'translate-x-0'
            }`} />
          </button>
        </div>

        {user?.location_enabled && (
           <div className="bg-[var(--bg-primary)] p-3 rounded-lg border border-[var(--border-color)] text-sm space-y-2">
              <div className="flex items-center gap-2 text-[var(--text-primary)]">
                 <MapPin className="w-4 h-4 text-[var(--accent-secondary)]" />
                 <span className="font-medium">Current Location:</span>
              </div>
              <p className="text-[var(--text-secondary)] pl-6 truncate">{address}</p>
              
              <div className="flex items-center gap-2 text-[var(--text-primary)] mt-2">
                 <Navigation className="w-4 h-4 text-[var(--accent-secondary)]" />
                 <span className="font-medium">Coordinates:</span>
              </div>
              <p className="text-[var(--text-secondary)] pl-6 font-mono text-xs">
                 {latitude ? `${latitude.toFixed(6)}, ${longitude.toFixed(6)}` : 'Waiting for signal...'}
              </p>
              
              <div className="pt-2 mt-2 border-t border-[var(--border-color)] flex gap-2">
                 <Button 
                    size="sm" 
                    variant="outline" 
                    onClick={handleManualRefresh}
                    disabled={isUpdating}
                    className="flex-1 border-[var(--border-color)] text-[var(--text-primary)]"
                 >
                    <RefreshCw className={`w-3 h-3 mr-2 ${isUpdating ? 'animate-spin' : ''}`} />
                    Update Now
                 </Button>
              </div>
           </div>
        )}
      </div>

      <div className="flex justify-between items-center pt-2">
         <p className="text-xs text-[var(--text-secondary)] italic">
            Location history is stored for safety and tracking.
         </p>
         <Button 
            size="sm" 
            variant="ghost" 
            onClick={handleClearHistory}
            className="text-red-500 hover:text-red-600 hover:bg-red-50 h-8"
         >
            <Trash2 className="w-3 h-3 mr-1" /> Clear History
         </Button>
      </div>
    </div>
  );
};

export default LocationSettings;
