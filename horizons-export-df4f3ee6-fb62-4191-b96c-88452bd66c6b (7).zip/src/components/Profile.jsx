
import React, { useState, useEffect } from 'react';
import { Settings, Plus, AlertTriangle, ShieldCheck, MapPin, Clock, Mail, Edit2, Check, BookOpen, Volume2, MousePointer2, Palette, Moon, Sun } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Switch } from "@/components/ui/switch";
import { Label } from "@/components/ui/label";
import { useAuth } from '@/context/AuthContext';
import { usePetTheme } from '@/context/PetThemeContext';
import { useTheme } from '@/context/ThemeContext';
import { supabase } from '@/lib/supabase';
import SettingsPanel from '@/components/SettingsPanel';
import AddPetPage from '@/components/AddPetPage';
import LostFoundPage from '@/components/LostFoundPage';
import VetApplicationForm from '@/components/VetApplicationForm';
import VerifiedVetBadge from '@/components/VerifiedVetBadge';
import { useLocationTracking } from '@/hooks/useLocationTracking';
import { updateUserLocation } from '@/lib/locationUtils';
import { useToast } from '@/components/ui/use-toast';
import HighlightsPanel from './HighlightsPanel';
import { useNavigate } from 'react-router-dom';
import CustomLoadingSpinner from '@/components/ui/CustomLoadingSpinner';

const Profile = () => {
  const [view, setView] = useState('main'); 
  const { user, updateProfileEmail, hasAcceptedGuidelines } = useAuth();
  const { soundEnabled, setSoundEnabled, cursorTrailEnabled, setCursorTrailEnabled } = usePetTheme();
  const { themeMode, setThemeMode, applyPreset, isPresetActive, activeTheme } = useTheme();
  
  const [myPets, setMyPets] = useState([]);
  const [vetAppStatus, setVetAppStatus] = useState(null);
  const [loading, setLoading] = useState(true);
  const { latitude, longitude, accuracy, refreshLocation } = useLocationTracking();
  const { toast } = useToast();
  const [lastLocationUpdate, setLastLocationUpdate] = useState(null);
  const [guidelinesDate, setGuidelinesDate] = useState(null);
  const navigate = useNavigate();
  
  const [isEditingEmail, setIsEditingEmail] = useState(false);
  const [emailInput, setEmailInput] = useState('');
  const [isSavingEmail, setIsSavingEmail] = useState(false);

  useEffect(() => {
    const fetchData = async () => {
      if (!user?.id) return;
      
      setLoading(true);
      if (user.email) setEmailInput(user.email);

      const { data } = await supabase.from('pets').select('*').eq('owner_id', user.id);
      if (data) setMyPets(data);

      const { data: appData } = await supabase.from('vet_applications')
        .select('status')
        .eq('user_id', user.id)
        .order('submitted_at', { ascending: false })
        .limit(1);
      
      if (appData && appData.length > 0) setVetAppStatus(appData[0].status);
      
      const { data: gd } = await supabase
        .from('community_guidelines_acceptance')
        .select('accepted_at')
        .eq('user_id', user.id)
        .order('accepted_at', { ascending: false })
        .limit(1)
        .maybeSingle();
        
      if (gd) setGuidelinesDate(new Date(gd.accepted_at));

      try {
        const { data: locData } = await supabase
           .from('user_locations')
           .select('timestamp')
           .eq('user_id', user.id)
           .eq('is_current', true)
           .maybeSingle();
        
        if (locData) setLastLocationUpdate(new Date(locData.timestamp));
      } catch (err) {
        console.error("Error fetching location history:", err);
      }
      setLoading(false);
    };
    
    fetchData();
  }, [user, view]);

  const handleUpdateLocation = async () => {
    refreshLocation();
    if (latitude && longitude) {
        try {
            await updateUserLocation(user.id, { latitude, longitude, accuracy });
            setLastLocationUpdate(new Date());
            toast({ title: "Location Updated", description: "Your profile now reflects your current position." });
        } catch (e) {
            console.error("Update location error:", e);
            toast({ variant: "destructive", title: "Error", description: "Could not update location. Please check your connection." });
        }
    } else {
        toast({ title: "Getting Location...", description: "Please wait while we acquire GPS signal." });
    }
  };

  const handleSaveEmail = async () => {
    setIsSavingEmail(true);
    await updateProfileEmail(emailInput);
    setIsSavingEmail(false);
    setIsEditingEmail(false);
  };

  if (view === 'settings') return <SettingsPanel onBack={() => setView('main')} />;
  if (view === 'add-pet') return <AddPetPage onBack={() => setView('main')} />;
  if (view === 'lost-found') return <LostFoundPage onBack={() => setView('main')} />;
  if (view === 'vet-application') return <VetApplicationForm onBack={() => setView('main')} />;

  if (loading) {
      return (
          <div className="min-h-screen flex items-center justify-center bg-[var(--bg-primary)]">
              <CustomLoadingSpinner size="large" />
          </div>
      );
  }

  return (
    <div className="container mx-auto px-4 py-8 max-w-4xl min-h-screen pb-24" style={{ backgroundColor: activeTheme.bg_surface }}>
      <div className="flex items-center justify-between mb-8">
        <h1 className="text-4xl font-extrabold font-poppins" style={{ color: activeTheme.text_primary }}>Your Profile</h1>
        <button onClick={() => setView('settings')} className="p-2 rounded-full hover:bg-white hover:shadow-md transition-all">
          <Settings className="w-7 h-7" style={{ color: activeTheme.text_secondary }} />
        </button>
      </div>

      <div className="grid md:grid-cols-3 gap-6">
        {/* Main Profile Card */}
        <div className="md:col-span-2 space-y-6">
           <div className="rounded-3xl shadow-lg p-8 border relative overflow-hidden" style={{ backgroundColor: activeTheme.bg_primary, borderColor: activeTheme.border_color }}>
             <div className="absolute top-0 right-0 w-32 h-32 rounded-bl-full opacity-20 -mr-10 -mt-10" style={{ backgroundColor: activeTheme.accent_primary }}></div>
             
             <div className="flex items-start gap-6 relative z-10">
                <div className="w-24 h-24 rounded-full border-4 shadow-md overflow-hidden bg-gray-100" style={{ borderColor: activeTheme.bg_secondary }}>
                    {user?.avatar_url ? (
                    <img src={user.avatar_url} alt="Profile" className="w-full h-full object-cover" />
                    ) : (
                    <div className="w-full h-full flex items-center justify-center text-3xl font-bold text-gray-400">
                        {user?.full_name?.[0]?.toUpperCase()}
                    </div>
                    )}
                </div>
                <div className="flex-1">
                    <div className="flex items-center gap-2 mb-1">
                        <h2 className="text-2xl font-bold" style={{ color: activeTheme.text_primary }}>{user?.full_name || 'User'}</h2>
                        {user?.role === 'verified_vet' && <VerifiedVetBadge />}
                    </div>
                    <p className="font-medium mb-3" style={{ color: activeTheme.text_secondary }}>@{user?.username}</p>
                    
                    {/* Email Edit */}
                    <div className="text-sm inline-block px-3 py-1 rounded-lg" style={{ backgroundColor: activeTheme.bg_secondary }}>
                      {isEditingEmail ? (
                        <div className="flex items-center gap-2">
                          <Input 
                            value={emailInput} 
                            onChange={(e) => setEmailInput(e.target.value)}
                            className="h-7 text-sm w-48 border-none bg-transparent focus-visible:ring-0 px-0"
                            placeholder="Add email"
                          />
                          <button onClick={handleSaveEmail} disabled={isSavingEmail} className="text-green-600">
                            <Check className="w-4 h-4" />
                          </button>
                        </div>
                      ) : (
                        <div className="flex items-center gap-2 cursor-pointer hover:opacity-80" onClick={() => setIsEditingEmail(true)} style={{ color: activeTheme.text_secondary }}>
                          <Mail className="w-3 h-3" />
                          <span>{user?.email || "Add email"}</span>
                          <Edit2 className="w-3 h-3 opacity-50" />
                        </div>
                      )}
                    </div>
                </div>
             </div>

             {/* Guidelines Status */}
             <div className="mt-8 pt-6 border-t" style={{ borderColor: activeTheme.border_color }}>
                <div className="flex items-center justify-between">
                   <div className="flex items-center gap-2">
                      <ShieldCheck className={`w-5 h-5 ${hasAcceptedGuidelines ? 'text-green-500' : 'text-red-500'}`} />
                      <span className="text-sm font-medium" style={{ color: activeTheme.text_primary }}>Community Guidelines</span>
                   </div>
                   <Button variant="ghost" size="sm" onClick={() => navigate('/guidelines')} className="text-xs hover:opacity-80" style={{ color: activeTheme.accent_primary }}>
                      <BookOpen className="w-3 h-3 mr-1" /> View Rules
                   </Button>
                </div>
                {guidelinesDate && (
                   <p className="text-xs mt-1 ml-7 opacity-70" style={{ color: activeTheme.text_secondary }}>Accepted on {guidelinesDate.toLocaleDateString()}</p>
                )}
             </div>
           </div>

           {/* Highlights */}
           <div className="rounded-3xl shadow-lg p-6 border" style={{ backgroundColor: activeTheme.bg_primary, borderColor: activeTheme.border_color }}>
             <h3 className="text-lg font-bold mb-4" style={{ color: activeTheme.text_primary }}>Highlights</h3>
             <HighlightsPanel userId={user.id} />
           </div>

           {/* My Pets */}
           <div>
              <div className="flex items-center justify-between mb-4">
                 <h2 className="text-xl font-bold" style={{ color: activeTheme.text_primary }}>My Pets</h2>
                 <Button onClick={() => setView('add-pet')} className="text-white rounded-xl" style={{ backgroundColor: activeTheme.accent_primary }}>
                    <Plus className="w-4 h-4 mr-2" /> Add Pet
                 </Button>
              </div>
              
              {myPets.length === 0 ? (
                <div className="text-center py-10 rounded-3xl border-2 border-dashed" style={{ backgroundColor: activeTheme.bg_primary, borderColor: activeTheme.border_color }}>
                   <div className="w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-3" style={{ backgroundColor: activeTheme.bg_secondary }}>
                     <span className="text-2xl">🐾</span>
                   </div>
                   <p style={{ color: activeTheme.text_secondary }}>No pets added yet.</p>
                </div>
              ) : (
                <div className="grid sm:grid-cols-2 gap-4">
                  {myPets.map(pet => (
                    <div key={pet.id} className="p-4 rounded-2xl shadow-sm border flex items-center gap-4 hover:shadow-md transition-shadow cursor-pointer" style={{ backgroundColor: activeTheme.bg_primary, borderColor: activeTheme.border_color }}>
                       {pet.photo_url ? (
                         <img src={pet.photo_url} alt={pet.name} className="w-16 h-16 rounded-2xl object-cover" />
                       ) : (
                         <div className="w-16 h-16 rounded-2xl flex items-center justify-center text-2xl" style={{ backgroundColor: activeTheme.bg_secondary }}>🐕</div>
                       )}
                       <div>
                         <h3 className="font-bold" style={{ color: activeTheme.text_primary }}>{pet.name}</h3>
                         <p className="text-sm" style={{ color: activeTheme.text_secondary }}>{pet.breed} • {pet.age}</p>
                       </div>
                    </div>
                  ))}
                </div>
              )}
           </div>
        </div>

        {/* Sidebar Column */}
        <div className="space-y-6">
           {/* Location Card */}
           <div className="bg-gradient-to-br from-blue-500 to-blue-600 rounded-3xl shadow-lg p-6 text-white">
              <div className="flex items-center justify-between mb-4">
                 <div className="flex items-center gap-2 font-bold">
                    <MapPin className="w-5 h-5" /> Location
                 </div>
                 <button onClick={handleUpdateLocation} className="bg-white/20 hover:bg-white/30 p-2 rounded-lg transition-colors">
                    <Clock className="w-4 h-4" />
                 </button>
              </div>
              <p className="text-blue-100 text-sm mb-4">
                 {user?.location_enabled ? "Sharing is enabled. Friends can find you." : "Location sharing is hidden."}
              </p>
              {lastLocationUpdate && (
                 <p className="text-xs text-blue-200">Updated: {lastLocationUpdate.toLocaleTimeString()}</p>
              )}
           </div>

           {/* Preferences & Theme */}
           <div className="rounded-3xl shadow-lg p-6 border" style={{ backgroundColor: activeTheme.bg_primary, borderColor: activeTheme.border_color }}>
              <h3 className="font-bold mb-4" style={{ color: activeTheme.text_primary }}>App Preferences</h3>
              
              <div className="space-y-6">
                 {/* Theme Selector */}
                 <div className="space-y-3 pb-4 border-b" style={{ borderColor: activeTheme.border_color }}>
                     <label className="text-sm font-medium flex items-center gap-2" style={{ color: activeTheme.text_primary }}>
                        <Palette className="w-4 h-4" /> Theme
                     </label>
                     <div className="grid grid-cols-2 gap-2">
                        <Button 
                            variant="outline" 
                            size="sm"
                            className={themeMode === 'light' ? 'border-blue-500 bg-blue-50 text-blue-700' : ''}
                            onClick={() => setThemeMode('light')}
                        >
                            <Sun className="w-4 h-4 mr-2" /> Light
                        </Button>
                        <Button 
                            variant="outline" 
                            size="sm"
                            className={themeMode === 'dark' ? 'border-purple-500 bg-purple-50 text-purple-700' : ''}
                            onClick={() => setThemeMode('dark')}
                        >
                            <Moon className="w-4 h-4 mr-2" /> Dark
                        </Button>
                     </div>
                     <div className="grid grid-cols-3 gap-2 mt-2">
                        {['forest', 'ocean', 'sunset'].map(preset => (
                            <div 
                                key={preset}
                                onClick={() => applyPreset(preset)}
                                className={`h-8 rounded-full cursor-pointer border-2 transition-all ${isPresetActive(preset) ? 'border-black scale-105 shadow-sm' : 'border-transparent opacity-70 hover:opacity-100'}`}
                                style={{ backgroundColor: preset === 'forest' ? '#22c55e' : preset === 'ocean' ? '#3b82f6' : '#f97316' }}
                            />
                        ))}
                     </div>
                 </div>

                 {/* Toggles */}
                 <div className="flex items-center justify-between">
                    <div className="flex items-center gap-3">
                       <div className="p-2 bg-orange-100 text-orange-600 rounded-lg dark:bg-orange-900/20">
                          <Volume2 className="w-5 h-5" />
                       </div>
                       <Label htmlFor="sound-toggle" className="text-sm font-medium" style={{ color: activeTheme.text_primary }}>Sound Effects</Label>
                    </div>
                    <Switch id="sound-toggle" checked={soundEnabled} onCheckedChange={setSoundEnabled} />
                 </div>

                 <div className="flex items-center justify-between">
                    <div className="flex items-center gap-3">
                       <div className="p-2 bg-purple-100 text-purple-600 rounded-lg dark:bg-purple-900/20">
                          <MousePointer2 className="w-5 h-5" />
                       </div>
                       <Label htmlFor="cursor-toggle" className="text-sm font-medium" style={{ color: activeTheme.text_primary }}>Paw Trail</Label>
                    </div>
                    <Switch id="cursor-toggle" checked={cursorTrailEnabled} onCheckedChange={setCursorTrailEnabled} />
                 </div>
              </div>
           </div>

           {/* Vet Status */}
           {user.role !== 'verified_vet' && (
              <div className="rounded-3xl shadow-lg p-6 border" style={{ backgroundColor: activeTheme.bg_primary, borderColor: activeTheme.border_color }}>
                 <h3 className="font-bold mb-2" style={{ color: activeTheme.text_primary }}>Veterinarian?</h3>
                 <p className="text-sm mb-4" style={{ color: activeTheme.text_secondary }}>Get verified to help our community with expert advice.</p>
                 {vetAppStatus === 'pending' ? (
                   <div className="bg-yellow-50 text-yellow-800 p-3 rounded-xl text-sm text-center font-medium">
                     Application Pending
                   </div>
                 ) : (
                   <Button 
                     onClick={() => setView('vet-application')}
                     variant="outline" 
                     className="w-full"
                   >
                     Apply Now
                   </Button>
                 )}
              </div>
           )}
           
           <Button 
             onClick={() => setView('lost-found')}
             className="w-full bg-red-50 hover:bg-red-100 text-red-600 border border-red-200 rounded-2xl py-6"
           >
             <AlertTriangle className="w-5 h-5 mr-2" /> Report Lost Pet
           </Button>
        </div>
      </div>
    </div>
  );
};

export default Profile;
