
import React, { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { MapPin, User, Navigation } from 'lucide-react';
import { supabase } from '@/lib/supabase';
import { useAuth } from '@/context/AuthContext';
import { calculateDistance } from '@/lib/locationUtils';
import { Button } from '@/components/ui/button';

const NearbyUsers = ({ currentUserLocation, radiusKm = 100 }) => {
  const { user } = useAuth();
  const [nearbyUsers, setNearbyUsers] = useState([]);
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    if (!user || !currentUserLocation?.latitude) return;

    const fetchNearby = async () => {
      setLoading(true);
      // Fetch users who have location enabled
      // Note: In a real production app with millions of users, you would use PostGIS 'ST_DWithin'
      // For this demo/frontend-only constraint, we fetch enabled users and filter in JS
      const { data, error } = await supabase
        .from('profiles')
        .select('id, full_name, avatar_url, latitude, longitude, role, last_seen')
        .eq('location_enabled', true)
        .neq('id', user.id); // Exclude self

      if (data) {
        const usersWithDistance = data.map(u => {
          if (!u.latitude || !u.longitude) return null;
          const dist = calculateDistance(
            currentUserLocation.latitude, 
            currentUserLocation.longitude, 
            u.latitude, 
            u.longitude
          );
          return { ...u, distance: dist };
        })
        .filter(u => u !== null && u.distance <= radiusKm)
        .sort((a, b) => a.distance - b.distance);

        setNearbyUsers(usersWithDistance);
      }
      setLoading(false);
    };

    fetchNearby();

    // Subscribe to changes in profiles (location updates)
    const channel = supabase.channel('nearby_users_updates')
      .on('postgres_changes', { 
        event: 'UPDATE', 
        schema: 'public', 
        table: 'profiles',
        filter: 'location_enabled=eq.true'
      }, () => {
        fetchNearby(); // Re-fetch on any location update
      })
      .subscribe();

    return () => supabase.removeChannel(channel);

  }, [user, currentUserLocation, radiusKm]);

  if (!currentUserLocation?.latitude) {
    return (
      <div className="p-4 text-center text-[var(--text-secondary)] bg-[var(--bg-secondary)] rounded-xl">
        <MapPin className="w-8 h-8 mx-auto mb-2 opacity-50" />
        <p>Enable location to see nearby pet owners.</p>
      </div>
    );
  }

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <h3 className="font-bold text-[var(--text-primary)]">Nearby Pet Owners</h3>
        <span className="text-xs bg-[var(--accent-tertiary)] text-[var(--accent-primary)] px-2 py-1 rounded-full">
          Within {radiusKm}km
        </span>
      </div>

      {loading && nearbyUsers.length === 0 ? (
        <p className="text-sm text-[var(--text-secondary)] text-center py-4">Finding neighbors...</p>
      ) : nearbyUsers.length === 0 ? (
        <p className="text-sm text-[var(--text-secondary)] text-center py-4">No other users found nearby.</p>
      ) : (
        <div className="grid gap-3">
          {nearbyUsers.map(neighbor => (
            <motion.div
              key={neighbor.id}
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              className="bg-[var(--bg-primary)] p-3 rounded-xl border border-[var(--border-color)] flex items-center justify-between shadow-sm hover:shadow-md transition-shadow"
            >
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-full overflow-hidden bg-[var(--bg-secondary)] border border-[var(--border-color)]">
                   {neighbor.avatar_url ? (
                     <img src={neighbor.avatar_url} alt={neighbor.full_name} className="w-full h-full object-cover" />
                   ) : (
                     <User className="w-5 h-5 m-2.5 text-[var(--text-secondary)]" />
                   )}
                </div>
                <div>
                  <h4 className="font-semibold text-sm text-[var(--text-primary)]">{neighbor.full_name}</h4>
                  <div className="flex items-center gap-1 text-xs text-[var(--text-secondary)]">
                    <Navigation className="w-3 h-3" />
                    <span>{neighbor.distance.toFixed(1)} km away</span>
                  </div>
                </div>
              </div>
              <Button size="sm" variant="ghost" className="h-8 w-8 p-0 rounded-full">
                <MapPin className="w-4 h-4 text-[var(--accent-primary)]" />
              </Button>
            </motion.div>
          ))}
        </div>
      )}
    </div>
  );
};

export default NearbyUsers;
