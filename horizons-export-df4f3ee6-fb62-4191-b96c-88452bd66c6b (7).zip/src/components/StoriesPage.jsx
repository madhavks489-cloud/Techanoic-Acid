import React, { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { Plus, X, ChevronLeft, ChevronRight, Loader2 } from 'lucide-react';
import { Dialog, DialogContent } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { supabase } from '@/lib/supabase';
import { useAuth } from '@/context/AuthContext';
import { useTheme } from '@/context/ThemeContext';
import { useToast } from '@/components/ui/use-toast';

const StoriesPage = () => {
  const [stories, setStories] = useState([]);
  const [selectedStoryIndex, setSelectedStoryIndex] = useState(null);
  const [loading, setLoading] = useState(true);
  const { user } = useAuth();
  const { activeTheme } = useTheme();
  const { toast } = useToast();

  useEffect(() => {
    fetchStories();
  }, []);

  const fetchStories = async () => {
    setLoading(true);
    // Fetch stories from last 24 hours
    const { data } = await supabase
      .from('stories')
      .select('*, profiles(*)')
      .gt('expires_at', new Date().toISOString())
      .order('created_at', { ascending: false });
    
    if (data) {
      // Group by user
      const grouped = data.reduce((acc, story) => {
        const userId = story.user_id;
        if (!acc[userId]) {
           acc[userId] = {
             user: story.profiles,
             items: []
           };
        }
        acc[userId].items.push(story);
        return acc;
      }, {});
      setStories(Object.values(grouped));
    }
    setLoading(false);
  };

  const handleCreateStory = async (e) => {
     const file = e.target.files[0];
     if (!file) return;

     const toastId = toast({ title: "Uploading story...", duration: 10000 });
     
     try {
        const fileName = `${user.id}/${Date.now()}_${file.name}`;
        const { error: upErr } = await supabase.storage.from('stories').upload(fileName, file);
        if (upErr) throw upErr;

        const { data: { publicUrl } } = supabase.storage.from('stories').getPublicUrl(fileName);

        await supabase.from('stories').insert({
          user_id: user.id,
          media_url: publicUrl,
          media_type: file.type.startsWith('video') ? 'video' : 'image'
        });

        toast({ title: "Story added!", description: "It will disappear in 24 hours." });
        fetchStories();

     } catch (err) {
        toast({ title: "Error", description: "Failed to upload story", variant: "destructive" });
     }
  };

  return (
    <div className="py-4 overflow-x-auto no-scrollbar flex gap-4 px-4 bg-[var(--bg-primary)] border-b border-[var(--border-color)]">
      {/* Add Story Button */}
      <div className="flex flex-col items-center space-y-1 min-w-[70px]">
        <div className="relative w-16 h-16 cursor-pointer group">
           <div className="w-full h-full rounded-full border-2 border-dashed border-gray-300 flex items-center justify-center overflow-hidden bg-gray-50 hover:bg-gray-100 transition-colors">
              <Plus className="w-6 h-6 text-gray-400" />
           </div>
           <input 
             type="file" 
             accept="image/*,video/*" 
             className="absolute inset-0 opacity-0 cursor-pointer"
             onChange={handleCreateStory}
           />
        </div>
        <span className="text-xs font-medium text-[var(--text-secondary)]">Your Story</span>
      </div>

      {loading && <Loader2 className="w-6 h-6 animate-spin text-[var(--accent-primary)] mt-4" />}

      {stories.map((group, idx) => (
        <motion.div 
          key={group.user.id}
          className="flex flex-col items-center space-y-1 min-w-[70px] cursor-pointer"
          onClick={() => setSelectedStoryIndex(idx)}
          whileHover={{ scale: 1.05 }}
        >
          <div className="w-16 h-16 rounded-full p-[2px] bg-gradient-to-tr from-yellow-400 to-fuchsia-600">
             <img 
               src={group.user.avatar_url} 
               alt={group.user.full_name} 
               className="w-full h-full rounded-full object-cover border-2 border-white"
             />
          </div>
          <span className="text-xs font-medium truncate w-16 text-center text-[var(--text-primary)]">
            {group.user.full_name.split(' ')[0]}
          </span>
        </motion.div>
      ))}

      {/* Story Viewer Modal */}
      {selectedStoryIndex !== null && (
        <StoryViewer 
           userStories={stories[selectedStoryIndex]} 
           onClose={() => setSelectedStoryIndex(null)}
           onNext={() => {
              if (selectedStoryIndex < stories.length - 1) setSelectedStoryIndex(selectedStoryIndex + 1);
              else setSelectedStoryIndex(null);
           }}
           onPrev={() => {
              if (selectedStoryIndex > 0) setSelectedStoryIndex(selectedStoryIndex - 1);
           }}
        />
      )}
    </div>
  );
};

const StoryViewer = ({ userStories, onClose, onNext, onPrev }) => {
  const [currentItem, setCurrentItem] = useState(0);
  const [progress, setProgress] = useState(0);
  const items = userStories.items;
  const currentStory = items[currentItem];

  useEffect(() => {
    const timer = setInterval(() => {
       setProgress(old => {
         if (old >= 100) {
           if (currentItem < items.length - 1) {
             setCurrentItem(c => c + 1);
             return 0;
           } else {
             onNext();
             return 100;
           }
         }
         return old + 1; // Approx 5 seconds total (50ms interval * 100 steps = 5000ms)
       });
    }, 50);

    return () => clearInterval(timer);
  }, [currentItem, items.length, onNext]);

  return (
    <Dialog open={true} onOpenChange={onClose}>
      <DialogContent className="p-0 border-none bg-black max-w-md h-[80vh] flex flex-col items-center justify-center overflow-hidden">
         {/* Progress Bar */}
         <div className="absolute top-4 left-4 right-4 z-20 flex gap-1">
            {items.map((_, idx) => (
               <div key={idx} className="h-1 flex-1 bg-white/30 rounded-full overflow-hidden">
                  <div 
                    className="h-full bg-white transition-all duration-100 ease-linear"
                    style={{ width: idx < currentItem ? '100%' : idx === currentItem ? `${progress}%` : '0%' }}
                  />
               </div>
            ))}
         </div>

         {/* Header */}
         <div className="absolute top-8 left-4 z-20 flex items-center gap-2">
            <img src={userStories.user.avatar_url} className="w-8 h-8 rounded-full border border-white" />
            <span className="text-white font-bold text-sm shadow-md">{userStories.user.full_name}</span>
            <span className="text-white/70 text-xs shadow-md">
               {new Date(currentStory.created_at).getHours()}h
            </span>
         </div>
         
         <button onClick={onClose} className="absolute top-8 right-4 z-20 text-white"><X /></button>

         {/* Content */}
         <div className="w-full h-full relative bg-gray-900 flex items-center justify-center">
             {currentStory.media_type === 'video' ? (
                <video src={currentStory.media_url} autoPlay muted className="w-full h-full object-contain" />
             ) : (
                <img src={currentStory.media_url} className="w-full h-full object-contain" />
             )}

             {/* Navigation Zones */}
             <div className="absolute inset-y-0 left-0 w-1/3 z-10" onClick={(e) => { e.stopPropagation(); if(currentItem > 0) { setCurrentItem(c=>c-1); setProgress(0); } else onPrev(); }}></div>
             <div className="absolute inset-y-0 right-0 w-1/3 z-10" onClick={(e) => { e.stopPropagation(); if(currentItem < items.length-1) { setCurrentItem(c=>c+1); setProgress(0); } else onNext(); }}></div>
         </div>
      </DialogContent>
    </Dialog>
  );
};

export default StoriesPage;