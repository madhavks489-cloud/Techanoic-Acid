
import React, { useState, useEffect } from 'react';
import { Loader2, Shield, UserX, Crown, LogOut, MoreVertical } from 'lucide-react';
import { supabase } from '@/lib/supabase';
import { useAuth } from '@/context/AuthContext';
import { useTheme } from '@/context/ThemeContext';
import { Button } from '@/components/ui/button';
import { useToast } from '@/components/ui/use-toast';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";

const CommunityMembersPanel = ({ channelId, isCreator, onClose }) => {
  const [members, setMembers] = useState([]);
  const [loading, setLoading] = useState(true);
  const { user } = useAuth();
  const { activeTheme } = useTheme();
  const { toast } = useToast();

  useEffect(() => {
    fetchMembers();
  }, [channelId]);

  const fetchMembers = async () => {
    setLoading(true);
    // Removed 'id' from selection as channel_members uses composite key
    const { data, error } = await supabase
      .from('channel_members')
      .select('*, profiles:user_id(*)')
      .eq('channel_id', channelId);

    if (!error && data) {
      setMembers(data);
    }
    setLoading(false);
  };

  const handleRemoveMember = async (memberId) => {
    const { error } = await supabase
      .from('channel_members')
      .delete()
      .eq('channel_id', channelId)
      .eq('user_id', memberId);

    if (!error) {
      setMembers(prev => prev.filter(m => m.user_id !== memberId));
      toast({ title: "Member Removed" });
    } else {
      toast({ title: "Error", description: "Failed to remove member", variant: "destructive" });
    }
  };

  const handleUpdateRole = async (memberId, newRole) => {
    const { error } = await supabase
      .from('channel_members')
      .update({ role: newRole })
      .eq('channel_id', channelId)
      .eq('user_id', memberId);

    if (!error) {
      setMembers(prev => prev.map(m => m.user_id === memberId ? { ...m, role: newRole } : m));
      toast({ title: "Role Updated", description: `User is now a ${newRole}` });
    } else {
      toast({ title: "Error", description: "Failed to update role", variant: "destructive" });
    }
  };

  const handleLeave = async () => {
     const { error } = await supabase
      .from('channel_members')
      .delete()
      .eq('channel_id', channelId)
      .eq('user_id', user.id);

    if (!error) {
       toast({ title: "Left Community" });
       onClose();
    }
  };

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between mb-4">
        <h3 className="font-bold text-lg" style={{ color: activeTheme.text_primary }}>Members ({members.length})</h3>
      </div>

      {loading ? (
        <div className="flex justify-center py-4">
           <Loader2 className="animate-spin w-6 h-6" style={{ color: activeTheme.accent_primary }} />
        </div>
      ) : (
        <div className="space-y-3">
           {members.map((member) => {
             const isMe = user && member.user_id === user.id;
             const isAdmin = member.role === 'admin' || member.role === 'owner';
             
             return (
               <div key={member.user_id} className="flex items-center justify-between p-2 rounded-lg" style={{ backgroundColor: activeTheme.bg_secondary }}>
                  <div className="flex items-center gap-3">
                     {member.profiles?.avatar_url ? (
                       <img src={member.profiles.avatar_url} className="w-10 h-10 rounded-full object-cover" alt="" />
                     ) : (
                       <div className="w-10 h-10 rounded-full flex items-center justify-center font-bold" style={{ backgroundColor: activeTheme.bg_primary, color: activeTheme.accent_primary }}>
                         {member.profiles?.full_name?.[0]}
                       </div>
                     )}
                     <div>
                       <p className="text-sm font-medium" style={{ color: activeTheme.text_primary }}>
                         {member.profiles?.full_name} 
                         {isMe && <span className="text-xs ml-1 opacity-70">(You)</span>}
                       </p>
                       <div className="flex items-center gap-1 text-xs opacity-70" style={{ color: activeTheme.text_secondary }}>
                          {isAdmin && <Shield className="w-3 h-3 text-amber-500" />}
                          <span>{member.role || 'Member'}</span>
                       </div>
                     </div>
                  </div>

                  {/* Actions */}
                  {isCreator && !isMe ? (
                    <DropdownMenu>
                      <DropdownMenuTrigger asChild>
                         <Button variant="ghost" size="sm" className="h-8 w-8 p-0">
                           <MoreVertical className="w-4 h-4" />
                         </Button>
                      </DropdownMenuTrigger>
                      <DropdownMenuContent>
                        {member.role !== 'admin' && (
                          <DropdownMenuItem onClick={() => handleUpdateRole(member.user_id, 'admin')}>
                             <Crown className="w-4 h-4 mr-2 text-amber-500" /> Make Admin
                          </DropdownMenuItem>
                        )}
                        {member.role === 'admin' && (
                          <DropdownMenuItem onClick={() => handleUpdateRole(member.user_id, 'member')}>
                             <Shield className="w-4 h-4 mr-2" /> Demote to Member
                          </DropdownMenuItem>
                        )}
                        <DropdownMenuItem onClick={() => handleRemoveMember(member.user_id)} className="text-red-500">
                           <UserX className="w-4 h-4 mr-2" /> Remove from Group
                        </DropdownMenuItem>
                      </DropdownMenuContent>
                    </DropdownMenu>
                  ) : isMe && !isCreator && (
                     <Button 
                       variant="ghost" 
                       size="sm" 
                       onClick={handleLeave}
                       className="text-red-500 hover:text-red-600 hover:bg-red-50"
                     >
                       <LogOut className="w-4 h-4" />
                     </Button>
                  )}
               </div>
             );
           })}
        </div>
      )}
    </div>
  );
};

export default CommunityMembersPanel;
