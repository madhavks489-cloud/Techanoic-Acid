import React, { useState, useEffect, useRef, useCallback } from 'react';
import { useAuth } from '@/context/AuthContext';
import { useLocationTracking } from '@/hooks/useLocationTracking';
import { calculateDistance } from '@/lib/locationUtils';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { useToast } from '@/components/ui/use-toast';
import { MapPin, Navigation, Search, List, Map as MapIcon, Loader2, AlertCircle } from 'lucide-react';

// Replace with your actual key
const GOOGLE_MAPS_API_KEY = "AIzaSyApmbTFq9Npf28jH8x6RZgbtoJDrbJsP68";

const DEFAULT_LOCATION = { lat: 40.7128, lng: -74.0060 }; // NYC fallback

const AdoptionCentresPage = () => {
  const { latitude: userLat, longitude: userLng } = useLocationTracking();
  const [viewMode, setViewMode] = useState('map');
  const [centres, setCentres] = useState([]);
  const [loading, setLoading] = useState(false);
  const [mapLoaded, setMapLoaded] = useState(false);
  const [selectedCentre, setSelectedCentre] = useState(null);
  const [searchQuery, setSearchQuery] = useState('');
  const [apiError, setApiError] = useState(null);

  const mapRef = useRef(null);
  const mapInstanceRef = useRef(null);
  const markersRef = useRef([]);
  const { toast } = useToast();

  /** Load Google Maps Script */
  useEffect(() => {
    if (!window.google) {
      if (GOOGLE_MAPS_API_KEY === "INSERT_GOOGLE_MAPS_API_KEY_HERE") {
        setApiError("Google Maps API Key missing. Please configure your API key.");
        return;
      }

      const script = document.createElement('script');
      script.src = `https://maps.googleapis.com/maps/api/js?key=${GOOGLE_MAPS_API_KEY}&libraries=places`;
      script.async = true;
      script.defer = true;
      script.onload = () => {
        setMapLoaded(true);
        setApiError(null);
      };
      script.onerror = () => {
        setApiError("Failed to load Google Maps. Please check your network or API key.");
        toast({
            title: "Map Error",
            description: "Unable to load Google Maps API.",
            variant: "destructive"
        });
      };
      document.head.appendChild(script);
    } else {
      setMapLoaded(true);
    }
  }, [toast]);

  /** Process search results */
  const processResults = useCallback((results, origin) => {
    // Clear markers
    markersRef.current.forEach((marker) => marker.setMap(null));
    markersRef.current = [];

    const mappedCentres = results.map((place) => {
      const lat = place.geometry.location.lat();
      const lng = place.geometry.location.lng();
      return {
        id: place.place_id,
        name: place.name,
        address: place.vicinity,
        latitude: lat,
        longitude: lng,
        rating: place.rating,
        openNow: place.opening_hours?.open_now,
        distance: origin ? calculateDistance(origin.lat, origin.lng, lat, lng) : 0,
      };
    });

    setCentres(mappedCentres);

    // Add markers
    mappedCentres.forEach((centre) => {
      const marker = new window.google.maps.Marker({
        position: { lat: centre.latitude, lng: centre.longitude },
        map: mapInstanceRef.current,
        title: centre.name,
        animation: window.google.maps.Animation.DROP,
      });

      marker.addListener('click', () => {
        setSelectedCentre(centre);
        mapInstanceRef.current.panTo(marker.getPosition());
      });

      markersRef.current.push(marker);
    });
  }, []);

  /** Search nearby adoption centres */
  const searchNearbyCentres = useCallback((location) => {
    if (!mapInstanceRef.current || !window.google) return;

    setLoading(true);
    setApiError(null);
    const service = new window.google.maps.places.PlacesService(mapInstanceRef.current);

    service.nearbySearch(
      {
        location,
        radius: 20000, // 20km for broader coverage
        keyword: 'pet adoption animal shelter rescue',
      },
      (results, status) => {
        setLoading(false);
        if (status === window.google.maps.places.PlacesServiceStatus.OK && results?.length) {
          processResults(results, location);
        } else if (status === window.google.maps.places.PlacesServiceStatus.ZERO_RESULTS) {
          setCentres([]);
          toast({
            title: "No Results",
            description: "No adoption centres found within 20km.",
            variant: "default"
          });
        } else {
          setCentres([]);
          console.error('Places search failed:', status);
          setApiError(`Search failed: ${status}`);
        }
      }
    );
  }, [processResults, toast]);

  /** Initialize Map */
  const initMap = useCallback(() => {
    if (!mapLoaded || mapInstanceRef.current || !mapRef.current) return;
    
    // Determine center: user location > fallback
    const center = (userLat && userLng) 
        ? { lat: userLat, lng: userLng } 
        : DEFAULT_LOCATION;

    try {
      mapInstanceRef.current = new window.google.maps.Map(mapRef.current, {
        center,
        zoom: 12,
        styles: [{ featureType: 'poi', elementType: 'labels', stylers: [{ visibility: 'off' }] }],
        mapTypeControl: false,
        fullscreenControl: false,
        streetViewControl: false,
      });

      // User marker
      if (userLat && userLng) {
        new window.google.maps.Marker({
          position: { lat: userLat, lng: userLng },
          map: mapInstanceRef.current,
          icon: {
            path: window.google.maps.SymbolPath.CIRCLE,
            scale: 8,
            fillColor: '#4285F4',
            fillOpacity: 1,
            strokeColor: '#ffffff',
            strokeWeight: 2,
          },
          title: 'You are here',
        });
      }

      searchNearbyCentres(center);
    } catch (e) {
      console.error("Error initializing map:", e);
      setApiError("Error initializing map interface.");
    }
  }, [mapLoaded, userLat, userLng, searchNearbyCentres]);

  useEffect(() => {
    initMap();
  }, [initMap]);

  /** Manual search */
  const handleManualSearch = () => {
    if (!searchQuery.trim()) return;
    if (!window.google || !mapInstanceRef.current) {
        toast({ title: "Map not ready", description: "Please wait for the map to load.", variant: "destructive" });
        return;
    }

    setLoading(true);
    const geocoder = new window.google.maps.Geocoder();
    geocoder.geocode({ address: searchQuery }, (results, status) => {
      if (status === 'OK' && results[0]) {
        const location = results[0].geometry.location;
        mapInstanceRef.current.setCenter(location);
        mapInstanceRef.current.setZoom(12);
        
        // Search relative to the new manual location
        searchNearbyCentres({ lat: location.lat(), lng: location.lng() });
      } else {
        setLoading(false);
        toast({
            title: "Location Not Found",
            description: "Could not find that location. Please try another.",
            variant: "destructive"
        });
      }
    });
  };

  return (
    <div className="h-screen flex flex-col bg-gray-50">
      {/* Header & Controls */}
      <div className="p-4 bg-white shadow-sm z-10">
        <div className="max-w-4xl mx-auto w-full flex flex-col sm:flex-row gap-4 items-center justify-between mb-4">
          <h1 className="text-2xl font-bold text-gray-900">Find Adoption Centres</h1>
          <div className="flex bg-gray-100 p-1 rounded-lg">
            <button
              onClick={() => setViewMode('map')}
              className={`px-4 py-2 text-sm rounded-md font-medium transition-all ${viewMode === 'map' ? 'bg-white shadow-sm text-blue-600' : 'text-gray-500'
                }`}
            >
              <MapIcon className="w-4 h-4 inline mr-2" /> Map
            </button>
            <button
              onClick={() => setViewMode('list')}
              className={`px-4 py-2 text-sm rounded-md font-medium transition-all ${viewMode === 'list' ? 'bg-white shadow-sm text-blue-600' : 'text-gray-500'
                }`}
            >
              <List className="w-4 h-4 inline mr-2" /> List
            </button>
          </div>
        </div>
        
        {apiError && (
            <div className="bg-red-50 text-red-700 p-3 rounded-md mb-3 flex items-center text-sm">
                <AlertCircle className="w-4 h-4 mr-2" />
                {apiError}
            </div>
        )}

        <div className="flex gap-2">
          <div className="relative flex-1">
            <Search className="absolute left-3 top-3 w-4 h-4 text-gray-400" />
            <Input
              placeholder="Search by city or zip code..."
              className="pl-10"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              onKeyDown={(e) => e.key === 'Enter' && handleManualSearch()}
            />
          </div>
          <Button onClick={handleManualSearch} disabled={loading || !!apiError}>
            {loading ? <Loader2 className="w-4 h-4 animate-spin" /> : 'Search'}
          </Button>
        </div>
      </div>

      {/* Main Content */}
      <div className="flex-1 relative">
        {/* Map View */}
        <div ref={mapRef} className={`w-full h-full ${viewMode === 'map' ? 'block' : 'hidden'}`} />

        {/* List View */}
        <div
          className={`w-full h-full overflow-y-auto p-4 ${viewMode === 'list' ? 'block' : 'hidden'}`}
        >
          <div className="max-w-2xl mx-auto space-y-4">
            {loading && (
              <div className="text-center py-10">
                <Loader2 className="animate-spin w-8 h-8 mx-auto text-blue-500" />
                <p className="mt-2 text-gray-500">Searching nearby adoption centres...</p>
              </div>
            )}
            
            {!loading && !apiError && centres.length === 0 && (
              <div className="text-center py-12 bg-white rounded-lg shadow-sm border border-gray-100">
                  <div className="bg-gray-100 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4">
                     <Search className="w-8 h-8 text-gray-400" />
                  </div>
                  <h3 className="text-lg font-medium text-gray-900">No adoption centres found</h3>
                  <p className="text-gray-500 mt-1">Try increasing your search radius or searching a different area.</p>
              </div>
            )}

            {centres.map((centre) => (
              <Card
                key={centre.id}
                className="hover:shadow-md transition-shadow cursor-pointer"
                onClick={() => {
                  setSelectedCentre(centre);
                  setViewMode('map');
                }}
              >
                <CardContent className="p-4">
                  <h3 className="font-bold text-lg text-gray-900">{centre.name}</h3>
                  <p className="text-gray-600 text-sm mb-2">{centre.address}</p>
                  <div className="flex items-center gap-4 text-sm text-gray-500">
                    {centre.rating && (
                      <span className="flex items-center text-amber-500">
                        <Search className="w-3 h-3 mr-1" /> {centre.rating}
                      </span>
                    )}
                    <span className="flex items-center text-blue-600">
                      <Navigation className="w-3 h-3 mr-1" /> {centre.distance.toFixed(1)} km away
                    </span>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>

        {/* Selected Centre Overlay */}
        {viewMode === 'map' && selectedCentre && (
          <div className="absolute bottom-6 left-1/2 -translate-x-1/2 w-full max-w-sm px-4 z-20">
            <Card className="shadow-lg border-0 overflow-hidden animate-in slide-in-from-bottom-5 fade-in duration-300">
              <div className="bg-blue-600 p-2 flex justify-end">
                <button
                  onClick={() => setSelectedCentre(null)}
                  className="text-white hover:bg-blue-700 rounded-full p-1"
                >
                  ✕
                </button>
              </div>
              <CardContent className="p-4">
                <h3 className="font-bold text-lg text-gray-900 mb-1">{selectedCentre.name}</h3>
                <p className="text-sm text-gray-600 mb-3">{selectedCentre.address}</p>

                <div className="grid grid-cols-2 gap-2 text-sm">
                  <div className="flex items-center text-gray-600">
                    <Navigation className="w-4 h-4 mr-2 text-blue-500" />
                    {selectedCentre.distance.toFixed(1)} km
                  </div>
                  {selectedCentre.openNow !== undefined && (
                    <div
                      className={`flex items-center ${selectedCentre.openNow ? 'text-green-600' : 'text-red-600'
                        }`}
                    >
                      <span className="w-2 h-2 rounded-full bg-current mr-2" />
                      {selectedCentre.openNow ? 'Open Now' : 'Closed'}
                    </div>
                  )}
                </div>

                <Button
                  className="w-full mt-4"
                  onClick={() =>
                    window.open(
                      `https://www.google.com/maps/dir/?api=1&destination_place_id=${selectedCentre.id}`,
                      '_blank'
                    )
                  }
                >
                  Get Directions
                </Button>
              </CardContent>
            </Card>
          </div>
        )}
      </div>
    </div>
  );
};

export default AdoptionCentresPage;