
import React, { useState, useEffect } from 'react';
import { Search, UserPlus, Loader2, MessageCircle } from 'lucide-react';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { useAuth } from '@/context/AuthContext';
import { useTheme } from '@/context/ThemeContext';
import { supabase } from '@/lib/supabase';
import { useToast } from '@/components/ui/use-toast';
import { useNavigate } from 'react-router-dom';

const UserSearchModal = ({ isOpen, onClose, onUserSelect }) => {
  const [query, setQuery] = useState('');
  const [results, setResults] = useState([]);
  const [loading, setLoading] = useState(false);
  const { user } = useAuth();
  const { activeTheme } = useTheme();
  const { toast } = useToast();

  useEffect(() => {
    if (isOpen) {
      setQuery('');
      setResults([]);
      fetchSuggestedUsers();
    }
  }, [isOpen]);

  const fetchSuggestedUsers = async () => {
    setLoading(true);
    // Fetch recent profiles excluding self
    const { data, error } = await supabase
      .from('profiles')
      .select('*')
      .neq('id', user.id)
      .limit(5);
    
    if (!error && data) {
      setResults(data);
    }
    setLoading(false);
  };

  const handleSearch = async (e) => {
    const val = e.target.value;
    setQuery(val);
    
    if (val.length < 2) {
      if (val.length === 0) fetchSuggestedUsers();
      return;
    }

    setLoading(true);
    const { data, error } = await supabase
      .from('profiles')
      .select('*')
      .neq('id', user.id)
      .or(`full_name.ilike.%${val}%,email.ilike.%${val}%`)
      .limit(10);

    if (!error && data) {
      setResults(data);
    }
    setLoading(false);
  };

  const handleStartChat = async (targetUser) => {
    try {
      setLoading(true);
      
      // Check if conversation exists
      // This is a simplified check. Ideally use a stored procedure or more complex query.
      // We'll check if we have a conversation with this user by intersecting participation.
      
      // 1. Get my conversations
      const { data: myConvos } = await supabase
        .from('conversation_participants')
        .select('conversation_id')
        .eq('user_id', user.id);
        
      const myConvoIds = myConvos.map(c => c.conversation_id);
      
      let conversationId = null;

      if (myConvoIds.length > 0) {
        // 2. Check if target user is in any of these conversations
        const { data: commonConvos } = await supabase
          .from('conversation_participants')
          .select('conversation_id')
          .in('conversation_id', myConvoIds)
          .eq('user_id', targetUser.id);
          
        if (commonConvos && commonConvos.length > 0) {
          conversationId = commonConvos[0].conversation_id;
        }
      }

      // 3. If not, create new conversation
      if (!conversationId) {
        const { data: newConvo, error: createError } = await supabase
          .from('conversations')
          .insert({})
          .select()
          .single();

        if (createError) throw createError;
        conversationId = newConvo.id;

        // Add participants
        await supabase.from('conversation_participants').insert([
          { conversation_id: conversationId, user_id: user.id },
          { conversation_id: conversationId, user_id: targetUser.id }
        ]);
      }

      onClose();
      if (onUserSelect) {
        onUserSelect({
          id: conversationId,
          otherUser: targetUser,
          lastMessage: { content: 'Start chatting!', created_at: new Date().toISOString() },
          unreadCount: 0
        });
      }

    } catch (error) {
      console.error('Error starting chat:', error);
      toast({
        title: "Error",
        description: "Could not start chat. Please try again.",
        variant: "destructive"
      });
    } finally {
      setLoading(false);
    }
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent 
        className="sm:max-w-md"
        style={{ 
          backgroundColor: activeTheme.bg_primary,
          borderColor: activeTheme.border_color,
          color: activeTheme.text_primary
        }}
      >
        <DialogHeader>
          <DialogTitle>New Message</DialogTitle>
        </DialogHeader>
        
        <div className="relative mb-4">
          <Search className="absolute left-3 top-2.5 w-4 h-4 text-gray-400" />
          <Input
            placeholder="Search by name or email..."
            value={query}
            onChange={handleSearch}
            className="pl-9"
            style={{
              backgroundColor: activeTheme.bg_secondary,
              borderColor: activeTheme.border_color,
              color: activeTheme.text_primary
            }}
          />
        </div>

        <div className="space-y-2 max-h-[300px] overflow-y-auto">
          {loading ? (
             <div className="flex justify-center py-8">
               <Loader2 className="w-6 h-6 animate-spin text-gray-400" />
             </div>
          ) : results.length > 0 ? (
            results.map(profile => (
              <div 
                key={profile.id}
                onClick={() => handleStartChat(profile)}
                className="flex items-center gap-3 p-3 rounded-lg hover:bg-black/5 dark:hover:bg-white/5 cursor-pointer transition-colors"
              >
                <div className="relative">
                   {profile.avatar_url ? (
                     <img src={profile.avatar_url} alt="" className="w-10 h-10 rounded-full object-cover" />
                   ) : (
                     <div 
                       className="w-10 h-10 rounded-full flex items-center justify-center text-sm font-bold"
                       style={{ backgroundColor: activeTheme.accent_tertiary, color: activeTheme.accent_primary }}
                     >
                       {profile.full_name?.[0]}
                     </div>
                   )}
                   {/* Online indicator placeholder - real implementation would need presence */}
                   <div className="absolute bottom-0 right-0 w-3 h-3 bg-green-500 rounded-full border-2 border-white dark:border-gray-800"></div>
                </div>
                
                <div className="flex-1">
                  <h4 className="font-medium text-sm">{profile.full_name}</h4>
                  <p className="text-xs opacity-70 truncate">{profile.bio || 'Pet lover'}</p>
                </div>
                
                <MessageCircle className="w-5 h-5 opacity-50" />
              </div>
            ))
          ) : (
            <div className="text-center py-8 opacity-50 text-sm">
              No users found.
            </div>
          )}
        </div>
      </DialogContent>
    </Dialog>
  );
};

export default UserSearchModal;
