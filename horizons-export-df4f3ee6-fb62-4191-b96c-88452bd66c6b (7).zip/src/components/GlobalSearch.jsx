
import React, { useState, useEffect } from 'react';
import { Search, X } from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';

const GlobalSearch = ({ onNavigate }) => {
  const [query, setQuery] = useState('');
  const [results, setResults] = useState({ users: [], threads: [] });
  const [showResults, setShowResults] = useState(false);

  useEffect(() => {
    if (query.length < 2) {
      setResults({ users: [], threads: [] });
      return;
    }

    const timer = setTimeout(() => {
      // Mock Search - normally this would be a Supabase query
      const threads = JSON.parse(localStorage.getItem('forum_threads') || '[]');
      const users = JSON.parse(localStorage.getItem('paws_user_list') || '[]'); // Mock user list

      const filteredThreads = threads.filter(t => t.title.toLowerCase().includes(query.toLowerCase()));
      
      setResults({
        threads: filteredThreads,
        users: [] // No real user list in local storage prototype
      });
      setShowResults(true);
    }, 300);

    return () => clearTimeout(timer);
  }, [query]);

  return (
    <div className="relative w-full max-w-md mx-auto mb-4 z-50">
      <div className="relative">
        <Search className="absolute left-3 top-3 w-5 h-5 text-gray-400" />
        <input 
          value={query}
          onChange={e => setQuery(e.target.value)}
          placeholder="Search forum, vets, pets..."
          className="w-full pl-10 pr-10 py-2.5 rounded-full border border-gray-200 shadow-sm focus:outline-none focus:ring-2 focus:ring-[#9CAF88] bg-white/90 backdrop-blur-sm"
          onFocus={() => query.length >= 2 && setShowResults(true)}
        />
        {query && (
          <button 
            onClick={() => { setQuery(''); setShowResults(false); }}
            className="absolute right-3 top-3 text-gray-400 hover:text-gray-600"
          >
            <X className="w-4 h-4" />
          </button>
        )}
      </div>

      <AnimatePresence>
        {showResults && (results.threads.length > 0 || results.users.length > 0) && (
          <motion.div
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: 10 }}
            className="absolute top-full left-0 right-0 mt-2 bg-white rounded-xl shadow-xl border border-gray-100 overflow-hidden"
          >
            <div className="max-h-60 overflow-y-auto">
              {results.threads.length > 0 && (
                <div className="p-2">
                  <h4 className="text-xs font-bold text-gray-400 uppercase px-2 mb-1">Forum Discussions</h4>
                  {results.threads.map(thread => (
                    <div 
                      key={thread.id}
                      onClick={() => {
                        onNavigate('forum', thread.id);
                        setShowResults(false);
                      }}
                      className="p-2 hover:bg-gray-50 rounded-lg cursor-pointer"
                    >
                      <p className="text-sm font-medium text-gray-900">{thread.title}</p>
                      <p className="text-xs text-gray-500">{thread.category}</p>
                    </div>
                  ))}
                </div>
              )}
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
};

export default GlobalSearch;
