
import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Bell, X, Check } from 'lucide-react';
import { supabase } from '@/lib/supabase';
import { useAuth } from '@/context/AuthContext';

const NotificationCenter = ({ isOpen, onClose }) => {
  const { user } = useAuth();
  const [notifications, setNotifications] = useState([]);

  useEffect(() => {
    if (user && isOpen) {
      fetchNotifications();
    }
  }, [user, isOpen]);

  const fetchNotifications = async () => {
    const { data } = await supabase
      .from('notifications')
      .select('*')
      .eq('user_id', user.id)
      .order('created_at', { ascending: false });
    if (data) setNotifications(data);
  };

  const markAsRead = async (id) => {
    await supabase.from('notifications').update({ is_read: true }).eq('id', id);
    setNotifications(prev => prev.map(n => n.id === id ? { ...n, is_read: true } : n));
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 bg-black/50 backdrop-blur-sm flex justify-end">
      <motion.div
        initial={{ x: '100%' }}
        animate={{ x: 0 }}
        exit={{ x: '100%' }}
        className="w-full max-w-md bg-white h-full shadow-2xl p-4 flex flex-col"
      >
        <div className="flex justify-between items-center mb-6">
          <h2 className="text-xl font-bold font-poppins">Notifications</h2>
          <button onClick={onClose}><X className="w-6 h-6 text-gray-500" /></button>
        </div>

        <div className="flex-1 overflow-y-auto space-y-4">
          {notifications.length === 0 ? (
             <div className="text-center py-10 text-gray-400">
               <Bell className="w-12 h-12 mx-auto mb-2 opacity-50" />
               <p>No new notifications</p>
             </div>
          ) : (
            notifications.map(n => (
              <div 
                key={n.id} 
                className={`p-4 rounded-xl border ${n.is_read ? 'bg-white border-gray-100' : 'bg-blue-50 border-blue-100'}`}
                onClick={() => markAsRead(n.id)}
              >
                <div className="flex gap-3">
                   <div className="w-2 h-2 mt-2 rounded-full bg-blue-500 opacity-0" style={{ opacity: n.is_read ? 0 : 1 }} />
                   <div>
                     <h4 className="font-bold text-sm text-gray-900">{n.title}</h4>
                     <p className="text-sm text-gray-600">{n.message}</p>
                     <span className="text-xs text-gray-400 mt-1 block">{new Date(n.created_at).toLocaleDateString()}</span>
                   </div>
                </div>
              </div>
            ))
          )}
        </div>
      </motion.div>
    </div>
  );
};

export default NotificationCenter;
