
import React, { useState } from 'react';
import { ArrowLeft } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { useToast } from '@/components/ui/use-toast';
import { useAuth } from '@/context/AuthContext';

const CreateThreadForm = ({ categoryId, onBack }) => {
  const [title, setTitle] = useState('');
  const [content, setContent] = useState('');
  const [category, setCategory] = useState(categoryId || 'general');
  const { user } = useAuth();
  const { toast } = useToast();

  const handleSubmit = (e) => {
    e.preventDefault();
    const newThread = {
      id: Date.now().toString(),
      title,
      content,
      category,
      authorId: user?.id || 'anon',
      authorName: user?.name || 'Anonymous',
      createdAt: new Date().toISOString(),
      likes: 0,
      comments: []
    };

    const threads = JSON.parse(localStorage.getItem('forum_threads') || '[]');
    localStorage.setItem('forum_threads', JSON.stringify([newThread, ...threads]));
    
    toast({ title: "Topic Created!" });
    onBack();
  };

  return (
    <div className="container mx-auto px-4 py-6 max-w-2xl">
      <button onClick={onBack} className="flex items-center gap-2 mb-6 text-gray-600">
        <ArrowLeft className="w-5 h-5" /> Back to Forum
      </button>
      
      <h1 className="text-2xl font-bold mb-6">Start New Discussion</h1>
      
      <form onSubmit={handleSubmit} className="space-y-4 bg-white p-6 rounded-xl shadow-lg">
        <div>
          <label className="block text-sm font-medium mb-1">Title</label>
          <input 
            required 
            value={title} 
            onChange={e => setTitle(e.target.value)}
            className="w-full p-3 border rounded-lg focus:ring-2 focus:ring-[#9CAF88] outline-none"
            placeholder="What's on your mind?"
          />
        </div>
        
        <div>
           <label className="block text-sm font-medium mb-1">Category</label>
           <select 
             value={category}
             onChange={e => setCategory(e.target.value)}
             className="w-full p-3 border rounded-lg"
           >
             <option value="general">General Chat</option>
             <option value="health">Pet Health</option>
             <option value="nutrition">Nutrition</option>
             <option value="behavior">Behavior & Training</option>
           </select>
        </div>

        <div>
          <label className="block text-sm font-medium mb-1">Details</label>
          <textarea 
            required 
            value={content} 
            onChange={e => setContent(e.target.value)}
            className="w-full p-3 border rounded-lg h-32 focus:ring-2 focus:ring-[#9CAF88] outline-none"
            placeholder="Provide more context..."
          />
        </div>

        <Button type="submit" className="w-full bg-[#9CAF88]">Post Topic</Button>
      </form>
    </div>
  );
};

export default CreateThreadForm;
