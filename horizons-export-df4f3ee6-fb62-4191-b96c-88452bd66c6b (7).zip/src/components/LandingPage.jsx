
import React from 'react';
import { Helmet } from 'react-helmet';
import { motion } from 'framer-motion';
import { Heart, Star, Lock, ArrowRight } from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import PetButton from '@/components/ui/PetButton';
import PetCard from '@/components/ui/PetCard';

const LandingPage = () => {
  const navigate = useNavigate();

  const features = [
    {
      icon: <Heart className="w-8 h-8" />,
      title: 'Connect with Pet Lovers',
      description: 'Share moments, make friends, and build a community of pet enthusiasts.'
    },
    {
      icon: <Star className="w-8 h-8" />,
      title: 'Expert Advice',
      description: 'Get professional tips from certified vets and experienced trainers.'
    },
    {
      icon: <Lock className="w-8 h-8" />,
      title: 'Pet Health Vault',
      description: 'Securely store and manage your pet\'s health records and documents.'
    }
  ];

  return (
    <>
      <Helmet>
        <title>Paws & Pals - The Ultimate Pet Community</title>
        <meta name="description" content="Join Paws & Pals, the social network for pet lovers." />
      </Helmet>
      
      <div className="min-h-screen">
        {/* Hero Section */}
        <section className="container mx-auto px-6 py-12 md:py-24 max-w-6xl">
          <div className="grid md:grid-cols-2 gap-12 items-center">
            <motion.div
              initial={{ opacity: 0, x: -50 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.8, ease: 'easeOut' }}
            >
              <h1 className="text-5xl md:text-7xl font-bold mb-6 text-[var(--text-primary)] leading-tight tracking-tight">
                Welcome to <br />
                <span className="text-gradient">Paws & Pals</span>
              </h1>
              <p className="text-lg md:text-xl text-[var(--text-secondary)] mb-8 leading-relaxed max-w-lg">
                Where every tail wags, every whisker twitches, and every pet parent finds their perfect community. Join thousands of pet lovers today.
              </p>
              <div className="flex gap-4">
                <PetButton
                  onClick={() => navigate('/signup')}
                  className="px-8 py-4 text-lg"
                >
                  Get Started <ArrowRight className="ml-2 w-5 h-5" />
                </PetButton>
                <PetButton
                  variant="outline"
                  onClick={() => navigate('/signin')}
                  className="px-8 py-4 text-lg"
                >
                  Sign In
                </PetButton>
              </div>
            </motion.div>
            
            <motion.div
              initial={{ opacity: 0, scale: 0.9 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ duration: 0.8, ease: 'easeOut', delay: 0.2 }}
              className="relative"
            >
              <div className="absolute inset-0 bg-[var(--accent-primary)] rounded-[3rem] opacity-20 blur-3xl transform rotate-6"></div>
              <motion.div 
                animate={{ y: [-10, 10, -10] }}
                transition={{ duration: 5, repeat: Infinity, ease: 'easeInOut' }}
                className="rounded-[3rem] overflow-hidden shadow-2xl relative border-8 border-white"
              >
                <img
                  src="https://images.unsplash.com/photo-1543466835-00a7907e9de1?q=80&w=1974&auto=format&fit=crop"
                  alt="Happy Dog"
                  className="w-full h-[500px] object-cover"
                />
              </motion.div>
            </motion.div>
          </div>
        </section>

        {/* Features Section */}
        <section className="py-20 bg-white/50 backdrop-blur-sm">
          <div className="container mx-auto px-6 max-w-6xl">
            <motion.h2
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.6 }}
              className="text-3xl md:text-4xl font-bold text-center mb-16 text-[var(--text-primary)]"
            >
              Everything Your Pet Needs
            </motion.h2>
            
            <div className="grid md:grid-cols-3 gap-8">
              {features.map((feature, index) => (
                <PetCard
                  key={index}
                  initial={{ opacity: 0, y: 30 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  viewport={{ once: true }}
                  transition={{ duration: 0.6, delay: index * 0.2 }}
                  className="h-full"
                >
                  <div className="w-16 h-16 rounded-2xl flex items-center justify-center mb-6 bg-[var(--pet-green-soft)] text-[var(--accent-primary)]">
                    {feature.icon}
                  </div>
                  <h3 className="text-xl font-bold mb-4 text-[var(--text-primary)]">{feature.title}</h3>
                  <p className="text-[var(--text-secondary)] leading-relaxed">{feature.description}</p>
                </PetCard>
              ))}
            </div>
          </div>
        </section>
      </div>
    </>
  );
};

export default LandingPage;
