
import React, { useState, useEffect, useRef } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Send, Bot, User, Trash2, Sparkles } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { useAuth } from '@/context/AuthContext';
import { supabase } from '@/lib/supabase';
import { useToast } from '@/components/ui/use-toast';

const AIAssistant = () => {
  const [messages, setMessages] = useState([
    { role: 'assistant', content: "Hello! I'm your Paws & Pals expert. I can help with pet health, nutrition, training, and behavior. What's on your mind today?" }
  ]);
  const [inputText, setInputText] = useState('');
  const [loading, setLoading] = useState(false);
  const scrollRef = useRef(null);
  const { user } = useAuth();
  const { toast } = useToast();

  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  const scrollToBottom = () => {
    if (scrollRef.current) {
      scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
    }
  };

  const handleSend = async (e) => {
    e.preventDefault();
    if (!inputText.trim() || loading) return;

    const userMessage = { role: 'user', content: inputText };
    setMessages(prev => [...prev, userMessage]);
    setInputText('');
    setLoading(true);

    try {
      const conversationHistory = messages.slice(-10).map(m => ({
        role: m.role,
        content: m.content
      }));
      conversationHistory.push(userMessage);

      // Ensure we have a session before calling
      const { data: { session } } = await supabase.auth.getSession();
      
      if (!session) {
        throw new Error("Authentication required. Please log in.");
      }

      const { data, error } = await supabase.functions.invoke('ask-pet-expert', {
        body: { messages: conversationHistory },
        method: 'POST',
        // Explicitly set headers to ensure auth is passed correctly
        headers: {
          Authorization: `Bearer ${session.access_token}`
        }
      });

      if (error) throw error;

      if (data && data.response) {
        setMessages(prev => [...prev, { role: 'assistant', content: data.response }]);
      } else {
        throw new Error("No response from AI");
      }
    } catch (error) {
      console.error('AI Error:', error);
      
      let errorMessage = "I'm having trouble connecting right now. Please try again later.";
      if (error.message && (error.message.includes('apikey') || error.message.includes('Authorization'))) {
        errorMessage = "Configuration Error: API Key missing or invalid. Please check Supabase settings.";
      }

      setMessages(prev => [...prev, { 
        role: 'assistant', 
        content: errorMessage,
        isError: true 
      }]);
      
      toast({
        title: "Error",
        description: "Failed to get response from AI Expert.",
        variant: "destructive",
      });
    } finally {
      setLoading(false);
    }
  };

  const clearChat = () => {
    setMessages([{ role: 'assistant', content: "Chat cleared. How can I help you with your pet today?" }]);
  };

  return (
    <div className="flex flex-col h-[calc(100vh-80px)] bg-[var(--bg-secondary)]">
      <div className="bg-[var(--bg-primary)] p-4 shadow-sm flex items-center justify-between z-10 border-b border-[var(--border-color)]">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 bg-[var(--accent-primary)] rounded-full flex items-center justify-center text-white shadow-md">
            <Bot className="w-6 h-6" />
          </div>
          <div>
            <h1 className="font-bold text-[var(--text-primary)] font-poppins">Pet Expert AI</h1>
            <div className="flex items-center gap-1.5">
               <span className="w-2 h-2 bg-green-500 rounded-full animate-pulse"></span>
               <p className="text-xs text-[var(--text-secondary)]">Online & Ready</p>
            </div>
          </div>
        </div>
        <Button variant="ghost" size="icon" onClick={clearChat} className="text-[var(--text-secondary)] hover:text-red-500 hover:bg-red-50">
          <Trash2 className="w-5 h-5" />
        </Button>
      </div>

      <div ref={scrollRef} className="flex-1 overflow-y-auto p-4 space-y-6">
        <AnimatePresence initial={false}>
          {messages.map((msg, index) => {
            const isAi = msg.role === 'assistant';
            return (
              <motion.div
                key={index}
                initial={{ opacity: 0, y: 20, scale: 0.95 }}
                animate={{ opacity: 1, y: 0, scale: 1 }}
                transition={{ duration: 0.3 }}
                className={`flex ${isAi ? 'justify-start' : 'justify-end'}`}
              >
                <div className={`flex gap-3 max-w-[85%] ${isAi ? 'flex-row' : 'flex-row-reverse'}`}>
                  <div className={`w-8 h-8 rounded-full flex-shrink-0 flex items-center justify-center ${
                    isAi ? 'bg-[var(--accent-primary)] text-white' : 'bg-blue-100 text-blue-600'
                  }`}>
                    {isAi ? <Bot className="w-4 h-4" /> : <User className="w-4 h-4" />}
                  </div>
                  
                  <div className="flex flex-col gap-1">
                     <div 
                       className={`p-4 rounded-2xl text-sm shadow-sm leading-relaxed whitespace-pre-wrap ${
                         isAi 
                           ? `bg-[var(--bg-primary)] text-[var(--text-primary)] rounded-tl-none border border-[var(--border-color)] ${msg.isError ? 'border-red-200 bg-red-50 text-red-800' : ''}` 
                           : 'bg-blue-500 text-white rounded-tr-none'
                       }`}
                     >
                       {msg.content}
                     </div>
                     <span className={`text-[10px] text-[var(--text-secondary)] ${isAi ? 'text-left ml-1' : 'text-right mr-1'}`}>
                       {new Date().toLocaleTimeString([], {hour: '2-digit', minute:'2-digit'})}
                     </span>
                  </div>
                </div>
              </motion.div>
            );
          })}
        </AnimatePresence>
        
        {loading && (
          <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="flex justify-start">
             <div className="flex gap-3 max-w-[85%]">
               <div className="w-8 h-8 rounded-full bg-[var(--accent-primary)] flex items-center justify-center text-white">
                 <Bot className="w-4 h-4" />
               </div>
               <div className="bg-[var(--bg-primary)] p-4 rounded-2xl rounded-tl-none border border-[var(--border-color)] shadow-sm flex items-center gap-1 h-12">
                 <div className="w-2 h-2 bg-gray-400 rounded-full animate-bounce" style={{ animationDelay: '0s' }}></div>
                 <div className="w-2 h-2 bg-gray-400 rounded-full animate-bounce" style={{ animationDelay: '0.15s' }}></div>
                 <div className="w-2 h-2 bg-gray-400 rounded-full animate-bounce" style={{ animationDelay: '0.3s' }}></div>
               </div>
             </div>
          </motion.div>
        )}
      </div>

      <div className="p-4 bg-[var(--bg-primary)] border-t border-[var(--border-color)]">
         <form onSubmit={handleSend} className="relative flex items-center gap-2 max-w-2xl mx-auto">
            <input 
              value={inputText}
              onChange={(e) => setInputText(e.target.value)}
              placeholder="Ask about your pet..."
              className="w-full pl-4 pr-12 py-3 bg-[var(--input-bg)] text-[var(--text-primary)] rounded-full border border-[var(--border-color)] focus:outline-none focus:ring-2 focus:ring-[var(--accent-primary)] focus:border-transparent transition-all"
              disabled={loading}
            />
            <Button 
              type="submit" 
              size="icon" 
              disabled={!inputText.trim() || loading}
              className={`absolute right-1 top-1 bottom-1 w-10 h-10 rounded-full transition-all ${
                !inputText.trim() || loading ? 'bg-[var(--border-color)] text-[var(--text-secondary)]' : 'bg-[var(--accent-primary)] text-white shadow-md hover:opacity-90'
              }`}
            >
              <Send className="w-4 h-4 ml-0.5" />
            </Button>
         </form>
         <div className="text-center mt-2">
            <p className="text-[10px] text-[var(--text-secondary)] flex items-center justify-center gap-1">
              <Sparkles className="w-3 h-3" /> AI advice is for informational purposes only. Consult a vet for emergencies.
            </p>
         </div>
      </div>
    </div>
  );
};

export default AIAssistant;
