
import React, { useState, useEffect } from 'react';
import { supabase } from '@/lib/supabase';
import { useTheme } from '@/context/ThemeContext';
import { useAuth } from '@/context/AuthContext';
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { useToast } from '@/components/ui/use-toast';
import { Users, Shield, AlertTriangle, FileText, Search, Trash2, CheckCircle } from 'lucide-react';

const AdminDashboard = () => {
  const { activeTheme } = useTheme();
  const { user } = useAuth();
  const { toast } = useToast();
  
  const [stats, setStats] = useState({ users: 0, posts: 0, questions: 0 });
  const [usersList, setUsersList] = useState([]);
  const [actionsLog, setActionsLog] = useState([]);
  const [loading, setLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState('');

  useEffect(() => {
    fetchStats();
    fetchUsers();
    fetchLogs();
    
    // Subscribe to logs
    const logSub = supabase.channel('admin_logs')
      .on('postgres_changes', { event: 'INSERT', schema: 'public', table: 'admin_actions' }, (payload) => {
         setActionsLog(prev => [payload.new, ...prev]);
      })
      .subscribe();

    return () => supabase.removeChannel(logSub);
  }, []);

  const fetchStats = async () => {
    const { count: userCount } = await supabase.from('profiles').select('*', { count: 'exact', head: true });
    const { count: postCount } = await supabase.from('feed_posts').select('*', { count: 'exact', head: true });
    const { count: qCount } = await supabase.from('qa_questions').select('*', { count: 'exact', head: true });
    
    setStats({ users: userCount || 0, posts: postCount || 0, questions: qCount || 0 });
  };

  const fetchUsers = async () => {
    const { data } = await supabase.from('profiles').select('*').order('created_at', { ascending: false }).limit(50);
    setUsersList(data || []);
  };

  const fetchLogs = async () => {
    const { data } = await supabase
      .from('admin_actions')
      .select('*, profiles:admin_id(full_name)')
      .order('created_at', { ascending: false })
      .limit(20);
    setActionsLog(data || []);
  };

  const updateUserRole = async (targetUserId, newRole) => {
    try {
       const { error } = await supabase.from('profiles').update({ role: newRole }).eq('id', targetUserId);
       if (error) throw error;
       
       // Log action
       await supabase.from('admin_actions').insert({
          admin_id: user.id,
          action_type: 'UPDATE_ROLE',
          target_id: targetUserId,
          target_type: 'profiles',
          reason: `Role changed to ${newRole}`
       });

       setUsersList(prev => prev.map(u => u.id === targetUserId ? { ...u, role: newRole } : u));
       toast({ title: "Role updated successfully" });
    } catch (error) {
       toast({ title: "Failed to update role", variant: "destructive" });
    }
  };

  const filteredUsers = usersList.filter(u => 
    u.full_name?.toLowerCase().includes(searchTerm.toLowerCase()) || 
    u.username?.toLowerCase().includes(searchTerm.toLowerCase())
  );

  return (
    <div className="min-h-screen p-6 pb-24" style={{ backgroundColor: activeTheme.bg_secondary }}>
       <h1 className="text-3xl font-bold mb-8 text-gray-900">Admin Dashboard</h1>

       {/* Stats Overview */}
       <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
               <CardTitle className="text-sm font-medium">Total Users</CardTitle>
               <Users className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
               <div className="text-2xl font-bold">{stats.users}</div>
            </CardContent>
          </Card>
          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
               <CardTitle className="text-sm font-medium">Total Posts</CardTitle>
               <FileText className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
               <div className="text-2xl font-bold">{stats.posts}</div>
            </CardContent>
          </Card>
          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
               <CardTitle className="text-sm font-medium">Questions Asked</CardTitle>
               <AlertTriangle className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
               <div className="text-2xl font-bold">{stats.questions}</div>
            </CardContent>
          </Card>
       </div>

       <Tabs defaultValue="users" className="space-y-4">
         <TabsList>
           <TabsTrigger value="users">User Management</TabsTrigger>
           <TabsTrigger value="logs">Action Logs</TabsTrigger>
         </TabsList>

         <TabsContent value="users">
            <Card>
              <CardHeader>
                <CardTitle>Users</CardTitle>
                <CardDescription>Manage user roles and permissions</CardDescription>
                <div className="relative mt-2">
                   <Search className="absolute left-2 top-2.5 h-4 w-4 text-muted-foreground" />
                   <Input 
                      placeholder="Search users..." 
                      className="pl-8" 
                      value={searchTerm}
                      onChange={e => setSearchTerm(e.target.value)}
                   />
                </div>
              </CardHeader>
              <CardContent>
                 <div className="space-y-4">
                    {filteredUsers.map(userItem => (
                       <div key={userItem.id} className="flex items-center justify-between p-4 border rounded-lg bg-white">
                          <div>
                             <p className="font-medium">{userItem.full_name || 'No Name'}</p>
                             <p className="text-sm text-gray-500">@{userItem.username}</p>
                             <span className={`text-xs px-2 py-0.5 rounded-full ${
                                userItem.role === 'admin' ? 'bg-purple-100 text-purple-700' :
                                userItem.role === 'moderator' ? 'bg-blue-100 text-blue-700' :
                                'bg-gray-100 text-gray-700'
                             }`}>
                                {userItem.role || 'user'}
                             </span>
                          </div>
                          <div className="flex gap-2">
                             {userItem.role !== 'admin' && (
                                <Button size="sm" variant="outline" onClick={() => updateUserRole(userItem.id, 'admin')}>
                                   Make Admin
                                </Button>
                             )}
                             {userItem.role !== 'moderator' && (
                                <Button size="sm" variant="outline" onClick={() => updateUserRole(userItem.id, 'moderator')}>
                                   Make Mod
                                </Button>
                             )}
                             {userItem.role !== 'user' && (
                                <Button size="sm" variant="outline" onClick={() => updateUserRole(userItem.id, 'user')}>
                                   Demote
                                </Button>
                             )}
                          </div>
                       </div>
                    ))}
                 </div>
              </CardContent>
            </Card>
         </TabsContent>

         <TabsContent value="logs">
            <Card>
               <CardHeader>
                  <CardTitle>Recent Admin Actions</CardTitle>
               </CardHeader>
               <CardContent>
                  <div className="space-y-4">
                     {actionsLog.map(log => (
                        <div key={log.id} className="border-b pb-4 last:border-0">
                           <div className="flex justify-between">
                              <span className="font-bold text-sm">{log.action_type}</span>
                              <span className="text-xs text-gray-500">{new Date(log.created_at).toLocaleString()}</span>
                           </div>
                           <p className="text-sm">By: {log.profiles?.full_name}</p>
                           <p className="text-sm text-gray-600">Reason: {log.reason}</p>
                           <p className="text-xs text-gray-400 font-mono mt-1">Target ID: {log.target_id}</p>
                        </div>
                     ))}
                     {actionsLog.length === 0 && <p className="text-gray-500 text-center py-4">No actions recorded yet.</p>}
                  </div>
               </CardContent>
            </Card>
         </TabsContent>
       </Tabs>
    </div>
  );
};

export default AdminDashboard;
