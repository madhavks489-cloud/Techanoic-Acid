import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Heart, MessageCircle, Trash2, X, ZoomIn } from 'lucide-react';
import { supabase } from '@/lib/supabase';
import { Button } from '@/components/ui/button';
import { useToast } from '@/components/ui/use-toast';
import { Dialog, DialogContent, DialogTrigger } from '@/components/ui/dialog';
import VerifiedVetBadge from '@/components/VerifiedVetBadge';

const FeedPost = ({ post, currentUser }) => {
  const [liked, setLiked] = useState(post.post_likes?.some(l => l.user_id === currentUser.id));
  const [likeCount, setLikeCount] = useState(post.likes_count || post.post_likes?.length || 0);
  const [showComments, setShowComments] = useState(false);
  const [comments, setComments] = useState([]);
  const [newComment, setNewComment] = useState('');
  const [isImageOpen, setIsImageOpen] = useState(false);
  const { toast } = useToast();

  const isOwner = currentUser.id === post.user_id;

  useEffect(() => {
    if (showComments) {
      fetchComments();
    }
  }, [showComments]);

  const fetchComments = async () => {
    const { data } = await supabase
      .from('comments')
      .select('*, profiles:user_id(full_name)')
      .eq('post_id', post.id)
      .order('created_at', { ascending: true });
    if (data) setComments(data);
  };

  const handleLike = async () => {
    if (liked) {
      setLikeCount(prev => prev - 1);
      setLiked(false);
      await supabase.from('post_likes').delete().match({ post_id: post.id, user_id: currentUser.id });
    } else {
      setLikeCount(prev => prev + 1);
      setLiked(true);
      await supabase.from('post_likes').insert({ post_id: post.id, user_id: currentUser.id });
    }
  };

  const handleDelete = async () => {
    if (!window.confirm("Delete this post?")) return;
    const { error } = await supabase.from('feed_posts').delete().eq('id', post.id);
    if (error) {
      toast({ title: "Error", description: "Failed to delete post", variant: "destructive" });
    } else {
      toast({ title: "Deleted", description: "Post removed successfully" });
    }
  };

  const handleSendComment = async (e) => {
    e.preventDefault();
    if (!newComment.trim()) return;

    const { error } = await supabase.from('comments').insert({
      post_id: post.id,
      user_id: currentUser.id,
      content: newComment
    });

    if (error) {
      toast({ title: "Error", variant: "destructive" });
    } else {
      setNewComment('');
      fetchComments();
    }
  };

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      className="bg-white rounded-xl shadow-lg overflow-hidden border border-gray-100"
    >
      {/* Header */}
      <div className="p-4 flex items-center justify-between">
        <div className="flex items-center gap-3">
          {post.pets?.photo_url ? (
            <img src={post.pets.photo_url} alt="" className="w-10 h-10 rounded-full object-cover border-2 border-[#9CAF88]" />
          ) : (
             <div className="w-10 h-10 bg-gray-200 rounded-full" />
          )}
          <div>
            <div className="flex items-center gap-2">
              <span className="font-bold text-gray-900 text-sm">
                {post.pets?.name || post.profiles?.full_name || 'Unknown User'}
              </span>
              {post.profiles?.role === 'verified_vet' && <VerifiedVetBadge />}
            </div>
            <span className="text-xs text-gray-500">
              {post.pets?.breed || 'Pet Owner'} • {new Date(post.created_at).toLocaleDateString()}
            </span>
          </div>
        </div>
        {isOwner && (
          <Button variant="ghost" size="icon" onClick={handleDelete} className="text-gray-400 hover:text-red-500">
            <Trash2 className="w-4 h-4" />
          </Button>
        )}
      </div>

      {/* Image */}
      {post.image_url && (
        <Dialog open={isImageOpen} onOpenChange={setIsImageOpen}>
          <DialogTrigger asChild>
             <div className="w-full h-80 relative overflow-hidden bg-gray-50 cursor-pointer group">
                <img 
                  src={post.image_url} 
                  alt="Post" 
                  className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-105" 
                />
                <div className="absolute inset-0 bg-black/0 group-hover:bg-black/10 transition-colors flex items-center justify-center opacity-0 group-hover:opacity-100">
                   <ZoomIn className="text-white w-8 h-8 drop-shadow-md" />
                </div>
             </div>
          </DialogTrigger>
          <DialogContent className="max-w-4xl p-0 overflow-hidden bg-black/90 border-none">
            <div className="relative w-full h-full flex items-center justify-center p-4">
               <button 
                 onClick={() => setIsImageOpen(false)} 
                 className="absolute top-4 right-4 text-white hover:text-gray-300 z-50 bg-black/50 rounded-full p-2"
               >
                 <X className="w-6 h-6" />
               </button>
               <img src={post.image_url} alt="Full size" className="max-w-full max-h-[85vh] object-contain rounded-md" />
            </div>
          </DialogContent>
        </Dialog>
      )}

      {/* Actions */}
      <div className="p-4">
        <div className="flex items-center gap-4 mb-3">
          <button onClick={handleLike} className="flex items-center gap-1 group">
            <Heart className={`w-6 h-6 transition-colors ${liked ? 'fill-red-500 text-red-500' : 'text-gray-600 group-hover:text-red-500'}`} />
            <span className="text-sm font-semibold">{likeCount}</span>
          </button>
          <button onClick={() => setShowComments(!showComments)} className="flex items-center gap-1 group">
            <MessageCircle className="w-6 h-6 text-gray-600 group-hover:text-[#9CAF88] transition-colors" />
            <span className="text-sm font-semibold">{comments.length > 0 ? comments.length : ''}</span>
          </button>
        </div>

        <p className="text-gray-800 text-sm mb-4">
          <span className="font-bold mr-2">{post.profiles?.full_name}:</span>
          {post.content}
        </p>

        {/* Comments Section */}
        {showComments && (
          <motion.div initial={{ height: 0, opacity: 0 }} animate={{ height: 'auto', opacity: 1 }} className="border-t pt-3">
            <div className="space-y-3 mb-3 max-h-40 overflow-y-auto">
              {comments.map(c => (
                <div key={c.id} className="text-sm">
                  <span className="font-bold mr-2">{c.profiles?.full_name}:</span>
                  <span className="text-gray-600">{c.content}</span>
                </div>
              ))}
            </div>
            <form onSubmit={handleSendComment} className="flex gap-2">
              <input
                value={newComment}
                onChange={e => setNewComment(e.target.value)}
                placeholder="Add a comment..."
                className="flex-1 bg-gray-50 rounded-full px-3 py-2 text-sm focus:outline-none focus:ring-1 focus:ring-[#9CAF88]"
              />
              <button type="submit" className="text-[#9CAF88] font-bold text-sm">Post</button>
            </form>
          </motion.div>
        )}
      </div>
    </motion.div>
  );
};

export default FeedPost;