import React, { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { MessageSquare, Heart, Bone, Brain, Activity, Plus, Search, MessageCircle, Image as ImageIcon, X, Loader2 } from 'lucide-react';
import { supabase } from '@/lib/supabase';
import { Button } from '@/components/ui/button';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { useAuth } from '@/context/AuthContext';
import { useTheme } from '@/context/ThemeContext';
import ForumThread from './ForumThread';

const categories = [
  { id: 'Health', name: 'Pet Health', icon: Activity },
  { id: 'Nutrition', name: 'Nutrition', icon: Bone },
  { id: 'Behavior', name: 'Behavior', icon: Brain },
  { id: 'Training', name: 'Training', icon: Activity },
  { id: 'General', name: 'General Chat', icon: MessageSquare },
];

const ForumPage = () => {
  const { activeTheme } = useTheme();
  const [activeCategory, setActiveCategory] = useState(null);
  const [activeThreadId, setActiveThreadId] = useState(null);
  const [threads, setThreads] = useState([]);
  const [replyCounts, setReplyCounts] = useState({});
  const [loading, setLoading] = useState(true);
  const [isCreateOpen, setIsCreateOpen] = useState(false);
  const [newThread, setNewThread] = useState({ title: '', content: '', category: 'General' });
  const [searchQuery, setSearchQuery] = useState('');
  
  const [selectedFile, setSelectedFile] = useState(null);
  const [previewUrl, setPreviewUrl] = useState(null);
  const [uploading, setUploading] = useState(false);

  const { user } = useAuth();

  useEffect(() => {
    fetchThreads();
    const sub = supabase.channel('public:forum_threads')
      .on('postgres_changes', { event: '*', schema: 'public', table: 'forum_threads' }, fetchThreads)
      .subscribe();
      
    // Subscribe to reply changes to update counts
    const replySub = supabase.channel('public:forum_replies_count')
      .on('postgres_changes', { event: '*', schema: 'public', table: 'forum_replies' }, () => {
         // In a real app we might increment locally, but re-fetching counts is safer for consistency
         fetchReplyCounts();
      })
      .subscribe();

    return () => {
      supabase.removeChannel(sub);
      supabase.removeChannel(replySub);
    };
  }, []); 

  const fetchReplyCounts = async () => {
      const { data, error } = await supabase
        .from('forum_replies')
        .select('thread_id');
      
      if (data) {
          const counts = {};
          data.forEach(reply => {
              counts[reply.thread_id] = (counts[reply.thread_id] || 0) + 1;
          });
          setReplyCounts(counts);
      }
  };

  const fetchThreads = async () => {
    let query = supabase
      .from('forum_threads')
      .select('*, profiles:author_id(full_name)')
      .order('created_at', { ascending: false });
    
    const { data } = await query;
    if (data) {
      setThreads(data);
      fetchReplyCounts(); // Fetch counts after we get threads
    }
    setLoading(false);
  };

  const handleFileSelect = (e) => {
    const file = e.target.files[0];
    if (file) {
      setSelectedFile(file);
      setPreviewUrl(URL.createObjectURL(file));
    }
  };

  const clearFile = () => {
    setSelectedFile(null);
    setPreviewUrl(null);
  };

  const handleCreateThread = async () => {
    if (!newThread.title || !newThread.content) return;
    setUploading(true);

    try {
      let imageUrl = null;
      if (selectedFile) {
        const fileExt = selectedFile.name.split('.').pop();
        const fileName = `${Math.random()}.${fileExt}`;
        const filePath = `${user.id}/${fileName}`;
        
        const { error: uploadError } = await supabase.storage
          .from('forum_images')
          .upload(filePath, selectedFile);
        
        if (uploadError) throw uploadError;
        
        const { data: publicUrlData } = supabase.storage
          .from('forum_images')
          .getPublicUrl(filePath);
        
        imageUrl = publicUrlData.publicUrl;
      }

      await supabase.from('forum_threads').insert({
        author_id: user.id,
        title: newThread.title,
        content: newThread.content,
        category: newThread.category,
        image_url: imageUrl,
        likes_count: 0,
        views_count: 0
      });
      
      setNewThread({ title: '', content: '', category: 'General' });
      clearFile();
      setIsCreateOpen(false);
    } catch (error) {
      console.error("Error creating thread:", error);
    } finally {
      setUploading(false);
    }
  };

  const filteredThreads = threads.filter(thread => {
    const matchesCategory = activeCategory ? thread.category === activeCategory : true;
    const matchesSearch = searchQuery 
      ? thread.title.toLowerCase().includes(searchQuery.toLowerCase()) || 
        thread.content.toLowerCase().includes(searchQuery.toLowerCase())
      : true;
    return matchesCategory && matchesSearch;
  });

  if (activeThreadId) {
    return <ForumThread threadId={activeThreadId} onBack={() => setActiveThreadId(null)} />;
  }

  return (
    <div className="container mx-auto px-4 py-6 max-w-2xl min-h-screen pb-24" style={{ backgroundColor: activeTheme.bg_secondary }}>
      <div className="flex justify-between items-center mb-6">
        <h1 className="text-3xl font-bold font-poppins" style={{ color: activeTheme.text_primary }}>Forum</h1>
        
        <Dialog open={isCreateOpen} onOpenChange={(open) => {
            setIsCreateOpen(open);
            if(!open) clearFile();
        }}>
          <DialogTrigger asChild>
            <Button className="shadow-md border-0" style={{ backgroundColor: activeTheme.accent_primary, color: '#fff' }}>
              <Plus className="w-4 h-4 mr-2" /> New Thread
            </Button>
          </DialogTrigger>
          <DialogContent className="sm:max-w-md" style={{ backgroundColor: activeTheme.bg_primary, borderColor: activeTheme.border_color }}>
            <DialogHeader><DialogTitle style={{ color: activeTheme.text_primary }}>Create Discussion</DialogTitle></DialogHeader>
            <div className="space-y-4 pt-4">
              <div>
                <label className="text-sm font-medium mb-1 block" style={{ color: activeTheme.text_secondary }}>Title</label>
                <input 
                  placeholder="What's this about?"
                  value={newThread.title}
                  onChange={e => setNewThread({...newThread, title: e.target.value})}
                  className="w-full p-3 rounded-lg outline-none border focus:ring-2"
                  style={{ 
                    backgroundColor: activeTheme.bg_secondary, 
                    color: activeTheme.text_primary,
                    borderColor: activeTheme.border_color,
                    '--tw-ring-color': activeTheme.accent_primary
                  }}
                />
              </div>
              
              <div>
                 <label className="text-sm font-medium mb-1 block" style={{ color: activeTheme.text_secondary }}>Category</label>
                 <select
                  value={newThread.category}
                  onChange={e => setNewThread({...newThread, category: e.target.value})}
                  className="w-full p-3 rounded-lg outline-none border focus:ring-2"
                  style={{ 
                    backgroundColor: activeTheme.bg_secondary, 
                    color: activeTheme.text_primary,
                    borderColor: activeTheme.border_color,
                    '--tw-ring-color': activeTheme.accent_primary
                  }}
                >
                  {categories.map(c => <option key={c.id} value={c.id}>{c.name}</option>)}
                </select>
              </div>

              <div>
                <label className="text-sm font-medium mb-1 block" style={{ color: activeTheme.text_secondary }}>Content</label>
                <textarea 
                  placeholder="Share your thoughts..."
                  value={newThread.content}
                  onChange={e => setNewThread({...newThread, content: e.target.value})}
                  className="w-full p-3 rounded-lg h-32 outline-none resize-none border focus:ring-2"
                  style={{ 
                    backgroundColor: activeTheme.bg_secondary, 
                    color: activeTheme.text_primary,
                    borderColor: activeTheme.border_color,
                    '--tw-ring-color': activeTheme.accent_primary
                  }}
                />
              </div>

              {/* Image Upload Area */}
              <div className="flex flex-col gap-2">
                 <label htmlFor="forum-image-upload" className="cursor-pointer inline-flex items-center gap-2 text-sm hover:opacity-80" style={{ color: activeTheme.text_secondary }}>
                   <ImageIcon className="w-5 h-5" /> Add Image
                 </label>
                 <input 
                    id="forum-image-upload" 
                    type="file" 
                    accept="image/*" 
                    onChange={handleFileSelect} 
                    className="hidden" 
                 />
                 
                 {previewUrl && (
                   <div className="relative w-full h-40 mt-2 rounded-lg overflow-hidden border" style={{ backgroundColor: activeTheme.bg_secondary, borderColor: activeTheme.border_color }}>
                     <img src={previewUrl} alt="Preview" className="w-full h-full object-cover" />
                     <button 
                       onClick={clearFile}
                       className="absolute top-2 right-2 bg-black/50 text-white rounded-full p-1 hover:bg-black/70"
                     >
                       <X className="w-4 h-4" />
                     </button>
                   </div>
                 )}
              </div>

              <Button onClick={handleCreateThread} disabled={uploading} className="w-full hover:opacity-90 text-white" style={{ backgroundColor: activeTheme.accent_primary }}>
                {uploading ? <Loader2 className="w-4 h-4 animate-spin mr-2" /> : null}
                {uploading ? 'Posting...' : 'Post Thread'}
              </Button>
            </div>
          </DialogContent>
        </Dialog>
      </div>

      <div className="relative mb-6">
        <Search className="absolute left-3 top-3 w-5 h-5" style={{ color: activeTheme.text_secondary }} />
        <input 
          placeholder="Search topics..." 
          value={searchQuery}
          onChange={e => setSearchQuery(e.target.value)}
          className="w-full pl-10 pr-4 py-3 rounded-xl border-none shadow-sm focus:ring-2 outline-none"
          style={{ 
            backgroundColor: activeTheme.bg_primary, 
            color: activeTheme.text_primary,
            '--tw-ring-color': activeTheme.accent_primary
          }}
        />
      </div>

      {/* Category Pills */}
      <div className="flex gap-3 overflow-x-auto pb-4 mb-2 no-scrollbar">
        <motion.button
          whileTap={{ scale: 0.95 }}
          onClick={() => setActiveCategory(null)}
          className={`px-5 py-2 rounded-full whitespace-nowrap transition-colors font-medium text-sm shadow-sm border`}
          style={{
             backgroundColor: !activeCategory ? activeTheme.accent_primary : activeTheme.bg_primary,
             color: !activeCategory ? '#fff' : activeTheme.text_secondary,
             borderColor: !activeCategory ? 'transparent' : activeTheme.border_color
          }}
        >
          All
        </motion.button>
        {categories.map(cat => (
          <motion.button
            key={cat.id}
            whileTap={{ scale: 0.95 }}
            onClick={() => setActiveCategory(cat.id)}
            className={`px-4 py-2 rounded-full whitespace-nowrap transition-colors flex items-center gap-2 text-sm font-medium shadow-sm border`}
            style={{ 
              backgroundColor: activeCategory === cat.id ? activeTheme.accent_secondary : activeTheme.bg_primary,
              color: activeCategory === cat.id ? activeTheme.accent_primary : activeTheme.text_secondary,
              borderColor: activeCategory === cat.id ? activeTheme.accent_primary : activeTheme.border_color,
            }}
          >
            <cat.icon className="w-4 h-4" />
            {cat.name}
          </motion.button>
        ))}
      </div>

      {loading ? (
        <div className="text-center py-10" style={{ color: activeTheme.accent_primary }}>
          <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-current mx-auto mb-2"></div>
          Loading...
        </div>
      ) : filteredThreads.length === 0 ? (
        <div className="text-center py-16 rounded-xl shadow-sm border border-dashed" style={{ backgroundColor: activeTheme.bg_primary, borderColor: activeTheme.border_color }}>
          <MessageSquare className="w-12 h-12 mx-auto mb-3 opacity-50" style={{ color: activeTheme.text_secondary }} />
          <p style={{ color: activeTheme.text_secondary }}>No discussions found matching your criteria.</p>
        </div>
      ) : (
        <div className="space-y-4">
          {filteredThreads.map((thread, index) => {
             return (
              <motion.div
                key={thread.id}
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: index * 0.05 }}
                whileHover={{ y: -2 }}
                onClick={() => setActiveThreadId(thread.id)}
                className="p-5 rounded-xl shadow-sm border cursor-pointer group transition-all duration-300"
                style={{ 
                  backgroundColor: activeTheme.bg_primary, 
                  borderColor: activeTheme.border_color 
                }}
              >
                <div className="flex justify-between items-start mb-3">
                  <span 
                    className="text-[10px] font-bold px-2 py-1 rounded-full uppercase tracking-wider"
                    style={{ backgroundColor: activeTheme.bg_secondary, color: activeTheme.text_secondary }}
                  >
                    {thread.category}
                  </span>
                  <span className="text-xs" style={{ color: activeTheme.text_secondary }}>{new Date(thread.created_at).toLocaleDateString()}</span>
                </div>
                
                <h3 className="font-bold text-lg mb-2 transition-colors line-clamp-1 group-hover:text-opacity-80" style={{ color: activeTheme.text_primary }}>{thread.title}</h3>
                
                {thread.image_url && (
                  <div className="w-full h-32 mb-3 overflow-hidden rounded-lg">
                     <img src={thread.image_url} alt="Thread attachment" className="w-full h-full object-cover" />
                  </div>
                )}

                <p className="text-sm line-clamp-2 mb-4 leading-relaxed" style={{ color: activeTheme.text_secondary }}>{thread.content}</p>
                
                <div className="flex items-center justify-between pt-3 border-t" style={{ borderColor: activeTheme.border_color }}>
                   <div className="flex items-center gap-2 text-xs font-medium" style={{ color: activeTheme.text_secondary }}>
                     <div className="w-5 h-5 rounded-full flex items-center justify-center text-[10px]" style={{ backgroundColor: activeTheme.bg_secondary }}>
                       {thread.profiles?.full_name?.[0]}
                     </div>
                     {thread.profiles?.full_name}
                   </div>
                   
                   <div className="flex items-center gap-4 text-xs opacity-80" style={{ color: activeTheme.text_secondary }}>
                      <span className="flex items-center gap-1"><Heart className="w-3 h-3" /> {thread.likes_count || 0}</span>
                      <span className="flex items-center gap-1 bg-gray-100 dark:bg-gray-800 px-2 py-0.5 rounded-full">
                        <MessageCircle className="w-3 h-3" /> 
                        {replyCounts[thread.id] || 0} replies
                      </span>
                   </div>
                </div>
              </motion.div>
             );
          })}
        </div>
      )}
    </div>
  );
};

export default ForumPage;