
import React from 'react';
import { motion } from 'framer-motion';
import { Home, Map, MessageCircle, Users, User, Bot, Search, Video, HelpCircle, MapPin, Shield } from 'lucide-react';
import { useTheme } from '@/context/ThemeContext';
import { Link, useLocation } from 'react-router-dom';
import { useAuth } from '@/context/AuthContext';

const BottomNav = ({ activeTab, setActiveTab }) => {
  const { activeTheme } = useTheme();
  const location = useLocation();
  const { user } = useAuth();

  // If we are not on dashboard main view, we rely on URL matching or just navigation links
  // But for the Dashboard tabs, we use the props.
  // We'll mix dashboard tabs with direct links for new pages.

  const isAdmin = user?.role === 'admin' || user?.role === 'moderator';

  const tabs = [
    { id: 'home', icon: Home, label: 'Feed', type: 'tab' },
    { id: 'search', icon: Search, label: 'Search', type: 'tab' },
    { id: 'zoomies', icon: Video, label: 'Zoomies', type: 'tab' },
    { id: 'qa', icon: HelpCircle, label: 'Q&A', path: '/qa', type: 'link' },
    { id: 'adopt', icon: MapPin, label: 'Adopt', path: '/adoption-centres', type: 'link' },
    { id: 'map', icon: Map, label: 'Map', type: 'tab' },
    { id: 'aiAssistant', icon: Bot, label: 'AI Vet', type: 'tab' },
    { id: 'messages', icon: MessageCircle, label: 'Chat', type: 'tab' },
    { id: 'communities', icon: Users, label: 'Groups', type: 'tab' },
    { id: 'profile', icon: User, label: 'Me', type: 'tab' }
  ];

  if (isAdmin) {
      tabs.push({ id: 'admin', icon: Shield, label: 'Admin', path: '/admin', type: 'link' });
  }

  const handleNavClick = (tab) => {
      if (tab.type === 'tab') {
          // If we are on a separate route (like /qa), navigating to a tab implies going back to dashboard
          if (location.pathname !== '/dashboard') {
              window.location.href = '/dashboard'; // Simple redirect to reset dashboard state
          } else {
              setActiveTab(tab.id);
          }
      }
  };

  return (
    <nav 
      className="fixed bottom-0 left-0 right-0 shadow-[0_-4px_6px_-1px_rgba(0,0,0,0.05)] border-t z-50 transition-colors duration-300"
      style={{
        backgroundColor: activeTheme.bg_primary,
        borderColor: activeTheme.border_color
      }}
    >
      <div className="flex items-center h-20 w-full px-2 pb-2 overflow-x-auto no-scrollbar gap-1">
        {tabs.map((tab) => {
          const Icon = tab.icon;
          // Logic for active state:
          // If it's a link, check path. If it's a tab, check activeTab prop AND we must be on dashboard.
          const isLinkActive = tab.type === 'link' && location.pathname.startsWith(tab.path);
          const isTabActive = tab.type === 'tab' && activeTab === tab.id && location.pathname === '/dashboard';
          const isActive = isLinkActive || isTabActive;
          
          const Content = (
            <motion.div
                className="flex flex-col items-center justify-center min-w-[64px] h-full relative flex-shrink-0 group w-full"
                whileTap={{ scale: 0.9 }}
                whileHover={{ scale: 1.05 }}
            >
              <motion.div
                animate={{
                  y: isActive ? -5 : 0,
                  backgroundColor: isActive ? activeTheme.accent_tertiary : 'transparent',
                }}
                transition={{ duration: 0.3 }}
                className="p-2 rounded-full transition-colors duration-300"
              >
                <Icon 
                  className="w-6 h-6 transition-all duration-300"
                  style={{
                    color: isActive ? activeTheme.accent_primary : activeTheme.text_secondary,
                    fill: isActive ? 'currentColor' : 'none'
                  }}
                  strokeWidth={isActive ? 2.5 : 2}
                />
              </motion.div>
              <span 
                className="text-[10px] font-medium mt-1 whitespace-nowrap transition-colors duration-300"
                style={{
                  color: isActive ? activeTheme.accent_primary : activeTheme.text_secondary
                }}
              >
                {tab.label}
              </span>
            </motion.div>
          );

          if (tab.type === 'link') {
              return (
                  <Link key={tab.id} to={tab.path} className="h-full">
                      {Content}
                  </Link>
              )
          }

          return (
            <button
              key={tab.id}
              onClick={() => handleNavClick(tab)}
              className="h-full focus:outline-none"
            >
              {Content}
            </button>
          );
        })}
      </div>
    </nav>
  );
};

export default BottomNav;
