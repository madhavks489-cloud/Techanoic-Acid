import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { Filter, SortAsc, MapPin } from 'lucide-react';
import { useTheme } from '@/context/ThemeContext';
import SearchBar from './SearchBar';
import UserSearchResults from './UserSearchResults';
import { useUserSearch } from '@/hooks/useUserSearch';
import {
  Sheet,
  SheetContent,
  SheetHeader,
  SheetTitle,
  SheetTrigger,
  SheetDescription,
} from '@/components/ui/sheet';
import { Button } from '@/components/ui/button';
import { Label } from '@/components/ui/label';

const SearchPage = () => {
  const { activeTheme } = useTheme();
  const { results, loading, error, search } = useUserSearch();
  const [activeFilters, setActiveFilters] = useState({
    verifiedOnly: false,
    radius: null, // null = anywhere, 5, 10, 25, 50
    petType: '',
  });
  const [sortBy, setSortBy] = useState('relevance'); // relevance, distance, name
  const [currentQuery, setCurrentQuery] = useState('');
  const [isFilterOpen, setIsFilterOpen] = useState(false);
  const [isSortOpen, setIsSortOpen] = useState(false);

  const handleSearch = (term) => {
    setCurrentQuery(term);
    search(term, activeFilters, sortBy);
  };

  const updateFilters = (key, value) => {
    const newFilters = { ...activeFilters, [key]: value };
    setActiveFilters(newFilters);
    if (currentQuery) {
        search(currentQuery, newFilters, sortBy);
    }
  };

  const updateSort = (sort) => {
    setSortBy(sort);
    if (currentQuery) {
        search(currentQuery, activeFilters, sort);
    }
    setIsSortOpen(false);
  };

  return (
    <div className="min-h-screen pb-20 pt-4 px-4 max-w-3xl mx-auto" style={{ backgroundColor: activeTheme.bg_primary }}>
      
      {/* Header Area */}
      <div className="sticky top-0 z-30 pt-2 pb-4" style={{ backgroundColor: activeTheme.bg_primary }}>
        <h1 className="text-2xl font-bold mb-4 px-1" style={{ color: activeTheme.text_primary }}>
            Find Friends & Vets
        </h1>
        
        <SearchBar onSearch={handleSearch} loading={loading} />

        {/* Filters & Sort Bar */}
        <div className="flex items-center gap-2 mt-4 overflow-x-auto no-scrollbar pb-2">
            
            {/* Filter Sheet */}
            <Sheet open={isFilterOpen} onOpenChange={setIsFilterOpen}>
                <SheetTrigger asChild>
                    <Button variant="outline" size="sm" className="gap-2 h-8 rounded-full">
                        <Filter size={14} />
                        Filters
                        {(activeFilters.verifiedOnly || activeFilters.radius) && (
                            <span className="w-2 h-2 rounded-full bg-blue-500" />
                        )}
                    </Button>
                </SheetTrigger>
                <SheetContent side="bottom" className="h-auto max-h-[80vh] overflow-y-auto rounded-t-xl">
                    <SheetHeader>
                        <SheetTitle>Filter Results</SheetTitle>
                        <SheetDescription>Refine your search to find exactly what you need.</SheetDescription>
                    </SheetHeader>
                    <div className="py-6 space-y-6">
                        {/* Verified Filter */}
                        <div className="flex items-center justify-between p-3 border rounded-lg">
                            <div className="space-y-0.5">
                                <Label htmlFor="verified-filter" className="text-base font-medium">Verified Vets Only</Label>
                                <p className="text-xs text-muted-foreground">Show only verified veterinary professionals</p>
                            </div>
                            <Button 
                                id="verified-filter"
                                variant={activeFilters.verifiedOnly ? "default" : "outline"}
                                size="sm"
                                onClick={() => updateFilters('verifiedOnly', !activeFilters.verifiedOnly)}
                            >
                                {activeFilters.verifiedOnly ? 'On' : 'Off'}
                            </Button>
                        </div>
                        
                        {/* Radius Filter */}
                        <div className="space-y-3">
                            <Label className="text-base font-medium">Distance Radius</Label>
                            <div className="grid grid-cols-3 gap-2">
                                {[5, 10, 25, 50].map((km) => (
                                    <Button
                                        key={km}
                                        variant={activeFilters.radius === km ? "default" : "outline"}
                                        size="sm"
                                        onClick={() => updateFilters('radius', activeFilters.radius === km ? null : km)}
                                    >
                                        Within {km} km
                                    </Button>
                                ))}
                                <Button
                                    variant={activeFilters.radius === null ? "default" : "outline"}
                                    size="sm"
                                    className="col-span-2"
                                    onClick={() => updateFilters('radius', null)}
                                >
                                    Anywhere
                                </Button>
                            </div>
                        </div>
                    </div>
                    <div className="pt-2 pb-6">
                        <Button className="w-full" onClick={() => setIsFilterOpen(false)}>
                            Show Results
                        </Button>
                    </div>
                </SheetContent>
            </Sheet>

            {/* Sort Sheet */}
            <Sheet open={isSortOpen} onOpenChange={setIsSortOpen}>
                <SheetTrigger asChild>
                    <Button variant="outline" size="sm" className="gap-2 h-8 rounded-full">
                        <SortAsc size={14} />
                        Sort: {sortBy.charAt(0).toUpperCase() + sortBy.slice(1)}
                    </Button>
                </SheetTrigger>
                <SheetContent side="bottom" className="h-auto rounded-t-xl">
                    <SheetHeader>
                        <SheetTitle>Sort By</SheetTitle>
                        <SheetDescription>Choose how you want to order the results.</SheetDescription>
                    </SheetHeader>
                    <div className="py-6 flex flex-col gap-2">
                        <Button 
                            variant={sortBy === 'relevance' ? "default" : "ghost"} 
                            className="justify-start h-12 text-base"
                            onClick={() => updateSort('relevance')}
                        >
                            Relevance
                        </Button>
                        <Button 
                            variant={sortBy === 'distance' ? "default" : "ghost"} 
                            className="justify-start h-12 text-base"
                            onClick={() => updateSort('distance')}
                        >
                            Distance
                        </Button>
                        <Button 
                            variant={sortBy === 'name' ? "default" : "ghost"} 
                            className="justify-start h-12 text-base"
                            onClick={() => updateSort('name')}
                        >
                            Name (A-Z)
                        </Button>
                    </div>
                </SheetContent>
            </Sheet>

            {/* Quick Filter Bubbles */}
            {activeFilters.radius && (
                 <Button 
                    variant="ghost" 
                    size="sm" 
                    className="h-8 rounded-full bg-blue-100 text-blue-700 hover:bg-blue-200 dark:bg-blue-900 dark:text-blue-100 px-3 text-xs"
                    onClick={() => updateFilters('radius', null)}
                >
                    Within {activeFilters.radius}km <span className="ml-1">×</span>
                 </Button>
            )}
        </div>
      </div>

      {/* Results Area */}
      <div className="mt-2">
        {error ? (
            <div className="p-4 rounded-lg bg-red-50 text-red-600 border border-red-200 text-center text-sm">
                {error}
            </div>
        ) : (
            <UserSearchResults results={results} loading={loading} />
        )}
      </div>
    </div>
  );
};

export default SearchPage;