
import React from 'react';
import { Dog, Instagram, Twitter, Facebook } from 'lucide-react';

const PetFooter = () => {
  return (
    <footer className="bg-white border-t border-[var(--border-color)] pt-12 pb-6 mt-12 relative overflow-hidden">
       {/* Background Decoration */}
       <div className="absolute bottom-0 left-0 w-full opacity-5 pointer-events-none">
          <div className="flex justify-around">
             {[...Array(10)].map((_, i) => (
                <Dog key={i} className="w-16 h-16 transform translate-y-8" />
             ))}
          </div>
       </div>

       <div className="container mx-auto px-6 relative z-10">
          <div className="grid md:grid-cols-4 gap-8 mb-12">
             <div className="col-span-1 md:col-span-1">
                <div className="flex items-center gap-2 mb-4">
                   <div className="w-8 h-8 bg-[var(--accent-primary)] rounded-lg flex items-center justify-center text-white">
                      <Dog className="w-5 h-5" />
                   </div>
                   <span className="text-xl font-bold">Paws & Pals</span>
                </div>
                <p className="text-sm text-[var(--text-secondary)] leading-relaxed">
                   Connecting pet lovers, experts, and furry friends across the world. Join our community today.
                </p>
             </div>
             
             <div>
                <h4 className="font-bold mb-4 text-[var(--text-primary)]">Explore</h4>
                <ul className="space-y-2 text-sm text-[var(--text-secondary)]">
                   <li><a href="#" className="hover:text-[var(--accent-primary)]">Adopt a Pet</a></li>
                   <li><a href="#" className="hover:text-[var(--accent-primary)]">Find a Vet</a></li>
                   <li><a href="#" className="hover:text-[var(--accent-primary)]">Pet Store</a></li>
                   <li><a href="#" className="hover:text-[var(--accent-primary)]">Events</a></li>
                </ul>
             </div>

             <div>
                <h4 className="font-bold mb-4 text-[var(--text-primary)]">Community</h4>
                <ul className="space-y-2 text-sm text-[var(--text-secondary)]">
                   <li><a href="#" className="hover:text-[var(--accent-primary)]">Guidelines</a></li>
                   <li><a href="#" className="hover:text-[var(--accent-primary)]">Success Stories</a></li>
                   <li><a href="#" className="hover:text-[var(--accent-primary)]">Forums</a></li>
                   <li><a href="#" className="hover:text-[var(--accent-primary)]">Help Center</a></li>
                </ul>
             </div>

             <div>
                <h4 className="font-bold mb-4 text-[var(--text-primary)]">Follow Us</h4>
                <div className="flex gap-4">
                   <a href="#" className="w-10 h-10 rounded-full bg-[var(--pet-blue-soft)] flex items-center justify-center text-[var(--pet-text-light)] hover:bg-[var(--pet-blue-primary)] hover:text-white transition-all">
                      <Instagram className="w-5 h-5" />
                   </a>
                   <a href="#" className="w-10 h-10 rounded-full bg-[var(--pet-blue-soft)] flex items-center justify-center text-[var(--pet-text-light)] hover:bg-[var(--pet-blue-primary)] hover:text-white transition-all">
                      <Twitter className="w-5 h-5" />
                   </a>
                   <a href="#" className="w-10 h-10 rounded-full bg-[var(--pet-blue-soft)] flex items-center justify-center text-[var(--pet-text-light)] hover:bg-[var(--pet-blue-primary)] hover:text-white transition-all">
                      <Facebook className="w-5 h-5" />
                   </a>
                </div>
             </div>
          </div>
          
          <div className="border-t border-gray-100 pt-6 flex flex-col md:flex-row justify-between items-center text-xs text-gray-400">
             <p>&copy; {new Date().getFullYear()} Paws & Pals Inc. All rights reserved.</p>
             <div className="flex gap-4 mt-4 md:mt-0">
                <a href="#">Privacy Policy</a>
                <a href="#">Terms of Service</a>
             </div>
          </div>
       </div>
    </footer>
  );
};

export default PetFooter;
