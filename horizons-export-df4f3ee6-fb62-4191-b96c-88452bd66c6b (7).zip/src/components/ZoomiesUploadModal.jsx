import React, { useState, useRef } from 'react';
import { Upload, X, Film, Loader2 } from 'lucide-react';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { useAuth } from '@/context/AuthContext';
import { useTheme } from '@/context/ThemeContext';
import { supabase } from '@/lib/supabase';
import { useToast } from '@/components/ui/use-toast';

const ZoomiesUploadModal = ({ isOpen, onClose, onUploadSuccess }) => {
  const [file, setFile] = useState(null);
  const [preview, setPreview] = useState(null);
  const [title, setTitle] = useState('');
  const [description, setDescription] = useState('');
  const [uploading, setUploading] = useState(false);
  const videoRef = useRef(null);
  const { user } = useAuth();
  const { activeTheme } = useTheme();
  const { toast } = useToast();

  const handleFileSelect = (e) => {
    const selected = e.target.files[0];
    if (selected && selected.type.startsWith('video/')) {
       // Validate duration (simplified, normally requires loading metadata)
       setFile(selected);
       setPreview(URL.createObjectURL(selected));
    } else {
       toast({ title: "Invalid file", description: "Please select a video file.", variant: "destructive" });
    }
  };

  const handleLoadedMetadata = () => {
     if (videoRef.current) {
        if (videoRef.current.duration > 120) { // 2 minutes
           toast({ title: "Video too long", description: "Max duration is 2 minutes.", variant: "destructive" });
           setFile(null);
           setPreview(null);
        }
     }
  };

  const handleUpload = async () => {
    if (!file || !title) return;

    setUploading(true);
    try {
      const fileName = `${user.id}/${Date.now()}_${file.name}`;
      
      // 1. Upload video
      const { error: uploadError } = await supabase.storage
        .from('zoomies_videos')
        .upload(fileName, file);

      if (uploadError) throw uploadError;

      const { data: { publicUrl } } = supabase.storage
        .from('zoomies_videos')
        .getPublicUrl(fileName);

      // 2. Create DB record
      const { error: dbError } = await supabase.from('zoomies_videos').insert({
        user_id: user.id,
        title,
        description,
        video_url: publicUrl,
        thumbnail_url: null // Generate thumbnail on backend or client canvas in real app
      });

      if (dbError) throw dbError;

      toast({ title: "Zoomie uploaded!", description: "Your video is now live." });
      setFile(null);
      setPreview(null);
      setTitle('');
      setDescription('');
      onClose();
      if (onUploadSuccess) onUploadSuccess();

    } catch (error) {
      console.error('Upload failed:', error);
      toast({ title: "Upload failed", description: error.message, variant: "destructive" });
    } finally {
      setUploading(false);
    }
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent 
         className="sm:max-w-md"
         style={{ 
            backgroundColor: activeTheme.bg_primary,
            borderColor: activeTheme.border_color,
            color: activeTheme.text_primary 
         }}
      >
        <DialogHeader>
          <DialogTitle>Upload Zoomie</DialogTitle>
        </DialogHeader>
        
        <div className="space-y-4">
          {!preview ? (
            <div 
              className="border-2 border-dashed rounded-xl p-8 flex flex-col items-center justify-center cursor-pointer hover:bg-black/5 dark:hover:bg-white/5 transition-colors"
              style={{ borderColor: activeTheme.border_color }}
              onClick={() => document.getElementById('zoomie-input').click()}
            >
               <Film className="w-10 h-10 mb-2 opacity-50" />
               <span className="text-sm font-medium">Click to select video</span>
               <span className="text-xs opacity-50 mt-1">Max 2 mins • MP4, MOV</span>
               <input 
                 id="zoomie-input"
                 type="file"
                 accept="video/*"
                 className="hidden"
                 onChange={handleFileSelect}
               />
            </div>
          ) : (
             <div className="relative rounded-xl overflow-hidden bg-black aspect-[9/16] max-h-[300px]">
                <video 
                  ref={videoRef}
                  src={preview} 
                  className="w-full h-full object-contain" 
                  controls 
                  onLoadedMetadata={handleLoadedMetadata}
                />
                <button 
                  onClick={() => { setFile(null); setPreview(null); }}
                  className="absolute top-2 right-2 bg-black/50 p-1 rounded-full text-white"
                >
                   <X className="w-4 h-4" />
                </button>
             </div>
          )}

          <div className="space-y-2">
             <Input 
                placeholder="Caption / Title" 
                value={title}
                onChange={e => setTitle(e.target.value)}
                style={{ backgroundColor: activeTheme.bg_secondary }}
             />
             <Textarea 
                placeholder="Description & hashtags..." 
                value={description}
                onChange={e => setDescription(e.target.value)}
                style={{ backgroundColor: activeTheme.bg_secondary }}
             />
          </div>

          <Button 
            onClick={handleUpload} 
            disabled={!file || !title || uploading}
            className="w-full"
            style={{ backgroundColor: activeTheme.accent_primary, color: '#fff' }}
          >
             {uploading ? <Loader2 className="w-4 h-4 animate-spin mr-2" /> : <Upload className="w-4 h-4 mr-2" />}
             Post Zoomie
          </Button>
        </div>
      </DialogContent>
    </Dialog>
  );
};

export default ZoomiesUploadModal;