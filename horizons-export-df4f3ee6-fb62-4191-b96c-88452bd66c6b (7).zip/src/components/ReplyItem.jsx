
import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Heart, MessageCircle, Edit2, Trash2, ChevronDown, ChevronUp, CornerDownRight } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { useAuth } from '@/context/AuthContext';
import { useTheme } from '@/context/ThemeContext';
import VerifiedVetBadge from '@/components/VerifiedVetBadge';

const ReplyItem = ({ 
  reply, 
  allReplies, 
  depth = 0, 
  onReply, 
  onEdit, 
  onDelete 
}) => {
  const { user } = useAuth();
  const { activeTheme } = useTheme();
  const [isExpanded, setIsExpanded] = useState(true);
  
  // Find children
  const childReplies = allReplies.filter(r => r.parent_reply_id === reply.id);
  const hasChildren = childReplies.length > 0;
  const isOwner = user?.id === reply.author_id;

  const formatDate = (dateString) => {
    const date = new Date(dateString);
    const now = new Date();
    const diffInSeconds = Math.floor((now - date) / 1000);
    
    if (diffInSeconds < 60) return 'Just now';
    if (diffInSeconds < 3600) return `${Math.floor(diffInSeconds / 60)}m ago`;
    if (diffInSeconds < 86400) return `${Math.floor(diffInSeconds / 3600)}h ago`;
    return date.toLocaleDateString();
  };

  return (
    <div className="flex flex-col w-full">
      <motion.div 
        layout
        initial={{ opacity: 0, y: 10 }}
        animate={{ opacity: 1, y: 0 }}
        className={`group relative p-4 rounded-xl border transition-colors duration-200 mb-3`}
        style={{ 
          backgroundColor: activeTheme.bg_primary,
          borderColor: activeTheme.border_color,
          marginLeft: depth > 0 ? `${Math.min(depth * 16, 48)}px` : '0px',
        }}
      >
        {/* Connector Line for nested replies */}
        {depth > 0 && (
           <div 
             className="absolute -left-4 top-6 w-4 h-4 border-b border-l rounded-bl-xl pointer-events-none"
             style={{ borderColor: activeTheme.border_color }}
           />
        )}

        <div className="flex justify-between items-start mb-2">
          <div className="flex items-center gap-2">
            <div 
              className="w-8 h-8 rounded-full flex items-center justify-center text-xs font-bold"
              style={{ backgroundColor: activeTheme.bg_secondary, color: activeTheme.text_primary }}
            >
              {reply.profiles?.full_name?.[0]?.toUpperCase()}
            </div>
            <div className="flex flex-col">
              <div className="flex items-center gap-1">
                <span className="font-semibold text-sm" style={{ color: activeTheme.text_primary }}>
                  {reply.profiles?.full_name}
                </span>
                {reply.is_expert_reply && <VerifiedVetBadge size="sm" />}
              </div>
              <span className="text-xs" style={{ color: activeTheme.text_secondary }}>
                {formatDate(reply.created_at)} {reply.updated_at && <span className="italic ml-1">(Edited)</span>}
              </span>
            </div>
          </div>

          <div className="flex items-center gap-1">
            {isOwner && (
              <>
                <Button 
                  variant="ghost" 
                  size="icon" 
                  className="h-8 w-8" 
                  onClick={() => onEdit(reply)}
                  title="Edit"
                >
                  <Edit2 className="w-4 h-4" style={{ color: activeTheme.text_secondary }} />
                </Button>
                <Button 
                  variant="ghost" 
                  size="icon" 
                  className="h-8 w-8" 
                  onClick={() => onDelete(reply.id)}
                  title="Delete"
                >
                  <Trash2 className="w-4 h-4 text-red-500" />
                </Button>
              </>
            )}
          </div>
        </div>

        <div className="pl-10">
          <p className="text-sm whitespace-pre-wrap leading-relaxed mb-3" style={{ color: activeTheme.text_primary }}>
            {reply.content}
          </p>

          {reply.image_url && (
            <div className="mb-3 rounded-lg overflow-hidden border max-w-sm" style={{ borderColor: activeTheme.border_color }}>
              <img src={reply.image_url} alt="Attached" className="w-full h-auto object-cover" />
            </div>
          )}

          <div className="flex items-center gap-4 mt-2">
            <button 
              onClick={() => onReply(reply)}
              className="flex items-center gap-1 text-xs font-medium transition-colors hover:opacity-80"
              style={{ color: activeTheme.text_secondary }}
            >
              <MessageCircle className="w-3 h-3" /> Reply
            </button>
            
            {/* Collapse toggle for children */}
            {hasChildren && (
              <button 
                onClick={() => setIsExpanded(!isExpanded)}
                className="flex items-center gap-1 text-xs font-medium hover:underline ml-auto"
                style={{ color: activeTheme.accent_primary }}
              >
                {isExpanded ? (
                  <>
                    <ChevronUp className="w-3 h-3" /> Hide {childReplies.length} replies
                  </>
                ) : (
                  <>
                    <ChevronDown className="w-3 h-3" /> Show {childReplies.length} replies
                  </>
                )}
              </button>
            )}
          </div>
        </div>
      </motion.div>

      {/* Nested Replies Rendering */}
      <AnimatePresence>
        {hasChildren && isExpanded && (
          <motion.div
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: 'auto' }}
            exit={{ opacity: 0, height: 0 }}
            className="overflow-hidden"
          >
            {childReplies.map(child => (
              <ReplyItem
                key={child.id}
                reply={child}
                allReplies={allReplies}
                depth={depth + 1}
                onReply={onReply}
                onEdit={onEdit}
                onDelete={onDelete}
              />
            ))}
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
};

export default ReplyItem;
