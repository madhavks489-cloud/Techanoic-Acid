import React, { useState, useEffect, useRef } from 'react';
import { ArrowLeft, Heart, MessageSquare, AlertCircle } from 'lucide-react';
import { supabase } from '@/lib/supabase';
import { Button } from '@/components/ui/button';
import { useAuth } from '@/context/AuthContext';
import { useTheme } from '@/context/ThemeContext';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle } from "@/components/ui/alert-dialog";
import { motion, AnimatePresence } from 'framer-motion';
import ReplyForm from './ReplyForm';
import ReplyItem from './ReplyItem';

const ForumThread = ({ threadId, onBack }) => {
  const { user } = useAuth();
  const { activeTheme } = useTheme();
  const [thread, setThread] = useState(null);
  const [replies, setReplies] = useState([]);
  const [loading, setLoading] = useState(true);
  
  // Interaction States
  const [replyModalOpen, setReplyModalOpen] = useState(false);
  const [replyingTo, setReplyingTo] = useState(null); // The reply object we are replying to
  const [editingReply, setEditingReply] = useState(null); // The reply object we are editing
  const [deleteId, setDeleteId] = useState(null); // ID of reply to delete

  useEffect(() => {
    fetchThreadAndReplies();

    const threadSub = supabase.channel(`thread:${threadId}`)
      .on('postgres_changes', { event: '*', schema: 'public', table: 'forum_replies', filter: `thread_id=eq.${threadId}` }, (payload) => {
          handleRealtimeUpdate(payload);
      })
      .subscribe();

    return () => supabase.removeChannel(threadSub);
  }, [threadId]);

  const fetchThreadAndReplies = async () => {
    setLoading(true);
    // Fetch Thread Details
    const { data: tData, error: tError } = await supabase
      .from('forum_threads')
      .select('*, profiles:author_id(full_name)')
      .eq('id', threadId)
      .single();
    
    if (tError) console.error("Error fetching thread:", tError);
    if (tData) setThread(tData);

    // Fetch Replies
    const { data: rData, error: rError } = await supabase
      .from('forum_replies')
      .select('*, profiles:author_id(full_name, role)')
      .eq('thread_id', threadId)
      .order('created_at', { ascending: true });

    if (rError) console.error("Error fetching replies:", rError);
    if (rData) setReplies(rData);
    
    setLoading(false);
  };

  const handleRealtimeUpdate = async (payload) => {
    if (payload.eventType === 'INSERT') {
      // Fetch the full profile data for the new reply
      const { data: newReply } = await supabase
        .from('forum_replies')
        .select('*, profiles:author_id(full_name, role)')
        .eq('id', payload.new.id)
        .single();
        
      if (newReply) {
        setReplies(prev => {
          if (prev.find(r => r.id === newReply.id)) return prev;
          return [...prev, newReply];
        });
      }
    } else if (payload.eventType === 'UPDATE') {
      setReplies(prev => prev.map(r => r.id === payload.new.id ? { ...r, ...payload.new } : r));
    } else if (payload.eventType === 'DELETE') {
      setReplies(prev => prev.filter(r => r.id !== payload.old.id));
    }
  };

  const handleDeleteReply = async () => {
    if (deleteId) {
      const { error } = await supabase.from('forum_replies').delete().eq('id', deleteId);
      if (!error) {
         setReplies(prev => prev.filter(r => r.id !== deleteId));
      }
      setDeleteId(null);
    }
  };

  const openReplyModal = (parent = null) => {
    setReplyingTo(parent);
    setEditingReply(null);
    setReplyModalOpen(true);
  };

  const openEditModal = (reply) => {
    setEditingReply(reply);
    setReplyingTo(null);
    setReplyModalOpen(true);
  };

  const handleSuccess = () => {
    setReplyModalOpen(false);
    setReplyingTo(null);
    setEditingReply(null);
    // Optimistic update handled by realtime or simple re-fetch if needed
    fetchThreadAndReplies(); 
  };

  const toggleLike = async () => {
    if (!thread) return;
    const newCount = (thread.likes_count || 0) + 1;
    await supabase.from('forum_threads').update({ likes_count: newCount }).eq('id', threadId);
    setThread(prev => ({ ...prev, likes_count: newCount }));
  };

  // Only render root replies, the Item component handles recursion
  const rootReplies = replies.filter(r => !r.parent_reply_id);

  if (loading && !thread) {
    return (
      <div className="flex items-center justify-center min-h-[50vh]">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2" style={{ borderColor: activeTheme.accent_primary }}></div>
      </div>
    );
  }

  if (!thread) return <div className="p-8 text-center text-red-500">Thread not found</div>;

  return (
    <div className="container mx-auto px-4 py-6 max-w-3xl min-h-screen pb-24" style={{ backgroundColor: activeTheme.bg_secondary }}>
      <button 
        onClick={onBack} 
        className="flex items-center gap-2 mb-6 font-medium transition-colors hover:opacity-80"
        style={{ color: activeTheme.text_secondary }}
      >
        <ArrowLeft className="w-5 h-5" /> Back to Forum
      </button>

      {/* Main Thread Content */}
      <motion.div 
        initial={{ opacity: 0, y: 10 }}
        animate={{ opacity: 1, y: 0 }}
        className="p-6 rounded-xl shadow-sm border mb-8"
        style={{ backgroundColor: activeTheme.bg_primary, borderColor: activeTheme.border_color }}
      >
        <div className="flex flex-col gap-4">
          <div className="flex justify-between items-start">
             <h1 className="text-2xl font-bold leading-tight" style={{ color: activeTheme.text_primary }}>{thread.title}</h1>
             <span 
               className="text-xs px-2 py-1 rounded font-medium whitespace-nowrap"
               style={{ backgroundColor: activeTheme.bg_secondary, color: activeTheme.text_secondary }}
             >
               {thread.category}
             </span>
          </div>
          
          <div className="flex items-center gap-2 text-sm" style={{ color: activeTheme.text_secondary }}>
             <div className="flex items-center gap-2">
                <div className="w-6 h-6 rounded-full bg-gray-200 flex items-center justify-center text-gray-600 text-xs font-bold">
                  {thread.profiles?.full_name?.[0]}
                </div>
                <span className="font-semibold">{thread.profiles?.full_name}</span>
             </div>
             <span>•</span>
             <span>{new Date(thread.created_at).toLocaleDateString()}</span>
          </div>

          {thread.image_url && (
             <div className="w-full rounded-lg overflow-hidden border" style={{ borderColor: activeTheme.border_color }}>
               <img src={thread.image_url} alt="Thread topic" className="w-full max-h-[500px] object-contain bg-black/5" />
             </div>
          )}

          <div className="prose max-w-none" style={{ color: activeTheme.text_primary }}>
            <p className="whitespace-pre-wrap leading-relaxed">{thread.content}</p>
          </div>

          <div className="flex items-center gap-4 pt-4 border-t" style={{ borderColor: activeTheme.border_color }}>
            <button 
              onClick={toggleLike}
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-full transition-colors hover:bg-red-50 hover:text-red-500"
              style={{ color: activeTheme.text_secondary }}
            >
              <Heart className="w-4 h-4" /> 
              <span>{thread.likes_count || 0} Likes</span>
            </button>
            <div className="flex items-center gap-1.5 px-3 py-1.5" style={{ color: activeTheme.text_secondary }}>
              <MessageSquare className="w-4 h-4" />
              <span>{replies.length} Replies</span>
            </div>
          </div>
        </div>
      </motion.div>

      {/* Action Bar */}
      <div className="flex justify-between items-center mb-6">
        <h3 className="font-bold text-lg" style={{ color: activeTheme.text_primary }}>
          Discussion ({replies.length})
        </h3>
        <Button 
          onClick={() => openReplyModal(null)}
          style={{ backgroundColor: activeTheme.accent_primary, color: '#fff' }}
        >
          <MessageSquare className="w-4 h-4 mr-2" /> Add Reply
        </Button>
      </div>

      {/* Replies List */}
      <div className="space-y-2">
        {rootReplies.length === 0 ? (
          <div className="text-center py-10 opacity-60" style={{ color: activeTheme.text_secondary }}>
             <MessageSquare className="w-12 h-12 mx-auto mb-2 opacity-50" />
             <p>No replies yet. Be the first to share your thoughts!</p>
          </div>
        ) : (
          rootReplies.map((reply) => (
            <ReplyItem 
              key={reply.id} 
              reply={reply} 
              allReplies={replies} 
              onReply={openReplyModal}
              onEdit={openEditModal}
              onDelete={setDeleteId}
            />
          ))
        )}
      </div>

      {/* Reply/Edit Modal */}
      <Dialog open={replyModalOpen} onOpenChange={setReplyModalOpen}>
        <DialogContent className="sm:max-w-lg" style={{ backgroundColor: activeTheme.bg_primary, borderColor: activeTheme.border_color }}>
          <DialogHeader>
            <DialogTitle style={{ color: activeTheme.text_primary }}>
              {editingReply ? 'Edit Reply' : (replyingTo ? `Reply to ${replyingTo.profiles?.full_name}` : 'Post a Reply')}
            </DialogTitle>
          </DialogHeader>
          <ReplyForm 
            threadId={threadId}
            parentReply={replyingTo}
            initialData={editingReply}
            onSuccess={handleSuccess}
            onCancel={() => setReplyModalOpen(false)}
          />
        </DialogContent>
      </Dialog>

      {/* Delete Confirmation Dialog */}
      <AlertDialog open={!!deleteId} onOpenChange={(open) => !open && setDeleteId(null)}>
        <AlertDialogContent style={{ backgroundColor: activeTheme.bg_primary, borderColor: activeTheme.border_color }}>
          <AlertDialogHeader>
            <AlertDialogTitle style={{ color: activeTheme.text_primary }}>Delete Reply?</AlertDialogTitle>
            <AlertDialogDescription style={{ color: activeTheme.text_secondary }}>
              This action cannot be undone. This will permanently delete your reply and any nested replies.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel style={{ color: activeTheme.text_primary }}>Cancel</AlertDialogCancel>
            <AlertDialogAction 
              onClick={handleDeleteReply} 
              className="bg-red-600 hover:bg-red-700 text-white border-0"
            >
              Delete
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>

    </div>
  );
};

export default ForumThread;