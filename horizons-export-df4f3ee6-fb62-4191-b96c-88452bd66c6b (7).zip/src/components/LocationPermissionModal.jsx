
import React, { useState, useEffect, useRef } from 'react';
import { MapPin, Shield } from 'lucide-react';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
  DialogFooter,
} from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';

const LocationPermissionModal = ({ onPermissionGranted }) => {
  const [isOpen, setIsOpen] = useState(false);
  // Use a ref to ensure we only check/notify once per mount to prevent loops
  const hasCheckedPermission = useRef(false);

  useEffect(() => {
    if (hasCheckedPermission.current) return;
    hasCheckedPermission.current = true;

    const hasDecision = localStorage.getItem('location_permission_decision');
    if (!hasDecision) {
      // Small delay to not overwhelm user immediately on load
      const timer = setTimeout(() => setIsOpen(true), 1500);
      return () => clearTimeout(timer);
    } else if (hasDecision === 'granted' && onPermissionGranted) {
      onPermissionGranted();
    }
  }, [onPermissionGranted]);

  const handleAllow = () => {
    localStorage.setItem('location_permission_decision', 'granted');
    setIsOpen(false);
    if (onPermissionGranted) onPermissionGranted();
  };

  const handleDeny = () => {
    localStorage.setItem('location_permission_decision', 'denied');
    setIsOpen(false);
  };

  return (
    <Dialog open={isOpen} onOpenChange={setIsOpen}>
      <DialogContent className="sm:max-w-md bg-[var(--bg-primary)] border-[var(--border-color)]">
        <DialogHeader>
          <div className="mx-auto w-12 h-12 rounded-full bg-[var(--accent-tertiary)] flex items-center justify-center mb-4">
            <MapPin className="w-6 h-6 text-[var(--accent-primary)]" />
          </div>
          <DialogTitle className="text-center text-[var(--text-primary)]">Enable Location Services?</DialogTitle>
          <DialogDescription className="text-center text-[var(--text-secondary)]">
            To show you nearby pet owners, vets, and lost pets, we need access to your device's location.
          </DialogDescription>
        </DialogHeader>
        
        <div className="bg-[var(--bg-secondary)] p-3 rounded-lg flex items-start gap-3 my-2">
          <Shield className="w-5 h-5 text-[var(--accent-primary)] shrink-0 mt-0.5" />
          <p className="text-xs text-[var(--text-secondary)]">
            Your location is only shared with others if you explicitly enable "Location Sharing" in settings. You remain in control.
          </p>
        </div>

        <DialogFooter className="sm:justify-center flex-col sm:flex-row gap-2">
          <Button 
            variant="outline" 
            onClick={handleDeny}
            className="border-[var(--border-color)] text-[var(--text-primary)] hover:bg-[var(--bg-secondary)] w-full sm:w-auto"
          >
            Not Now
          </Button>
          <Button 
            onClick={handleAllow}
            className="bg-[var(--accent-primary)] text-white hover:opacity-90 w-full sm:w-auto"
          >
            Allow Access
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
};

export default LocationPermissionModal;
