
import React, { useState, useEffect, useRef } from 'react';
import { ArrowLeft, Send, Trash2, Flag, MoreVertical, User } from 'lucide-react';
import { supabase } from '@/lib/supabase';
import { useAuth } from '@/context/AuthContext';
import { Button } from '@/components/ui/button';
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { useToast } from '@/components/ui/use-toast';

const MessageThread = ({ conversation, onBack }) => {
  const { user } = useAuth();
  const [messages, setMessages] = useState([]);
  const [newMessage, setNewMessage] = useState('');
  const [messageToDelete, setMessageToDelete] = useState(null);
  const [messageToReport, setMessageToReport] = useState(null);
  const scrollRef = useRef();
  const { toast } = useToast();

  useEffect(() => {
    fetchMessages();
    
    const channel = supabase.channel(`conversation:${conversation.id}`)
      .on('postgres_changes', { 
        event: '*', 
        schema: 'public', 
        table: 'messages',
        filter: `conversation_id=eq.${conversation.id}`
      }, (payload) => {
        if (payload.eventType === 'INSERT') {
          // Check if message already exists (optimistic UI or double event)
          setMessages(prev => {
            if (prev.find(m => m.id === payload.new.id)) return prev;
            return [...prev, payload.new];
          });
          scrollToBottom();
          if (payload.new.sender_id !== user.id) markAsRead(payload.new.id);
        } else if (payload.eventType === 'DELETE') {
          setMessages(prev => prev.filter(m => m.id !== payload.old.id));
        } else if (payload.eventType === 'UPDATE') {
          if (payload.new.is_deleted) {
             setMessages(prev => prev.filter(m => m.id !== payload.new.id));
          }
        }
      })
      .subscribe();

    return () => supabase.removeChannel(channel);
  }, [conversation.id]);

  const fetchMessages = async () => {
    const { data, error } = await supabase
      .from('messages')
      .select('*')
      .eq('conversation_id', conversation.id)
      .eq('is_deleted', false)
      .order('created_at', { ascending: true });
    
    if (error) {
      console.error("Error loading messages:", error);
      return;
    }

    if (data) {
      setMessages(data);
      scrollToBottom();
      // Mark unread messages as read
      const unreadIds = data.filter(m => m.sender_id !== user.id && !m.read_at).map(m => m.id);
      if (unreadIds.length > 0) {
        unreadIds.forEach(id => markAsRead(id));
      }
    }
  };

  const markAsRead = async (msgId) => {
    await supabase.from('messages').update({ read_at: new Date().toISOString() }).eq('id', msgId);
  };

  const scrollToBottom = () => {
    setTimeout(() => {
      if (scrollRef.current) scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
    }, 100);
  };

  const sendMessage = async (e) => {
    e.preventDefault();
    if (!newMessage.trim()) return;

    const msgContent = newMessage;
    setNewMessage(''); // Optimistic clear

    const { error } = await supabase.from('messages').insert({
      conversation_id: conversation.id,
      sender_id: user.id,
      content: msgContent
    });

    if (error) {
      console.error("Failed to send:", error);
      toast({ title: "Failed to send message", variant: "destructive" });
      setNewMessage(msgContent); // Restore on error
    } else {
      // Message insertion will trigger subscription
    }
  };

  const confirmDeleteMessage = async () => {
    if (messageToDelete) {
      const { error } = await supabase.from('messages').delete().eq('id', messageToDelete);
      if (error) {
        toast({ title: "Error deleting message", variant: "destructive" });
      } else {
        setMessages(prev => prev.filter(m => m.id !== messageToDelete));
        toast({ title: "Message Deleted" });
      }
      setMessageToDelete(null);
    }
  };

  const confirmReportMessage = async () => {
     if (messageToReport) {
        const { error } = await supabase.from('message_reports').insert({
           message_id: messageToReport,
           reporter_id: user.id,
           reason: 'User reported content'
        });
        
        if (error) {
          toast({ title: "Error submitting report", variant: "destructive" });
        } else {
          toast({ title: "Report Submitted", description: "Thank you for keeping our community safe." });
        }
        setMessageToReport(null);
     }
  };

  return (
    <div className="flex flex-col h-[calc(100vh-80px)] bg-[#FFF8F3]">
      <div className="bg-white p-4 shadow-sm flex items-center gap-3 z-10 border-b border-gray-100">
        <button onClick={onBack} className="text-gray-600 hover:text-gray-900 transition-colors">
          <ArrowLeft className="w-6 h-6" />
        </button>
        <div className="flex-1">
          <h2 className="font-bold text-gray-900">{conversation.otherUser.full_name || conversation.otherUser.username || "Chat"}</h2>
          <p className="text-xs text-green-600">Active now</p>
        </div>
        <div className="w-8 h-8 rounded-full bg-gray-100 flex items-center justify-center">
           {conversation.otherUser.avatar_url ? (
             <img src={conversation.otherUser.avatar_url} className="w-full h-full rounded-full object-cover" />
           ) : (
             <User className="w-5 h-5 text-gray-500" />
           )}
        </div>
      </div>

      <div ref={scrollRef} className="flex-1 overflow-y-auto p-4 space-y-3">
        {messages.length === 0 ? (
          <div className="text-center text-gray-400 mt-10 text-sm">
            No messages yet. Say hello!
          </div>
        ) : (
          messages.map((msg) => {
            const isMe = msg.sender_id === user.id;
            return (
              <div key={msg.id} className={`flex ${isMe ? 'justify-end' : 'justify-start'} group items-center gap-2 mb-1`}>
                 <div className={`flex items-end gap-2 max-w-[80%] ${isMe ? 'flex-row-reverse' : 'flex-row'}`}>
                    <DropdownMenu>
                      <DropdownMenuTrigger asChild>
                         <div 
                           className={`p-3 rounded-2xl text-sm cursor-pointer hover:opacity-90 transition-opacity relative shadow-sm ${
                             isMe 
                               ? 'bg-[#9CAF88] text-white rounded-br-none' 
                               : 'bg-white text-gray-800 rounded-bl-none'
                           }`}
                         >
                           {msg.content}
                         </div>
                      </DropdownMenuTrigger>
                      <DropdownMenuContent>
                         {isMe ? (
                           <DropdownMenuItem onClick={() => setMessageToDelete(msg.id)} className="text-red-600">
                             <Trash2 className="w-4 h-4 mr-2" /> Delete
                           </DropdownMenuItem>
                         ) : (
                           <DropdownMenuItem onClick={() => setMessageToReport(msg.id)} className="text-orange-600">
                              <Flag className="w-4 h-4 mr-2" /> Report
                           </DropdownMenuItem>
                         )}
                      </DropdownMenuContent>
                    </DropdownMenu>
                 </div>
              </div>
            );
          })
        )}
      </div>

      <form onSubmit={sendMessage} className="p-3 bg-white border-t border-gray-100 flex gap-2">
        <input 
          value={newMessage}
          onChange={(e) => setNewMessage(e.target.value)}
          placeholder="Type a message..."
          className="flex-1 p-3 bg-gray-50 rounded-full border border-gray-200 focus:ring-2 focus:ring-[#9CAF88] focus:border-transparent outline-none transition-all"
        />
        <Button 
          type="submit" 
          size="icon" 
          className="rounded-full bg-[#9CAF88] hover:bg-[#8B9D77] transition-colors"
          disabled={!newMessage.trim()}
        >
          <Send className="w-5 h-5" />
        </Button>
      </form>

      <AlertDialog open={!!messageToDelete} onOpenChange={(open) => !open && setMessageToDelete(null)}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Delete Message?</AlertDialogTitle>
            <AlertDialogDescription>
              This message will be removed for everyone in the conversation. This action cannot be undone.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancel</AlertDialogCancel>
            <AlertDialogAction onClick={confirmDeleteMessage} className="bg-red-600 hover:bg-red-700">Delete</AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>

      <AlertDialog open={!!messageToReport} onOpenChange={(open) => !open && setMessageToReport(null)}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Report Message?</AlertDialogTitle>
            <AlertDialogDescription>
              Are you sure you want to report this message? Administrators will review it.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancel</AlertDialogCancel>
            <AlertDialogAction onClick={confirmReportMessage} className="bg-orange-600 hover:bg-orange-700">Report</AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
};

export default MessageThread;
