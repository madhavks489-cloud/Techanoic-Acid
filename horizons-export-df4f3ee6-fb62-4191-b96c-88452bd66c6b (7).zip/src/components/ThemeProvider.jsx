
import React, { useEffect } from 'react';
import { useTheme } from '@/context/ThemeContext';

const ThemeProvider = ({ children }) => {
  const { activeTheme } = useTheme();

  useEffect(() => {
    const root = document.documentElement;
    
    // Map theme object keys to CSS variables
    // Keys like bg_primary become --bg-primary
    Object.entries(activeTheme).forEach(([key, value]) => {
      const cssVarName = `--${key.replace('_', '-')}`;
      root.style.setProperty(cssVarName, value);
    });

  }, [activeTheme]);

  return <div className="theme-wrapper w-full h-full min-h-screen bg-[var(--bg-secondary)] text-[var(--text-primary)] transition-colors duration-300">{children}</div>;
};

export default ThemeProvider;
