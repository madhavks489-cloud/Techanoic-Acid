
import React from 'react';
import { motion } from 'framer-motion';
import { Shield, Heart, MessageCircle, AlertTriangle, CheckCircle, Info } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { useNavigate } from 'react-router-dom';
import { usePetTheme } from '@/context/PetThemeContext';

const CommunityGuidelinesPage = () => {
  const navigate = useNavigate();
  const { activeTheme } = usePetTheme();

  const sections = [
    {
      title: "Code of Conduct",
      icon: <Heart className="w-6 h-6 text-red-500" />,
      content: "We are a community built on love for pets. Treat every member with kindness, respect, and empathy. Harassment, hate speech, bullying, or discrimination of any kind is strictly prohibited."
    },
    {
      title: "Content Policy",
      icon: <MessageCircle className="w-6 h-6 text-blue-500" />,
      content: "Share content that celebrates pets! Photos, videos, and stories should be appropriate for all ages. Do not post graphic violence, explicit content, or spam. Ensure you have the right to share any media you post."
    },
    {
      title: "Safety & Privacy",
      icon: <Shield className="w-6 h-6 text-green-500" />,
      content: "Protect your privacy and the privacy of others. Do not share personal addresses, phone numbers, or financial information publicly. Report any suspicious behavior to moderators immediately."
    },
    {
      title: "Expert Advice",
      icon: <Info className="w-6 h-6 text-purple-500" />,
      content: "While we have verified vets, general advice from members is not a substitute for professional medical care. Always consult your local veterinarian for medical emergencies."
    },
    {
      title: "Consequences",
      icon: <AlertTriangle className="w-6 h-6 text-orange-500" />,
      content: "Violations of these guidelines may result in content removal, temporary suspension, or permanent banning from the platform depending on severity."
    }
  ];

  return (
    <div className="min-h-screen py-12 px-4 sm:px-6 lg:px-8 bg-gradient-to-br from-blue-50 to-green-50 dark:from-gray-900 dark:to-gray-800">
      <div className="max-w-4xl mx-auto">
        <div className="text-center mb-12">
          <motion.div
            initial={{ scale: 0 }}
            animate={{ scale: 1 }}
            className="w-20 h-20 bg-white rounded-full flex items-center justify-center mx-auto mb-6 shadow-xl"
          >
            <Shield className="w-10 h-10 text-blue-600" />
          </motion.div>
          <h1 className="text-4xl font-bold text-gray-900 dark:text-white mb-4 font-poppins">Community Guidelines</h1>
          <p className="text-xl text-gray-600 dark:text-gray-300">Making Paws & Pals a safe space for everyone.</p>
        </div>

        <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-1">
          {sections.map((section, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: index * 0.1 }}
              className="bg-white dark:bg-gray-800 rounded-2xl p-8 shadow-lg border border-gray-100 dark:border-gray-700 hover:shadow-xl transition-shadow"
            >
              <div className="flex items-start gap-4">
                <div className="p-3 bg-gray-50 dark:bg-gray-700 rounded-xl">
                  {section.icon}
                </div>
                <div>
                  <h2 className="text-xl font-bold text-gray-900 dark:text-white mb-3">{section.title}</h2>
                  <p className="text-gray-600 dark:text-gray-300 leading-relaxed">{section.content}</p>
                </div>
              </div>
            </motion.div>
          ))}
        </div>

        <div className="mt-12 text-center">
          <Button 
            onClick={() => navigate(-1)}
            className="bg-gray-900 text-white hover:bg-gray-800 px-8 py-6 text-lg rounded-xl shadow-lg"
          >
            Go Back
          </Button>
        </div>
      </div>
    </div>
  );
};

export default CommunityGuidelinesPage;
