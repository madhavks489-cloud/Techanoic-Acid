
import React from 'react';
import { Sun, Moon, Palette } from 'lucide-react';
import { useTheme } from '@/context/ThemeContext';
import { motion } from 'framer-motion';

const ThemeToggle = () => {
  const { themeMode, setThemeMode } = useTheme();

  const modes = [
    { id: 'light', icon: Sun, label: 'Light' },
    { id: 'dark', icon: Moon, label: 'Dark' },
    { id: 'custom', icon: Palette, label: 'Custom' }
  ];

  return (
    <div className="bg-[var(--bg-primary)] p-1 rounded-full border border-[var(--border-color)] inline-flex relative shadow-sm">
      {modes.map((mode) => {
        const isActive = themeMode === mode.id;
        const Icon = mode.icon;
        
        return (
          <button
            key={mode.id}
            onClick={() => setThemeMode(mode.id)}
            className={`relative z-10 w-10 h-10 rounded-full flex items-center justify-center transition-colors duration-300 ${
              isActive ? 'text-[var(--bg-primary)]' : 'text-[var(--text-secondary)] hover:text-[var(--text-primary)]'
            }`}
            title={mode.label}
          >
            {isActive && (
              <motion.div
                layoutId="activeTheme"
                className="absolute inset-0 bg-[var(--accent-primary)] rounded-full"
                transition={{ type: "spring", stiffness: 500, damping: 30 }}
              />
            )}
            <span className="relative z-10">
              <Icon className="w-5 h-5" />
            </span>
          </button>
        );
      })}
    </div>
  );
};

export default ThemeToggle;
