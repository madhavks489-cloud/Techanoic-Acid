
import React, { useState } from 'react';
import { X, Save, RotateCcw, LayoutGrid, Palette } from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';
import { useTheme } from '@/context/ThemeContext';
import { Button } from '@/components/ui/button';
import { Label } from '@/components/ui/label';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import ThemePresetsPanel from '@/components/ThemePresetsPanel';

const ThemeCustomizer = ({ isOpen, onClose }) => {
  const { customColors, updateCustomColors, resetCustomTheme, setThemeMode, activeTheme, activePresetId } = useTheme();
  const [localColors, setLocalColors] = useState(customColors);
  const [activeTab, setActiveTab] = useState('presets');

  // Sync local state when prop changes, if needed
  React.useEffect(() => {
    setLocalColors(customColors);
  }, [customColors, isOpen]);

  React.useEffect(() => {
     if(activePresetId) setActiveTab('presets');
  }, [activePresetId, isOpen]);

  const handleChange = (key, value) => {
    setLocalColors(prev => ({ ...prev, [key]: value }));
  };

  const handleSaveCustom = () => {
    updateCustomColors(localColors);
    setThemeMode('custom');
    onClose();
  };

  const handleReset = () => {
    resetCustomTheme();
    setLocalColors(customColors); 
  };

  const ColorInput = ({ label, keyName }) => (
    <div className="flex items-center justify-between mb-4">
      <Label className="text-[var(--text-primary)]">{label}</Label>
      <div className="flex items-center gap-2">
        <span className="text-xs text-[var(--text-secondary)] uppercase">{localColors[keyName]}</span>
        <input
          type="color"
          value={localColors[keyName]}
          onChange={(e) => handleChange(keyName, e.target.value)}
          className="w-10 h-10 rounded-lg cursor-pointer border-0 p-0 overflow-hidden shadow-sm"
        />
      </div>
    </div>
  );

  return (
    <AnimatePresence>
      {isOpen && (
        <>
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 0.5 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 bg-black z-50"
            onClick={onClose}
          />
          <motion.div
            initial={{ opacity: 0, scale: 0.95, y: 20 }}
            animate={{ opacity: 1, scale: 1, y: 0 }}
            exit={{ opacity: 0, scale: 0.95, y: 20 }}
            className="fixed inset-0 flex items-center justify-center z-50 pointer-events-none"
          >
            <div className="bg-[var(--bg-primary)] w-full max-w-4xl m-4 rounded-xl shadow-2xl pointer-events-auto border border-[var(--border-color)] max-h-[90vh] flex flex-col overflow-hidden">
              <div className="flex items-center justify-between p-6 border-b border-[var(--border-color)] bg-[var(--bg-secondary)]">
                <div>
                  <h2 className="text-xl font-bold text-[var(--text-primary)] font-poppins">Customize Theme</h2>
                  <p className="text-sm text-[var(--text-secondary)]">Choose a preset or create your own style.</p>
                </div>
                <button onClick={onClose} className="text-[var(--text-secondary)] hover:text-[var(--text-primary)]">
                  <X className="w-6 h-6" />
                </button>
              </div>

              <div className="flex-1 overflow-y-auto p-0">
                <Tabs defaultValue="presets" value={activeTab} onValueChange={setActiveTab} className="w-full h-full">
                  <div className="px-6 pt-6 sticky top-0 bg-[var(--bg-primary)] z-10 border-b border-[var(--border-color)]">
                    <TabsList className="grid w-full grid-cols-2 max-w-md mx-auto mb-4 bg-[var(--input-bg)]">
                      <TabsTrigger value="presets" className="data-[state=active]:bg-[var(--bg-primary)] data-[state=active]:text-[var(--accent-primary)]">
                        <LayoutGrid className="w-4 h-4 mr-2" /> Presets
                      </TabsTrigger>
                      <TabsTrigger value="custom" className="data-[state=active]:bg-[var(--bg-primary)] data-[state=active]:text-[var(--accent-primary)]">
                        <Palette className="w-4 h-4 mr-2" /> Custom Editor
                      </TabsTrigger>
                    </TabsList>
                  </div>

                  <TabsContent value="presets" className="mt-0 pb-6">
                    <ThemePresetsPanel />
                  </TabsContent>

                  <TabsContent value="custom" className="mt-0 p-6">
                    <div className="grid md:grid-cols-2 gap-8">
                       <div className="space-y-4">
                          <h3 className="font-bold text-[var(--text-primary)] mb-4">Edit Colors</h3>
                          <ColorInput label="Background (Main)" keyName="bg_primary" />
                          <ColorInput label="Background (Page)" keyName="bg_secondary" />
                          <ColorInput label="Primary Text" keyName="text_primary" />
                          <ColorInput label="Secondary Text" keyName="text_secondary" />
                          <ColorInput label="Primary Accent" keyName="accent_primary" />
                          <ColorInput label="Secondary Accent" keyName="accent_secondary" />
                          <ColorInput label="Input Background" keyName="input_bg" />
                          <ColorInput label="Border Color" keyName="border_color" />
                       </div>

                       <div>
                          <h3 className="font-bold text-[var(--text-primary)] mb-4">Live Preview</h3>
                          <div className="p-6 rounded-xl border border-dashed border-[var(--border-color)] bg-[var(--bg-secondary)] h-full flex items-center justify-center">
                              <div className="bg-[var(--bg-primary)] p-6 rounded-xl shadow-lg w-full max-w-xs border border-[var(--border-color)]">
                                 <div className="w-12 h-12 rounded-full mb-4 flex items-center justify-center text-white" style={{ backgroundColor: localColors.accent_primary }}>
                                    <Palette className="w-6 h-6" />
                                 </div>
                                 <h4 className="font-bold text-lg mb-2" style={{ color: localColors.text_primary }}>Sample Card</h4>
                                 <p className="text-sm mb-4" style={{ color: localColors.text_secondary }}>
                                   This is how your components will look with the selected colors.
                                 </p>
                                 <div className="flex gap-2">
                                   <button className="px-4 py-2 rounded-lg text-white text-sm font-medium flex-1" style={{ backgroundColor: localColors.accent_primary }}>
                                     Action
                                   </button>
                                   <button className="px-4 py-2 rounded-lg text-sm font-medium flex-1 border" style={{ borderColor: localColors.border_color, color: localColors.text_primary }}>
                                     Cancel
                                   </button>
                                 </div>
                              </div>
                          </div>
                       </div>
                    </div>
                  </TabsContent>
                </Tabs>
              </div>

              {activeTab === 'custom' && (
                <div className="p-6 border-t border-[var(--border-color)] bg-[var(--bg-primary)] flex gap-3">
                  <Button 
                    onClick={handleSaveCustom} 
                    className="flex-1 text-white bg-[var(--accent-primary)] hover:opacity-90"
                    style={{ backgroundColor: localColors.accent_primary }}
                  >
                    <Save className="w-4 h-4 mr-2" /> Apply Custom Theme
                  </Button>
                  <Button 
                    onClick={handleReset} 
                    variant="outline" 
                    className="border-[var(--border-color)] text-[var(--text-primary)] hover:bg-[var(--bg-secondary)]"
                  >
                    <RotateCcw className="w-4 h-4" />
                  </Button>
                </div>
              )}
              
              {activeTab === 'presets' && (
                 <div className="p-6 border-t border-[var(--border-color)] bg-[var(--bg-primary)] flex justify-end">
                    <Button onClick={onClose} variant="outline" className="border-[var(--border-color)] text-[var(--text-primary)]">
                       Close
                    </Button>
                 </div>
              )}
            </div>
          </motion.div>
        </>
      )}
    </AnimatePresence>
  );
};

export default ThemeCustomizer;
