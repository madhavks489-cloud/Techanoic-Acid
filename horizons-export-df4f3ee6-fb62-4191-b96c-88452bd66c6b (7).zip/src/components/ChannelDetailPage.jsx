
import React, { useState, useEffect, useRef } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { ArrowLeft, Send, Users, UserPlus, LogOut, Clock, Loader2, MoreVertical, Trash2, AlertTriangle, Flag, Shield } from 'lucide-react';
import { supabase } from '@/lib/supabase';
import { useAuth } from '@/context/AuthContext';
import { Button } from '@/components/ui/button';
import { useToast } from '@/components/ui/use-toast';
import { useTheme } from '@/context/ThemeContext';
import DeleteChannelDialog from './DeleteChannelDialog';
import CommunityMembersPanel from './CommunityMembersPanel';
import {
  Sheet,
  SheetContent,
  SheetHeader,
  SheetTitle,
  SheetTrigger,
} from "@/components/ui/sheet";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
  DropdownMenuSeparator
} from "@/components/ui/dropdown-menu";

const ChannelDetailPage = ({ channelId, onBack }) => {
  const { user } = useAuth();
  const { toast } = useToast();
  const { activeTheme } = useTheme();
  
  const [channel, setChannel] = useState(null);
  const [messages, setMessages] = useState([]);
  const [memberCount, setMemberCount] = useState(0);
  const [newMessage, setNewMessage] = useState('');
  const [isMember, setIsMember] = useState(false);
  const [loading, setLoading] = useState(true);
  const [sending, setSending] = useState(false);
  const [deleteDialogOpen, setDeleteDialogOpen] = useState(false);
  const [isDeleting, setIsDeleting] = useState(false);
  
  const scrollRef = useRef();

  useEffect(() => {
    if (channelId) {
      fetchChannelDetails();
      fetchMessages();
      fetchMemberCount();
    }

    const messageSub = supabase.channel(`channel_messages:${channelId}`)
      .on('postgres_changes', { 
        event: 'INSERT', 
        schema: 'public', 
        table: 'channel_messages', 
        filter: `channel_id=eq.${channelId}` 
      }, (payload) => {
        // Fetch single message to get profile details or insert optimistically
        fetchSingleMessage(payload.new.id);
      })
      .subscribe();
      
    return () => {
      supabase.removeChannel(messageSub);
    };
  }, [channelId, user?.id]);

  const fetchChannelDetails = async () => {
    const { data } = await supabase.from('channels').select('*').eq('id', channelId).single();
    if (data) setChannel(data);
  };

  const fetchMemberCount = async () => {
     const { count, error } = await supabase
       .from('channel_members')
       .select('*', { count: 'exact', head: true })
       .eq('channel_id', channelId);
     
     if (!error) setMemberCount(count);
     
     if (user?.id) {
       // Check membership status - removed 'id' selection as table uses composite key
       const { data } = await supabase
         .from('channel_members')
         .select('role')
         .eq('channel_id', channelId)
         .eq('user_id', user.id);
       
       setIsMember(data && data.length > 0);
     }
  };

  const fetchSingleMessage = async (msgId) => {
    const { data } = await supabase
      .from('channel_messages')
      .select('*, profiles:sender_id(full_name, avatar_url)')
      .eq('id', msgId)
      .single();
    if (data) {
      setMessages(prev => {
        // Prevent duplicates
        if (prev.some(m => m.id === data.id)) return prev;
        return [...prev, data];
      });
      scrollToBottom();
    }
  };

  const fetchMessages = async () => {
    const { data } = await supabase
      .from('channel_messages')
      .select('*, profiles:sender_id(full_name, avatar_url)')
      .eq('channel_id', channelId)
      .order('created_at', { ascending: true });
    
    if (data) {
      setMessages(data);
      setLoading(false);
      scrollToBottom();
    }
  };

  const scrollToBottom = () => {
    setTimeout(() => {
      if (scrollRef.current) scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
    }, 100);
  };

  const handleSend = async (e) => {
    e.preventDefault();
    if (!newMessage.trim() || sending) return;

    if (!isMember) {
      toast({ title: "Join Channel", description: "You must join this channel to post messages.", variant: "destructive" });
      return;
    }

    setSending(true);
    const { error } = await supabase.from('channel_messages').insert({
      channel_id: channelId,
      sender_id: user.id,
      content: newMessage
    });

    if (error) {
      toast({ title: "Error", description: "Failed to send message", variant: "destructive" });
    } else {
      setNewMessage('');
    }
    setSending(false);
  };

  const handleJoin = async () => {
    if (!user) {
      toast({ title: "Authentication Required", description: "Please log in to join channels.", variant: "destructive" });
      return;
    }

    const { error } = await supabase.from('channel_members').insert({
      channel_id: channelId,
      user_id: user.id,
      role: 'member',
      joined_at: new Date().toISOString()
    });

    if (!error) {
      toast({ title: "Joined!", description: `Welcome to #${channel?.name}` });
      setIsMember(true);
      fetchMemberCount();
    } else {
      toast({ title: "Error", description: "Failed to join channel. Please try again.", variant: "destructive" });
    }
  };

  const handleDeleteChannel = async () => {
    if (!channel) return;
    setIsDeleting(true);

    try {
      // 1. Delete all messages first
      await supabase.from('channel_messages').delete().eq('channel_id', channelId);
      // 2. Delete all members
      await supabase.from('channel_members').delete().eq('channel_id', channelId);
      // 3. Delete reports
      await supabase.from('community_reports').delete().eq('community_id', channelId);
      // 4. Delete the channel
      await supabase.from('channels').delete().eq('id', channelId);

      toast({ title: "Channel Deleted", description: `#${channel.name} has been successfully deleted.` });
      setDeleteDialogOpen(false);
      onBack();

    } catch (error) {
      console.error('Delete channel error:', error);
      toast({ title: "Delete Failed", description: "An unexpected error occurred.", variant: "destructive" });
      setIsDeleting(false);
    }
  };

  const handleReportChannel = async () => {
      if (!user) return;
      await supabase.from('community_reports').insert({
          community_id: channelId,
          reporter_id: user.id,
          reason: 'User reported community'
      });
      toast({ title: "Report Submitted", description: "We will review this community." });
  };

  const isCreator = channel?.creator_id === user?.id;

  if (loading && !channel) return (
    <div className="flex justify-center items-center h-screen" style={{ backgroundColor: activeTheme.bg_primary }}>
      <Loader2 className="animate-spin" style={{ color: activeTheme.accent_primary }} />
    </div>
  );

  return (
    <div className="flex flex-col h-[calc(100vh-80px)]" style={{ backgroundColor: activeTheme.bg_surface }}>
      {/* Header */}
      <div 
        className="p-4 shadow-sm flex items-center justify-between z-10 border-b transition-colors"
        style={{ 
          backgroundColor: activeTheme.bg_primary,
          borderColor: activeTheme.border_color
        }}
      >
        <div className="flex items-center gap-3">
          <button 
            onClick={onBack} 
            className="hover:opacity-70 transition-opacity"
            style={{ color: activeTheme.text_secondary }}
          >
            <ArrowLeft className="w-6 h-6" />
          </button>
          <div>
            <h2 className="font-bold flex items-center gap-2" style={{ color: activeTheme.text_primary }}>
              #{channel?.name}
              {channel?.privacy_status === 'private' && <Shield className="w-3 h-3 text-gray-500" />}
            </h2>
            <p className="text-xs truncate max-w-[200px]" style={{ color: activeTheme.text_secondary }}>
              {memberCount} members • {channel?.description}
            </p>
          </div>
        </div>
        
        <div className="flex items-center gap-2">
           {!isMember && (
             <Button 
                size="sm" 
                onClick={handleJoin} 
                className="h-8 text-xs text-white"
                style={{ backgroundColor: activeTheme.accent_primary }}
             >
               <UserPlus className="w-3 h-3 mr-1" /> Join
             </Button>
           )}
           <Sheet>
             <SheetTrigger asChild>
               <Button variant="ghost" size="icon" style={{ color: activeTheme.text_secondary }}>
                 <Users className="w-5 h-5" />
               </Button>
             </SheetTrigger>
             <SheetContent style={{ backgroundColor: activeTheme.bg_primary, borderColor: activeTheme.border_color }}>
               <CommunityMembersPanel channelId={channelId} isCreator={isCreator} onClose={() => {}} />
             </SheetContent>
           </Sheet>

            <DropdownMenu>
            <DropdownMenuTrigger asChild>
                <Button variant="ghost" size="icon" style={{ color: activeTheme.text_secondary }}>
                <MoreVertical className="w-5 h-5" />
                </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent 
                align="end" 
                style={{ backgroundColor: activeTheme.bg_primary, borderColor: activeTheme.border_color }}
            >
                <DropdownMenuItem onClick={handleReportChannel} className="text-orange-600">
                    <Flag className="w-4 h-4 mr-2" /> Report Community
                </DropdownMenuItem>
                
                {isCreator && (
                    <>
                        <DropdownMenuSeparator />
                        <DropdownMenuItem 
                        onClick={() => setDeleteDialogOpen(true)}
                        className="text-red-600 focus:text-red-600 focus:bg-red-50 dark:focus:bg-red-900/20 cursor-pointer"
                        >
                        <Trash2 className="w-4 h-4 mr-2" />
                        Delete Channel
                        </DropdownMenuItem>
                    </>
                )}
            </DropdownMenuContent>
            </DropdownMenu>
        </div>
      </div>

      {/* Chat Area */}
      <div 
        ref={scrollRef} 
        className="flex-1 overflow-y-auto p-4 space-y-4"
        style={{ backgroundColor: activeTheme.bg_secondary }}
      >
        <AnimatePresence initial={false}>
          {messages.map((msg) => {
            const isMe = user && msg.sender_id === user.id;
            return (
              <motion.div
                key={msg.id}
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                className={`flex gap-3 ${isMe ? 'flex-row-reverse' : ''}`}
              >
                {!isMe && (
                  <div 
                    className="w-8 h-8 border rounded-full flex-shrink-0 flex items-center justify-center text-xs font-bold shadow-sm"
                    style={{ 
                      backgroundColor: activeTheme.bg_primary, 
                      borderColor: activeTheme.border_color,
                      color: activeTheme.accent_primary 
                    }}
                  >
                    {msg.profiles?.full_name?.[0]}
                  </div>
                )}
                <div className={`max-w-[80%] ${isMe ? 'items-end' : 'items-start'} flex flex-col`}>
                  {!isMe && (
                    <span className="text-[10px] ml-1 mb-0.5" style={{ color: activeTheme.text_secondary }}>
                      {msg.profiles?.full_name}
                    </span>
                  )}
                  <div 
                    className={`p-3 rounded-xl text-sm shadow-sm ${
                      isMe ? 'rounded-br-none' : 'rounded-bl-none'
                    }`}
                    style={{
                      backgroundColor: isMe ? activeTheme.accent_primary : activeTheme.bg_primary,
                      color: isMe ? '#ffffff' : activeTheme.text_primary,
                    }}
                  >
                    {msg.content}
                  </div>
                  <span className="text-[9px] mt-1 opacity-70" style={{ color: activeTheme.text_secondary }}>
                    {new Date(msg.created_at).toLocaleTimeString([], {hour: '2-digit', minute:'2-digit'})}
                  </span>
                </div>
              </motion.div>
            );
          })}
        </AnimatePresence>
      </div>

      {/* Input */}
      {isMember ? (
        <form 
          onSubmit={handleSend} 
          className="p-4 border-t flex gap-2"
          style={{ 
            backgroundColor: activeTheme.bg_primary,
            borderColor: activeTheme.border_color
          }}
        >
          <input
            value={newMessage}
            onChange={e => setNewMessage(e.target.value)}
            className="flex-1 p-3 rounded-full focus:outline-none focus:ring-2 border-transparent transition-all"
            style={{ 
              backgroundColor: activeTheme.bg_secondary,
              color: activeTheme.text_primary,
            }}
            placeholder={`Message #${channel?.name || 'channel'}`}
            disabled={sending}
          />
          <Button 
            type="submit" 
            size="icon" 
            disabled={sending} 
            className="rounded-full w-12 h-12 shadow-md"
            style={{ backgroundColor: activeTheme.accent_primary, color: '#ffffff' }}
          >
            {sending ? <Loader2 className="w-4 h-4 animate-spin" /> : <Send className="w-4 h-4 ml-0.5" />}
          </Button>
        </form>
      ) : (
        <div 
          className="p-4 border-t text-center"
          style={{ 
            backgroundColor: activeTheme.bg_primary,
            borderColor: activeTheme.border_color
          }}
        >
          <Button 
            onClick={handleJoin} 
            className="w-full max-w-sm text-white"
            style={{ backgroundColor: activeTheme.accent_primary }}
          >
            Join to start chatting
          </Button>
        </div>
      )}

      {/* Delete Dialog */}
      <DeleteChannelDialog
        isOpen={deleteDialogOpen}
        onClose={setDeleteDialogOpen}
        onConfirm={handleDeleteChannel}
        channelName={channel?.name}
        loading={isDeleting}
      />
    </div>
  );
};

export default ChannelDetailPage;
