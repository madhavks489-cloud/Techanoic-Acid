
import React, { useState } from 'react';
import { useAuth } from '@/context/AuthContext';
import { supabase } from '@/lib/supabase';
import { useToast } from '@/components/ui/use-toast';
import { Button } from '@/components/ui/button';
import { Textarea } from '@/components/ui/textarea';
import { Loader2, Send } from 'lucide-react';
import { useTheme } from '@/context/ThemeContext';

const QnAAnswerForm = ({ questionId, onAnswerSubmitted }) => {
  const { user } = useAuth();
  const { activeTheme } = useTheme();
  const { toast } = useToast();
  const [answerText, setAnswerText] = useState('');
  const [loading, setLoading] = useState(false);

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!user) return;
    if (!answerText.trim()) return;

    setLoading(true);
    try {
      const { error } = await supabase
        .from('qa_answers')
        .insert({
          question_id: questionId,
          user_id: user.id,
          answer_text: answerText
        });

      if (error) throw error;

      // Update answer count on question
      await supabase.rpc('increment_answer_count', { q_id: questionId }).catch(() => {
          // Fallback if RPC doesn't exist, manual update
          // This is often handled by triggers but doing manual for simplicity if needed
      });
      // Or simply let the realtime subscription handle the UI update

      setAnswerText('');
      toast({
        title: "Answer Posted",
        description: "Thanks for helping out!"
      });
      onAnswerSubmitted?.();
    } catch (error) {
      console.error('Error posting answer:', error);
      toast({
        title: "Error",
        description: "Failed to post answer.",
        variant: "destructive"
      });
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="bg-white p-4 rounded-xl shadow-sm border mt-6" style={{ borderColor: activeTheme.border_color }}>
      <h3 className="font-semibold mb-3">Your Answer</h3>
      <form onSubmit={handleSubmit}>
        <Textarea
          placeholder="Share your knowledge..."
          value={answerText}
          onChange={(e) => setAnswerText(e.target.value)}
          className="min-h-[100px] mb-3"
        />
        <div className="flex justify-end">
          <Button 
            type="submit" 
            disabled={loading || !answerText.trim()}
            style={{ backgroundColor: activeTheme.accent_primary, color: '#fff' }}
          >
            {loading ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : <Send className="mr-2 h-4 w-4" />}
            Post Answer
          </Button>
        </div>
      </form>
    </div>
  );
};

export default QnAAnswerForm;
