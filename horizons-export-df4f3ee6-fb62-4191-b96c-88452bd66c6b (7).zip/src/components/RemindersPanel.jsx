
import React, { useState, useEffect } from 'react';
import { Calendar, Trash2, Plus, Bell, CheckCircle } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { useToast } from '@/components/ui/use-toast';
import { motion } from 'framer-motion';
import { supabase } from '@/lib/supabase';
import { useAuth } from '@/context/AuthContext';

const RemindersPanel = () => {
  const [reminders, setReminders] = useState([]);
  const [showAdd, setShowAdd] = useState(false);
  const [newReminder, setNewReminder] = useState({ title: '', due_date: '', type: 'vaccine' });
  const { toast } = useToast();
  const { user } = useAuth();

  useEffect(() => {
    fetchReminders();
  }, []);

  const fetchReminders = async () => {
    const { data } = await supabase.from('reminders').select('*').eq('user_id', user.id).order('due_date', { ascending: true });
    if (data) setReminders(data);
  };

  const addReminder = async (e) => {
    e.preventDefault();
    const { error } = await supabase.from('reminders').insert({
      user_id: user.id,
      title: newReminder.title,
      type: newReminder.type,
      due_date: newReminder.due_date,
      is_completed: false
    });

    if (error) {
      toast({ title: "Error", description: error.message, variant: "destructive" });
    } else {
      toast({ title: "Reminder Added" });
      setShowAdd(false);
      setNewReminder({ title: '', due_date: '', type: 'vaccine' });
      fetchReminders();
    }
  };

  const deleteReminder = async (id) => {
    await supabase.from('reminders').delete().eq('id', id);
    fetchReminders();
  };

  const toggleComplete = async (reminder) => {
    await supabase.from('reminders').update({ is_completed: !reminder.is_completed }).eq('id', reminder.id);
    fetchReminders();
  };

  return (
    <div className="container mx-auto px-4 py-6 max-w-2xl">
      <div className="flex justify-between items-center mb-6">
        <h1 className="text-2xl font-bold font-poppins text-gray-800">Pet Reminders</h1>
        <Button onClick={() => setShowAdd(!showAdd)} size="sm" className="bg-[#9CAF88]">
          <Plus className="w-4 h-4 mr-2" /> Add
        </Button>
      </div>

      {showAdd && (
        <motion.form 
          initial={{ height: 0, opacity: 0 }}
          animate={{ height: 'auto', opacity: 1 }}
          className="bg-white p-4 rounded-xl shadow-lg mb-6 space-y-4 border border-gray-100"
          onSubmit={addReminder}
        >
          <input 
            placeholder="Reminder Title" 
            className="w-full p-2 border rounded focus:ring-1 focus:ring-[#9CAF88]"
            required
            value={newReminder.title}
            onChange={e => setNewReminder({...newReminder, title: e.target.value})}
          />
          <div className="flex gap-2">
            <input 
              type="date" 
              className="flex-1 p-2 border rounded"
              required
              value={newReminder.due_date}
              onChange={e => setNewReminder({...newReminder, due_date: e.target.value})}
            />
            <select 
              className="flex-1 p-2 border rounded"
              value={newReminder.type}
              onChange={e => setNewReminder({...newReminder, type: e.target.value})}
            >
              <option value="vaccine">Vaccine</option>
              <option value="medication">Medication</option>
              <option value="grooming">Grooming</option>
              <option value="vet">Vet Visit</option>
            </select>
          </div>
          <Button type="submit" className="w-full bg-[#9CAF88]">Save</Button>
        </motion.form>
      )}

      <div className="space-y-3">
        {reminders.length === 0 ? (
           <div className="text-center py-10 text-gray-500 bg-white rounded-xl shadow-sm border border-dashed border-gray-200">
             <Bell className="w-8 h-8 mx-auto mb-2 text-gray-300" />
             <p>No upcoming reminders.</p>
           </div>
        ) : (
          reminders.map(reminder => (
            <motion.div 
              key={reminder.id}
              initial={{ x: -20, opacity: 0 }}
              animate={{ x: 0, opacity: 1 }}
              className={`p-4 rounded-xl shadow-sm flex items-center justify-between border-l-4 transition-all ${
                reminder.is_completed ? 'bg-gray-50 border-gray-300 opacity-60' : 'bg-white border-[#9CAF88]'
              }`}
            >
              <div className="flex items-center gap-3">
                <button 
                  onClick={() => toggleComplete(reminder)}
                  className={`rounded-full p-1 border ${reminder.is_completed ? 'bg-green-100 border-green-500 text-green-600' : 'border-gray-300 text-transparent hover:border-[#9CAF88]'}`}
                >
                  <CheckCircle className="w-4 h-4" />
                </button>
                <div>
                  <h3 className={`font-bold ${reminder.is_completed ? 'line-through text-gray-400' : 'text-gray-900'}`}>{reminder.title}</h3>
                  <div className="flex items-center text-sm text-gray-500 gap-2">
                    <Calendar className="w-3 h-3" />
                    {new Date(reminder.due_date).toLocaleDateString()}
                    <span className="capitalize bg-gray-100 px-2 py-0.5 rounded text-[10px]">{reminder.type}</span>
                  </div>
                </div>
              </div>
              <Button 
                variant="ghost" 
                size="sm" 
                onClick={() => deleteReminder(reminder.id)}
                className="text-gray-400 hover:text-red-500"
              >
                <Trash2 className="w-4 h-4" />
              </Button>
            </motion.div>
          ))
        )}
      </div>
    </div>
  );
};

export default RemindersPanel;
