
import React, { useState, useEffect } from 'react';
import { Send, Image as ImageIcon, X, Loader2, Paperclip } from 'lucide-react';
import { supabase } from '@/lib/supabase';
import { Button } from '@/components/ui/button';
import { useAuth } from '@/context/AuthContext';
import { useTheme } from '@/context/ThemeContext';
import { motion, AnimatePresence } from 'framer-motion';

const ReplyForm = ({ 
  threadId, 
  parentReply = null, 
  initialData = null, 
  onSuccess, 
  onCancel 
}) => {
  const { user } = useAuth();
  const { activeTheme } = useTheme();
  const [content, setContent] = useState(initialData?.content || '');
  const [selectedFile, setSelectedFile] = useState(null);
  const [previewUrl, setPreviewUrl] = useState(initialData?.image_url || null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);

  useEffect(() => {
    if (initialData) {
      setContent(initialData.content);
      setPreviewUrl(initialData.image_url);
    }
  }, [initialData]);

  const handleFileSelect = (e) => {
    const file = e.target.files[0];
    if (file) {
      if (file.size > 5 * 1024 * 1024) { // 5MB limit
        setError("Image size must be less than 5MB");
        return;
      }
      setSelectedFile(file);
      setPreviewUrl(URL.createObjectURL(file));
      setError(null);
    }
  };

  const clearFile = () => {
    setSelectedFile(null);
    setPreviewUrl(null);
    // If editing and had an image, clearing it means we want to remove it
    if (initialData?.image_url) {
      // Logic to track removal could be added here if needed, 
      // for now we just clear the preview.
    }
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!content.trim() && !selectedFile && !previewUrl) return;
    
    setLoading(true);
    setError(null);

    try {
      let imageUrl = previewUrl;

      // Upload new file if selected
      if (selectedFile) {
        const fileExt = selectedFile.name.split('.').pop();
        const fileName = `${Math.random()}.${fileExt}`;
        const filePath = `${user.id}/${fileName}`;
        
        const { error: uploadError } = await supabase.storage
          .from('forum_images')
          .upload(filePath, selectedFile);
        
        if (uploadError) throw uploadError;
        
        const { data: publicUrlData } = supabase.storage
          .from('forum_images')
          .getPublicUrl(filePath);
        
        imageUrl = publicUrlData.publicUrl;
      } else if (initialData && !previewUrl) {
         // If editing and preview was cleared, remove image
         imageUrl = null;
      }

      if (initialData) {
        // Update existing reply
        const { error: updateError } = await supabase
          .from('forum_replies')
          .update({
            content,
            image_url: imageUrl,
            updated_at: new Date().toISOString()
          })
          .eq('id', initialData.id);

        if (updateError) throw updateError;
      } else {
        // Create new reply
        const { error: insertError } = await supabase
          .from('forum_replies')
          .insert({
            thread_id: threadId,
            author_id: user.id,
            content,
            image_url: imageUrl,
            is_expert_reply: user.role === 'verified_vet',
            parent_reply_id: parentReply?.id || null
          });

        if (insertError) throw insertError;
      }
      
      setContent('');
      clearFile();
      if (onSuccess) onSuccess();
    } catch (err) {
      console.error("Error submitting reply:", err);
      setError("Failed to post reply. Please try again.");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div 
      className="p-4 rounded-lg shadow-sm border"
      style={{ 
        backgroundColor: activeTheme.bg_secondary,
        borderColor: activeTheme.border_color
      }}
    >
      {parentReply && (
        <div className="mb-3 text-sm flex items-center gap-2 opacity-70" style={{ color: activeTheme.text_secondary }}>
          <div className="w-1 h-4 rounded-full" style={{ backgroundColor: activeTheme.accent_primary }}></div>
          Replying to <span className="font-semibold">@{parentReply.profiles?.full_name || 'User'}</span>
        </div>
      )}

      <form onSubmit={handleSubmit} className="space-y-4">
        <textarea
          value={content}
          onChange={(e) => setContent(e.target.value)}
          placeholder={parentReply ? "Write a reply..." : "Add to the discussion..."}
          className="w-full p-3 rounded-md min-h-[100px] resize-none focus:outline-none focus:ring-2 bg-transparent"
          style={{ 
            color: activeTheme.text_primary,
            border: `1px solid ${activeTheme.border_color}`,
            backgroundColor: activeTheme.bg_primary
          }}
        />

        <AnimatePresence>
          {previewUrl && (
            <motion.div 
              initial={{ opacity: 0, height: 0 }}
              animate={{ opacity: 1, height: 'auto' }}
              exit={{ opacity: 0, height: 0 }}
              className="relative inline-block"
            >
              <img 
                src={previewUrl} 
                alt="Preview" 
                className="h-32 w-auto object-cover rounded-md border"
                style={{ borderColor: activeTheme.border_color }}
              />
              <button 
                type="button"
                onClick={clearFile} 
                className="absolute -top-2 -right-2 text-white rounded-full p-1 bg-black/50 hover:bg-black/70"
              >
                <X className="w-3 h-3" />
              </button>
            </motion.div>
          )}
        </AnimatePresence>

        {error && <p className="text-red-500 text-sm">{error}</p>}

        <div className="flex justify-between items-center pt-2">
          <label className="cursor-pointer p-2 rounded-full hover:bg-gray-100 dark:hover:bg-gray-800 transition-colors">
            <input 
              type="file" 
              accept="image/*" 
              onChange={handleFileSelect} 
              className="hidden" 
            />
            <ImageIcon className="w-5 h-5" style={{ color: activeTheme.text_secondary }} />
          </label>

          <div className="flex gap-2">
            {onCancel && (
              <Button 
                type="button" 
                variant="ghost" 
                onClick={onCancel}
                style={{ color: activeTheme.text_secondary }}
              >
                Cancel
              </Button>
            )}
            <Button 
              type="submit" 
              disabled={loading || (!content.trim() && !selectedFile && !previewUrl)}
              className="min-w-[100px]"
              style={{ backgroundColor: activeTheme.accent_primary, color: '#fff' }}
            >
              {loading ? <Loader2 className="w-4 h-4 animate-spin" /> : (initialData ? 'Update' : 'Reply')}
            </Button>
          </div>
        </div>
      </form>
    </div>
  );
};

export default ReplyForm;
