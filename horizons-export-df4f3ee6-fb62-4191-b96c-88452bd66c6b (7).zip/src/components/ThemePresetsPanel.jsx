
import React from 'react';
import { motion } from 'framer-motion';
import { Check } from 'lucide-react';
import { useTheme } from '@/context/ThemeContext';
import { cn } from '@/lib/utils';

const ThemePresetsPanel = () => {
  const { getPresetThemes, applyPreset, isPresetActive, activeTheme } = useTheme();
  const presets = getPresetThemes();

  return (
    <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-4 p-4">
      {presets.map((preset) => {
        const isActive = isPresetActive(preset.id);
        
        return (
          <motion.div
            key={preset.id}
            whileHover={{ scale: 1.02, y: -2 }}
            whileTap={{ scale: 0.98 }}
            onClick={() => applyPreset(preset.id)}
            className={cn(
              "relative cursor-pointer rounded-xl border-2 p-4 transition-all duration-300 overflow-hidden group",
              isActive 
                ? "border-[var(--accent-primary)] shadow-lg bg-[var(--bg-secondary)]" 
                : "border-[var(--border-color)] bg-[var(--bg-primary)] hover:border-[var(--text-secondary)]"
            )}
          >
            {isActive && (
              <div className="absolute top-2 right-2 bg-[var(--accent-primary)] text-white rounded-full p-1 shadow-sm z-10">
                <Check className="w-3 h-3" />
              </div>
            )}

            <h3 className="font-bold text-[var(--text-primary)] mb-1">{preset.name}</h3>
            <p className="text-xs text-[var(--text-secondary)] mb-3 line-clamp-2 min-h-[2.5em]">{preset.description}</p>

            {/* Color Palette Preview */}
            <div className="flex gap-2 mb-2">
              <div 
                className="w-8 h-8 rounded-full border shadow-sm" 
                style={{ backgroundColor: preset.colors.bg_primary, borderColor: preset.colors.border_color }} 
                title="Background"
              />
              <div 
                className="w-8 h-8 rounded-full border shadow-sm" 
                style={{ backgroundColor: preset.colors.accent_primary, borderColor: 'transparent' }} 
                title="Primary Accent"
              />
              <div 
                className="w-8 h-8 rounded-full border shadow-sm" 
                style={{ backgroundColor: preset.colors.accent_secondary, borderColor: 'transparent' }} 
                title="Secondary Accent"
              />
               <div 
                className="w-8 h-8 rounded-full border shadow-sm flex items-center justify-center font-bold text-xs" 
                style={{ backgroundColor: preset.colors.bg_secondary, color: preset.colors.text_primary }} 
                title="Text on Secondary"
              >
                Aa
              </div>
            </div>
            
            <div 
                className="h-1 w-full rounded-full mt-2 opacity-50 group-hover:opacity-100 transition-opacity"
                style={{ background: `linear-gradient(to right, ${preset.colors.accent_primary}, ${preset.colors.accent_secondary})` }}
            />
          </motion.div>
        );
      })}
    </div>
  );
};

export default ThemePresetsPanel;
