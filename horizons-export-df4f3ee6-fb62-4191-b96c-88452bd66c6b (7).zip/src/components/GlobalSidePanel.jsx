
import React from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Link, useNavigate } from 'react-router-dom';
import { X, User, Settings, HelpCircle, LogOut, Dog, Cat, MapPin, Video, Users } from 'lucide-react';
import { useAuth } from '@/context/AuthContext';
import { usePetTheme } from '@/context/PetThemeContext';
import PetButton from '@/components/ui/PetButton';

const GlobalSidePanel = () => {
  const { activeSidePanel, toggleSidePanel, soundEnabled, setSoundEnabled, cursorTrailEnabled, setCursorTrailEnabled } = usePetTheme();
  const { user, signOut } = useAuth();
  const navigate = useNavigate();

  const handleSignOut = async () => {
    await signOut();
    toggleSidePanel();
    navigate('/signin');
  };

  return (
    <AnimatePresence>
      {activeSidePanel && (
        <>
          {/* Backdrop */}
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 0.5 }}
            exit={{ opacity: 0 }}
            onClick={toggleSidePanel}
            className="fixed inset-0 bg-black/40 z-50 backdrop-blur-sm"
          />

          {/* Panel */}
          <motion.div
            initial={{ x: '100%' }}
            animate={{ x: 0 }}
            exit={{ x: '100%' }}
            transition={{ type: 'spring', damping: 25, stiffness: 200 }}
            className="fixed right-0 top-0 bottom-0 w-80 bg-white z-50 shadow-2xl overflow-y-auto"
          >
            <div className="p-6 h-full flex flex-col">
              <div className="flex justify-between items-center mb-8">
                <h2 className="text-xl font-bold text-[var(--text-primary)]">Menu</h2>
                <button onClick={toggleSidePanel} className="p-2 hover:bg-[var(--pet-cream)] rounded-full transition-colors">
                  <X className="w-6 h-6 text-[var(--text-secondary)]" />
                </button>
              </div>

              {user && (
                <div className="mb-8 p-4 bg-[var(--pet-blue-soft)] rounded-2xl flex items-center gap-3">
                  <div className="w-12 h-12 rounded-full bg-white border-2 border-[var(--pet-blue-primary)] overflow-hidden">
                     {user.avatar_url ? (
                       <img src={user.avatar_url} className="w-full h-full object-cover" />
                     ) : (
                       <div className="w-full h-full flex items-center justify-center"><User className="w-6 h-6 text-[var(--pet-text-light)]"/></div>
                     )}
                  </div>
                  <div>
                    <h3 className="font-bold text-[var(--pet-text-dark)]">{user.full_name}</h3>
                    <p className="text-xs text-[var(--pet-text-light)]">@{user.username}</p>
                  </div>
                </div>
              )}

              <nav className="space-y-2 flex-1">
                {[
                  { icon: Dog, label: "My Feed", path: "/dashboard" },
                  { icon: MapPin, label: "Adoption Centres", path: "/adoption-centres" },
                  { icon: HelpCircle, label: "Q&A Forum", path: "/qa" },
                  { icon: Users, label: "Communities", path: "/dashboard" }, // Maps to dashboard tab usually
                  { icon: Video, label: "Zoomies", path: "/dashboard" },
                ].map((item, idx) => (
                  <Link 
                    key={idx}
                    to={item.path} 
                    onClick={toggleSidePanel}
                    className="flex items-center gap-3 p-3 rounded-xl hover:bg-[var(--pet-cream)] text-[var(--text-secondary)] hover:text-[var(--accent-primary)] transition-all font-medium"
                  >
                    <item.icon className="w-5 h-5" />
                    {item.label}
                  </Link>
                ))}

                <div className="my-6 border-t border-gray-100 pt-6">
                    <h4 className="text-sm font-semibold text-gray-400 mb-4 px-3">PREFERENCES</h4>
                    
                    <div className="flex items-center justify-between p-3">
                        <span className="text-sm font-medium">Sound Effects</span>
                        <div 
                          onClick={() => setSoundEnabled(!soundEnabled)}
                          className={`w-10 h-6 rounded-full p-1 cursor-pointer transition-colors ${soundEnabled ? 'bg-[var(--accent-primary)]' : 'bg-gray-200'}`}
                        >
                            <div className={`w-4 h-4 bg-white rounded-full shadow-sm transition-transform ${soundEnabled ? 'translate-x-4' : ''}`} />
                        </div>
                    </div>

                    <div className="flex items-center justify-between p-3">
                        <span className="text-sm font-medium">Paw Trail</span>
                        <div 
                          onClick={() => setCursorTrailEnabled(!cursorTrailEnabled)}
                          className={`w-10 h-6 rounded-full p-1 cursor-pointer transition-colors ${cursorTrailEnabled ? 'bg-[var(--accent-primary)]' : 'bg-gray-200'}`}
                        >
                            <div className={`w-4 h-4 bg-white rounded-full shadow-sm transition-transform ${cursorTrailEnabled ? 'translate-x-4' : ''}`} />
                        </div>
                    </div>
                </div>
              </nav>

              <div className="mt-auto pt-6 border-t border-gray-100">
                {user ? (
                   <button 
                     onClick={handleSignOut}
                     className="flex items-center gap-2 text-red-500 font-medium hover:bg-red-50 w-full p-3 rounded-xl transition-colors"
                   >
                     <LogOut className="w-5 h-5" /> Sign Out
                   </button>
                ) : (
                   <Link to="/signin" onClick={toggleSidePanel}>
                     <PetButton className="w-full">Log In / Sign Up</PetButton>
                   </Link>
                )}
              </div>
            </div>
          </motion.div>
        </>
      )}
    </AnimatePresence>
  );
};

export default GlobalSidePanel;
