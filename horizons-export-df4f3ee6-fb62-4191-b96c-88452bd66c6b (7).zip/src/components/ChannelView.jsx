
import React, { useState, useEffect, useRef } from 'react';
import { ArrowLeft, Send, Users } from 'lucide-react';
import { supabase } from '@/lib/supabase';
import { useAuth } from '@/context/AuthContext';
import { Button } from '@/components/ui/button';

const ChannelView = ({ channel, onBack }) => {
  const { user } = useAuth();
  const [messages, setMessages] = useState([]);
  const [newMessage, setNewMessage] = useState('');
  const scrollRef = useRef();

  useEffect(() => {
    fetchMessages();
    const sub = supabase.channel(`channel:${channel.id}`)
      .on('postgres_changes', { 
        event: 'INSERT', 
        schema: 'public', 
        table: 'channel_messages', 
        filter: `channel_id=eq.${channel.id}` 
      }, (payload) => {
        // Optimistic update or quick fetch to include profile data
        fetchMessages(); 
      })
      .subscribe();
    return () => supabase.removeChannel(sub);
  }, [channel.id]);

  const fetchMessages = async () => {
    const { data } = await supabase
      .from('channel_messages')
      .select('*, profiles:sender_id(full_name, avatar_url)')
      .eq('channel_id', channel.id)
      .order('created_at', { ascending: true });
    if (data) {
      setMessages(data);
      scrollToBottom();
    }
  };

  const scrollToBottom = () => {
    setTimeout(() => {
      if (scrollRef.current) scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
    }, 100);
  };

  const handleSend = async (e) => {
    e.preventDefault();
    if (!newMessage.trim()) return;

    await supabase.from('channel_messages').insert({
      channel_id: channel.id,
      sender_id: user.id,
      content: newMessage
    });
    setNewMessage('');
  };

  return (
    <div className="flex flex-col h-[calc(100vh-80px)] bg-[#FFF8F3]">
      {/* Header */}
      <div className="bg-white p-4 shadow-sm flex items-center justify-between z-10 border-b border-gray-100">
        <div className="flex items-center gap-3">
          <button onClick={onBack} className="text-gray-600"><ArrowLeft /></button>
          <div>
            <h2 className="font-bold text-gray-900">#{channel.name}</h2>
            <p className="text-xs text-gray-500">{channel.description}</p>
          </div>
        </div>
        <Users className="w-5 h-5 text-gray-400" />
      </div>

      {/* Chat Area */}
      <div ref={scrollRef} className="flex-1 overflow-y-auto p-4 space-y-4">
        {messages.map((msg) => {
          const isMe = msg.sender_id === user.id;
          return (
            <div key={msg.id} className={`flex gap-3 ${isMe ? 'flex-row-reverse' : ''}`}>
              {!isMe && (
                <div className="w-8 h-8 bg-gray-200 rounded-full flex-shrink-0 flex items-center justify-center text-xs font-bold text-gray-500">
                  {msg.profiles?.full_name?.[0]}
                </div>
              )}
              <div className={`max-w-[80%] ${isMe ? 'items-end' : 'items-start'} flex flex-col`}>
                {!isMe && <span className="text-[10px] text-gray-400 ml-1 mb-0.5">{msg.profiles?.full_name}</span>}
                <div className={`p-3 rounded-xl text-sm ${
                  isMe ? 'bg-[#9CAF88] text-white rounded-br-none' : 'bg-white text-gray-800 shadow-sm rounded-bl-none'
                }`}>
                  {msg.content}
                </div>
              </div>
            </div>
          );
        })}
      </div>

      {/* Input */}
      <form onSubmit={handleSend} className="p-4 bg-white border-t border-gray-100 flex gap-2">
        <input
          value={newMessage}
          onChange={e => setNewMessage(e.target.value)}
          className="flex-1 p-3 bg-gray-50 rounded-lg focus:outline-none focus:ring-2 focus:ring-[#9CAF88]"
          placeholder={`Message #${channel.name}`}
        />
        <Button type="submit" size="icon" className="bg-[#9CAF88]"><Send className="w-4 h-4" /></Button>
      </form>
    </div>
  );
};

export default ChannelView;
