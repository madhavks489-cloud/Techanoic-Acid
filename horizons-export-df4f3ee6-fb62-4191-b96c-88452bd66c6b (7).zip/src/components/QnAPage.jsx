
import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '@/context/AuthContext';
import { useTheme } from '@/context/ThemeContext';
import { supabase } from '@/lib/supabase';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { Badge } from '@/components/ui/badge';
import { MessageSquare, Plus, Search, MessageCircle } from 'lucide-react';
import AskQuestionForm from './AskQuestionForm';
import { motion } from 'framer-motion';

const CATEGORIES = ['All', 'Health', 'Training', 'Nutrition', 'Behavior', 'Adoption', 'General'];

const QnAPage = () => {
  const { user } = useAuth();
  const { activeTheme } = useTheme();
  const navigate = useNavigate();
  
  const [questions, setQuestions] = useState([]);
  const [loading, setLoading] = useState(true);
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState('All');
  const [isAskModalOpen, setIsAskModalOpen] = useState(false);

  useEffect(() => {
    fetchQuestions();

    const subscription = supabase.channel('public_questions')
      .on('postgres_changes', { event: '*', schema: 'public', table: 'qa_questions' }, fetchQuestions)
      .subscribe();

    return () => supabase.removeChannel(subscription);
  }, []);

  const fetchQuestions = async () => {
    setLoading(true);
    const { data, error } = await supabase
      .from('qa_questions')
      .select('*, profiles:user_id(full_name, avatar_url)')
      .order('created_at', { ascending: false });
    
    if (error) console.error('Error fetching questions:', error);
    else setQuestions(data || []);
    setLoading(false);
  };

  const filteredQuestions = questions.filter(q => {
    const matchesSearch = q.title.toLowerCase().includes(searchQuery.toLowerCase()) || 
                          q.description.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesCategory = selectedCategory === 'All' || q.category === selectedCategory;
    return matchesSearch && matchesCategory;
  });

  return (
    <div className="min-h-screen pb-24 px-4 py-6 md:px-8" style={{ backgroundColor: activeTheme.bg_secondary }}>
      <div className="max-w-4xl mx-auto">
        <div className="flex flex-col md:flex-row justify-between items-start md:items-center mb-8 gap-4">
          <div>
            <h1 className="text-3xl font-bold mb-2" style={{ color: activeTheme.text_primary }}>Pet Community Q&A</h1>
            <p className="text-gray-600">Get answers from experienced pet owners and experts</p>
          </div>
          
          <Dialog open={isAskModalOpen} onOpenChange={setIsAskModalOpen}>
            <DialogTrigger asChild>
              <Button 
                className="rounded-full shadow-lg"
                style={{ backgroundColor: activeTheme.accent_primary, color: '#fff' }}
                disabled={!user}
              >
                <Plus className="w-4 h-4 mr-2" /> Ask a Question
              </Button>
            </DialogTrigger>
            <DialogContent className="sm:max-w-lg">
              <DialogHeader>
                <DialogTitle>Ask the Community</DialogTitle>
              </DialogHeader>
              <AskQuestionForm onSuccess={() => setIsAskModalOpen(false)} onCancel={() => setIsAskModalOpen(false)} />
            </DialogContent>
          </Dialog>
        </div>

        {/* Filters */}
        <div className="flex flex-col md:flex-row gap-4 mb-6">
          <div className="relative flex-1">
            <Search className="absolute left-3 top-3 w-4 h-4 text-gray-400" />
            <Input 
              placeholder="Search questions..." 
              className="pl-10 bg-white"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
            />
          </div>
          <div className="flex gap-2 overflow-x-auto pb-2 md:pb-0 no-scrollbar">
            {CATEGORIES.map(cat => (
              <button
                key={cat}
                onClick={() => setSelectedCategory(cat)}
                className={`px-4 py-2 rounded-full text-sm font-medium whitespace-nowrap transition-colors ${
                  selectedCategory === cat 
                    ? 'bg-gray-900 text-white' 
                    : 'bg-white text-gray-600 hover:bg-gray-100'
                }`}
              >
                {cat}
              </button>
            ))}
          </div>
        </div>

        {/* Questions List */}
        <div className="space-y-4">
          {loading ? (
             <div className="flex justify-center py-10"><div className="animate-spin rounded-full h-8 w-8 border-b-2 border-gray-900"></div></div>
          ) : filteredQuestions.length === 0 ? (
             <div className="text-center py-16 bg-white rounded-xl shadow-sm">
                <MessageSquare className="w-12 h-12 mx-auto text-gray-300 mb-4" />
                <h3 className="text-lg font-medium text-gray-900">No questions found</h3>
                <p className="text-gray-500">Be the first to ask about this topic!</p>
             </div>
          ) : (
             filteredQuestions.map((q, index) => (
               <motion.div
                 key={q.id}
                 initial={{ opacity: 0, y: 10 }}
                 animate={{ opacity: 1, y: 0 }}
                 transition={{ delay: index * 0.05 }}
                 onClick={() => navigate(`/qa/${q.id}`)}
                 className="bg-white p-6 rounded-xl shadow-sm border hover:shadow-md transition-shadow cursor-pointer"
                 style={{ borderColor: activeTheme.border_color }}
               >
                 <div className="flex justify-between items-start mb-2">
                    <Badge variant="secondary" className="bg-blue-50 text-blue-700 hover:bg-blue-100 border-none">
                       {q.category}
                    </Badge>
                    <span className="text-xs text-gray-500">{new Date(q.created_at).toLocaleDateString()}</span>
                 </div>
                 <h3 className="text-lg font-bold mb-2 text-gray-900 line-clamp-1">{q.title}</h3>
                 <p className="text-gray-600 text-sm mb-4 line-clamp-2">{q.description}</p>
                 
                 <div className="flex justify-between items-center border-t pt-4">
                    <div className="flex items-center gap-2">
                       <div className="w-6 h-6 rounded-full bg-gray-200 flex items-center justify-center text-xs font-bold text-gray-600">
                          {q.profiles?.full_name?.[0]}
                       </div>
                       <span className="text-sm font-medium text-gray-700">{q.profiles?.full_name}</span>
                    </div>
                    <div className="flex items-center gap-1 text-gray-500 text-sm">
                       <MessageCircle className="w-4 h-4" />
                       <span>{q.answer_count || 0} Answers</span>
                    </div>
                 </div>
               </motion.div>
             ))
          )}
        </div>
      </div>
    </div>
  );
};

export default QnAPage;
