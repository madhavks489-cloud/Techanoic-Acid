
import React from 'react';
import { motion } from 'framer-motion';
import { MapPin, MessageCircle, User, ShieldCheck } from 'lucide-react';
import { useTheme } from '@/context/ThemeContext';
import { Avatar, AvatarImage, AvatarFallback } from '@/components/ui/avatar';
import { Button } from '@/components/ui/button';
import { useToast } from '@/components/ui/use-toast';

const UserSearchResults = ({ results, loading }) => {
  const { activeTheme } = useTheme();
  const { toast } = useToast();

  const handleAction = (action, userName) => {
    toast({
      title: `${action}`,
      description: `Feature to ${action.toLowerCase()} ${userName} coming soon!`,
    });
  };

  if (loading && (!results || results.length === 0)) {
    return (
      <div className="flex flex-col items-center justify-center py-20">
         {/* Spinner is handled in SearchBar usually, but good to have fallback here if initial load */}
         <p style={{ color: activeTheme.text_secondary }}>Searching...</p>
      </div>
    );
  }

  if (!loading && results.length === 0) {
    return (
      <div className="flex flex-col items-center justify-center py-20 text-center px-4">
        <User size={48} className="mb-4 opacity-20" style={{ color: activeTheme.text_primary }} />
        <h3 className="text-lg font-semibold mb-2" style={{ color: activeTheme.text_primary }}>No users found</h3>
        <p className="text-sm max-w-xs" style={{ color: activeTheme.text_secondary }}>
          Try searching for a different name, email, or pet name.
        </p>
      </div>
    );
  }

  return (
    <div className="grid grid-cols-1 gap-4 pb-24">
      {results.map((user, index) => (
        <motion.div
          key={user.id}
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: index * 0.05 }}
          className="p-4 rounded-xl shadow-sm border flex flex-col sm:flex-row gap-4 relative overflow-hidden"
          style={{
            backgroundColor: activeTheme.bg_surface || activeTheme.bg_primary,
            borderColor: activeTheme.border_color
          }}
        >
            {/* Background Accent for verified */}
            {user.role === 'vet' && (
                <div 
                    className="absolute top-0 right-0 w-16 h-16 transform translate-x-8 -translate-y-8 rotate-45 opacity-10"
                    style={{ backgroundColor: activeTheme.accent_primary }}
                />
            )}

            <div className="flex items-start gap-4 flex-1">
                <Avatar className="h-16 w-16 border-2" style={{ borderColor: activeTheme.bg_secondary }}>
                    <AvatarImage src={user.avatar_url} />
                    <AvatarFallback style={{ backgroundColor: activeTheme.accent_tertiary, color: activeTheme.accent_primary }}>
                        {user.full_name?.substring(0,2).toUpperCase() || 'U'}
                    </AvatarFallback>
                </Avatar>
                
                <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-2 mb-1">
                        <h3 className="font-semibold text-base truncate" style={{ color: activeTheme.text_primary }}>
                            {user.full_name || 'Anonymous User'}
                        </h3>
                        {user.role === 'vet' && (
                            <ShieldCheck className="w-4 h-4" style={{ color: activeTheme.accent_primary }} />
                        )}
                    </div>
                    
                    {/* Pets */}
                    {user.pets && user.pets.length > 0 && (
                        <p className="text-sm mb-1 truncate" style={{ color: activeTheme.text_secondary }}>
                            <span className="font-medium">Pets:</span> {user.pets.map(p => p.name).join(', ')}
                        </p>
                    )}

                    {/* Location */}
                    <div className="flex items-center gap-4 text-xs mt-2" style={{ color: activeTheme.text_secondary }}>
                        {user.distance !== null && (
                            <div className="flex items-center gap-1">
                                <MapPin size={12} />
                                <span>{user.distance < 1 ? '< 1 km' : `${user.distance.toFixed(1)} km`} away</span>
                            </div>
                        )}
                        {/* Fake verification status if needed */}
                        {user.role === 'vet' && (
                            <span className="px-2 py-0.5 rounded-full bg-blue-100 text-blue-700 text-[10px] font-medium dark:bg-blue-900 dark:text-blue-100">
                                Verified Vet
                            </span>
                        )}
                    </div>
                </div>
            </div>

            <div className="flex sm:flex-col gap-2 w-full sm:w-auto mt-2 sm:mt-0">
                <Button 
                    variant="outline" 
                    size="sm" 
                    className="flex-1 sm:w-32 gap-2"
                    onClick={() => handleAction('Message', user.full_name)}
                    style={{ 
                        borderColor: activeTheme.border_color,
                        color: activeTheme.text_primary
                    }}
                >
                    <MessageCircle size={14} />
                    Message
                </Button>
                <Button 
                    size="sm" 
                    className="flex-1 sm:w-32 gap-2"
                    onClick={() => handleAction('View Profile', user.full_name)}
                    style={{ 
                        backgroundColor: activeTheme.accent_primary,
                        color: '#ffffff' // Assuming generic white text for primary buttons is safe, or calculate contrast
                    }}
                >
                    <User size={14} />
                    Profile
                </Button>
            </div>
        </motion.div>
      ))}
    </div>
  );
};

export default UserSearchResults;
