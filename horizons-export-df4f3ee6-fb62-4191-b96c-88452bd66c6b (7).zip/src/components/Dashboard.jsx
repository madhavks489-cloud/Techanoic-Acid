
import React, { useState } from 'react';
import Feed from './Feed';
import ForumPage from './ForumPage';
import AIAssistant from './AIAssistant';
import MessagesPage from './MessagesPage';
import CommunitiesPage from './CommunitiesPage';
import MapView from './MapView';
import Profile from './Profile';
import BottomNav from './BottomNav';
import SearchPage from './SearchPage';
import ZoomiesPage from './ZoomiesPage';
import StoriesPage from './StoriesPage';
import { useTheme } from '@/context/ThemeContext';
import { Button } from '@/components/ui/button';
import { Menu } from 'lucide-react';
import SettingsPanel from './SettingsPanel';
import { Sheet, SheetContent, SheetTrigger } from '@/components/ui/sheet';

const Dashboard = ({ onNavigate }) => {
  const [activeTab, setActiveTab] = useState('home');
  const { activeTheme } = useTheme();

  const renderContent = () => {
    switch (activeTab) {
      case 'home':
        return (
          <>
            <StoriesPage />
            <Feed />
          </>
        );
      case 'search':
        return <SearchPage />;
      case 'zoomies':
        return <ZoomiesPage />;
      case 'forum':
        return <ForumPage />;
      case 'aiAssistant':
        return <AIAssistant />;
      case 'messages':
        return <MessagesPage />;
      case 'communities':
        return <CommunitiesPage />;
      case 'map':
        return <MapView />;
      case 'profile':
        return <Profile />;
      default:
        return <Feed />;
    }
  };

  return (
    <div 
      className="min-h-screen w-full relative transition-colors duration-300"
      style={{ backgroundColor: activeTheme.bg_primary }}
    >
      {/* Mobile Header with Settings - Hide on Zoomies page for full immersion */}
      {activeTab !== 'zoomies' && (
        <div className="fixed top-4 right-4 z-40 md:hidden">
            <Sheet>
            <SheetTrigger asChild>
                <Button 
                    variant="outline" 
                    size="icon" 
                    className="rounded-full shadow-lg"
                    style={{ 
                        backgroundColor: activeTheme.bg_surface,
                        borderColor: activeTheme.border_color,
                        color: activeTheme.text_primary
                    }}
                >
                <Menu className="h-5 w-5" />
                </Button>
            </SheetTrigger>
            <SheetContent>
                <SettingsPanel />
            </SheetContent>
            </Sheet>
        </div>
      )}

      {/* Main Content Area */}
      <main className="pb-24 min-h-screen">
        {renderContent()}
      </main>

      <BottomNav activeTab={activeTab} setActiveTab={setActiveTab} />
    </div>
  );
};

export default Dashboard;
