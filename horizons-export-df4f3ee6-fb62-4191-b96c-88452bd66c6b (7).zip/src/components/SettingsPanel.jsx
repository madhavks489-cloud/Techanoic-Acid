
import React, { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { ArrowLeft, MapPin, Key, Save, Palette, LayoutGrid, Shield } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Label } from '@/components/ui/label';
import { useAuth } from '@/context/AuthContext';
import { useToast } from '@/components/ui/use-toast';
import { useTheme } from '@/context/ThemeContext';
import ThemeToggle from '@/components/ThemeToggle';
import ThemeCustomizer from '@/components/ThemeCustomizer';
import ThemePresetsPanel from '@/components/ThemePresetsPanel';
import LocationSettings from '@/components/LocationSettings';

const SettingsPanel = ({ onBack }) => {
  const { user, updateUser } = useAuth();
  const [apiKey, setApiKey] = useState('');
  const { toast } = useToast();
  const [showThemeCustomizer, setShowThemeCustomizer] = useState(false);
  const { themeMode } = useTheme();

  useEffect(() => {
    const storedKey = localStorage.getItem('openai_api_key');
    if (storedKey) setApiKey(storedKey);
    else if (user?.openai_api_key) setApiKey(user.openai_api_key);
  }, [user]);

  const handleSaveKey = () => {
    localStorage.setItem('openai_api_key', apiKey);
    updateUser({ openai_api_key: apiKey });
    toast({
      title: "Settings Saved",
      description: "API Key updated successfully.",
    });
  };

  return (
    <div className="container mx-auto px-4 py-6 max-w-2xl">
      <motion.div
        initial={{ opacity: 0, x: -20 }}
        animate={{ opacity: 1, x: 0 }}
      >
        <button onClick={onBack} className="flex items-center gap-2 mb-6 text-[var(--text-secondary)] hover:text-[var(--text-primary)]">
          <ArrowLeft className="w-5 h-5" />
          <span>Back to Profile</span>
        </button>

        <h1 className="text-3xl font-bold mb-6 text-[var(--text-primary)]" style={{ fontFamily: 'Poppins, sans-serif' }}>Settings</h1>

        <div className="space-y-6">
          {/* Location Settings Section */}
          <div className="bg-[var(--bg-primary)] rounded-xl shadow-lg p-6 border border-[var(--border-color)]">
              <h2 className="text-xl font-bold text-[var(--text-primary)] mb-4 flex items-center gap-2">
                 <MapPin className="w-5 h-5 text-[var(--accent-primary)]" />
                 Location Services
              </h2>
              <LocationSettings />
          </div>

          {/* Theme Settings */}
          <div className="bg-[var(--bg-primary)] rounded-xl shadow-lg p-6 border border-[var(--border-color)]">
            <div className="flex justify-between items-center mb-6">
              <div className="flex gap-3">
                <Palette className="w-6 h-6 text-[var(--accent-primary)]" />
                <div>
                  <Label className="text-lg font-semibold text-[var(--text-primary)]">Appearance</Label>
                  <p className="text-sm text-[var(--text-secondary)]">Customize your app theme</p>
                </div>
              </div>
              <ThemeToggle />
            </div>
            
            <div className="bg-[var(--bg-secondary)] rounded-lg p-4 border border-[var(--border-color)] mb-4">
               <h3 className="font-semibold text-[var(--text-primary)] mb-3 flex items-center gap-2">
                 <LayoutGrid className="w-4 h-4" /> Quick Presets
               </h3>
               <div className="max-h-60 overflow-y-auto">
                 <ThemePresetsPanel />
               </div>
            </div>

            <Button 
              variant="outline" 
              onClick={() => setShowThemeCustomizer(true)}
              className="w-full mt-2 border-[var(--border-color)] text-[var(--text-primary)] hover:bg-[var(--bg-secondary)]"
            >
              Open Advanced Theme Editor
            </Button>
          </div>

          {/* OpenAI API Key */}
          <div className="bg-[var(--bg-primary)] rounded-xl shadow-lg p-6 border border-[var(--border-color)]">
            <div className="flex items-center gap-3 mb-4">
              <Key className="w-6 h-6 text-[var(--accent-secondary)]" />
              <Label className="text-lg font-semibold text-[var(--text-primary)]">OpenAI API Key</Label>
            </div>
            <p className="text-sm text-[var(--text-secondary)] mb-4">Required for AI Assistant functionality.</p>
            <div className="flex gap-2">
              <input
                type="password"
                value={apiKey}
                onChange={(e) => setApiKey(e.target.value)}
                placeholder="sk-..."
                className="flex-1 px-4 py-2 border border-[var(--border-color)] rounded-lg bg-[var(--input-bg)] text-[var(--text-primary)] focus:outline-none focus:ring-2 focus:ring-[var(--accent-primary)]"
              />
              <Button onClick={handleSaveKey} variant="outline" className="border-[var(--border-color)] text-[var(--text-primary)]">
                <Save className="w-4 h-4" />
              </Button>
            </div>
          </div>
        </div>
      </motion.div>

      <ThemeCustomizer isOpen={showThemeCustomizer} onClose={() => setShowThemeCustomizer(false)} />
    </div>
  );
};

export default SettingsPanel;
